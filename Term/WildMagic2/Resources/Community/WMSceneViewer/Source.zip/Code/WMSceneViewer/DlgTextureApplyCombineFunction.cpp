// DlgTextureApplyCombineFunction.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgTextureApplyCombineFunction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using Texture::ApplyCombineFunction;

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineFunction dialog


DlgTextureApplyCombineFunction::DlgTextureApplyCombineFunction(CWnd* pParent /*=NULL*/)
	: CDialog(DlgTextureApplyCombineFunction::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgTextureApplyCombineFunction)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgTextureApplyCombineFunction::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgTextureApplyCombineFunction)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgTextureApplyCombineFunction, CDialog)
	//{{AFX_MSG_MAP(DlgTextureApplyCombineFunction)
	ON_BN_CLICKED(IDC_RADIO_DOT3_RGB, OnRadioDot3Rgb)
	ON_BN_CLICKED(IDC_RADIO_ADD_SIGNED, OnRadioAddSigned)
	ON_BN_CLICKED(IDC_RADIO_DOT3_RGBA, OnRadioDot3Rgba)
	ON_BN_CLICKED(IDC_RADIO_INTERPOLATE, OnRadioInterpolate)
	ON_BN_CLICKED(IDC_RADIO_MODULATE, OnRadioModulate)
	ON_BN_CLICKED(IDC_RADIO_REPLACE, OnRadioReplace)
	ON_BN_CLICKED(IDC_RADIO_SUBTRACT, OnRadioSubtract)
	ON_BN_CLICKED(IDC_RADIO_ADD, OnRadioAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineFunction message handlers

void DlgTextureApplyCombineFunction::OnRadioDot3Rgb() 
{
	m_eACF = ApplyCombineFunction::ACF_DOT3_RGB;
}

void DlgTextureApplyCombineFunction::OnRadioAddSigned() 
{
	m_eACF = ApplyCombineFunction::ACF_ADD_SIGNED;
}

void DlgTextureApplyCombineFunction::OnRadioDot3Rgba() 
{
	m_eACF = ApplyCombineFunction::ACF_DOT3_RGBA;	
}

void DlgTextureApplyCombineFunction::OnRadioInterpolate() 
{
	m_eACF = ApplyCombineFunction::ACF_INTERPOLATE;	
}

void DlgTextureApplyCombineFunction::OnRadioModulate() 
{
	m_eACF = ApplyCombineFunction::ACF_MODULATE;	
}

void DlgTextureApplyCombineFunction::OnRadioReplace() 
{
	m_eACF = ApplyCombineFunction::ACF_REPLACE;	
}

void DlgTextureApplyCombineFunction::OnRadioSubtract() 
{
	m_eACF = ApplyCombineFunction::ACF_SUBTRACT;
}

void DlgTextureApplyCombineFunction::OnRadioAdd() 
{
	m_eACF = ApplyCombineFunction::ACF_ADD;
}


