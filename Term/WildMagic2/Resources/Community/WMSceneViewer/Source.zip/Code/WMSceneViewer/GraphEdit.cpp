// GraphEdit.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "WMGraphFunctions.h"
#include "GraphEdit.h"
#include "WMSceneViewerDoc.h"
#include "DlgTextureApplyCombineFunction.h"
#include "DlgTextureApplyCombineOp.h"
#include "DlgTextureApplyMode.h"
#include "DlgTextureApplyCombineSource.h"
#include "DlgColorRGB.h"
#include "DlgBoolean.h"
#include "DlgAlphaStateSrcBlendFunc.h"
#include "DlgAlphaStateDstBlendFunc.h"
#include "DlgAlphaStateTestFunc.h"
#include "DlgFloat.h"
#include "DlgVector3.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GraphEdit

IMPLEMENT_DYNCREATE(GraphEdit, CFormView)

const int STRLEN = 256;

GraphEdit::GraphEdit()
	: CFormView(GraphEdit::IDD)
{
	//{{AFX_DATA_INIT(GraphEdit)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

GraphEdit::~GraphEdit()
{
}

void GraphEdit::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GraphEdit)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GraphEdit, CFormView)
	//{{AFX_MSG_MAP(GraphEdit)
	ON_WM_LBUTTONDBLCLK()
	ON_NOTIFY(NM_RCLICK, IDC_TREE_GRAPH, OnRclickTreeGraph)
	ON_COMMAND(ID_EDIT_CHANGE, OnEditChange)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_NOTIFY(NM_DBLCLK, IDC_TREE_GRAPH, OnDblclkTreeGraph)
	ON_COMMAND(ID_EDIT_ADDTEXTURE, OnEditAddTexture)
	ON_COMMAND(ID_EDIT_ADDALPHASTATE, OnEditAddAlphaState)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GraphEdit diagnostics

#ifdef _DEBUG
void GraphEdit::AssertValid() const
{
	CFormView::AssertValid();
}

void GraphEdit::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// GraphEdit message handlers

void GraphEdit::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	ASSERT(m_BufferStream.Load("dummy.mgc"));
	//setup the tree control
	WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
	Node* pNode = pDoc->GetScene();
	CTreeCtrl* pTreeCtrl = (CTreeCtrl*)GetDlgItem(IDC_TREE_GRAPH);
	pTreeCtrl->DeleteAllItems();
	//empty all maps
	EmptyAllMaps();
	if (pNode)
	{
		HTREEITEM hParent = GetTreeCtrl().InsertItem("Root Node: ", TVI_ROOT);
		mapObjToItem[pNode] = hParent;
		mapItemToObj[hParent] = pNode;
		InsertNodes(pNode, hParent);		
	}
}

void GraphEdit::EmptyAllMaps()
{
	mapObjToItem.erase(mapObjToItem.begin(), mapObjToItem.end());
	mapItemToObj.erase(mapItemToObj.begin(), mapItemToObj.end());	
}

CTreeCtrl& GraphEdit::GetTreeCtrl()
{
	return *(CTreeCtrl*)GetDlgItem(IDC_TREE_GRAPH);
}


void GraphEdit::InsertTriMesh(TriMesh* pTriMesh, HTREEITEM hParent)
{	
	hParent = GetTreeCtrl().InsertItem(MakeName(pTriMesh, "TriMesh: "), hParent);
	mapObjToItem[pTriMesh] = hParent;
	mapItemToObj[hParent] = pTriMesh;
	InsertSpatial(pTriMesh, hParent);
	
	//insert the render states
	InsertRenderState(pTriMesh, hParent);

	//insert the child controllers
	Controller* pCont = pTriMesh->GetControllers();
	while (pCont != NULL)
	{
		InsertController(pCont, hParent);
		pCont = pCont->GetNext();
	}
	
	//insert the vertices
	HTREEITEM hTemp;
	hTemp = GetTreeCtrl().InsertItem("Vertices: ", hParent);
	InsertVertices(pTriMesh, hTemp);

	//insert connectivity info
	hTemp = GetTreeCtrl().InsertItem("Connectivity: ", hParent);
	InsertConnectivity(pTriMesh, hTemp);

	//insert the vertex colors
	hTemp = GetTreeCtrl().InsertItem("Vertex Colors: ", hParent);
	InsertVertexColors(pTriMesh, hTemp);

	//insert normals
	hTemp = GetTreeCtrl().InsertItem("Normals: ", hParent);
	InsertNormals(pTriMesh, hTemp);
}

HTREEITEM GraphEdit::InsertLight(Light* pL, HTREEITEM hParent)
{	
	char Buf[STRLEN];
	hParent = GetTreeCtrl().InsertItem(MakeName(pL, "Light: "), hParent);
	mapObjToItem[pL] = hParent;
	mapItemToObj[hParent] = pL;
	
	sprintf(Buf, "Attenuate = ");
	InsertBool(pL->Attenuate(), Buf, hParent);
	
	sprintf(Buf, "Constant = ");
	InsertFloat(pL->Constant(), Buf, hParent);

	sprintf(Buf, "Linear = ");
	InsertFloat(pL->Linear(), Buf, hParent);

	sprintf(Buf, "Quadratic = ");
	InsertFloat(pL->Quadratic(), Buf, hParent);

	sprintf(Buf, "On = ");
	InsertBool(pL->On(), Buf, hParent);

	sprintf(Buf, "Intensity = ");
	InsertFloat(pL->Intensity(), Buf, hParent);

	//do the colors	
	sprintf(Buf, "Ambient = ");
	InsertColorRGB(pL->Ambient(), Buf, hParent);

	sprintf(Buf, "Diffuse = ");
	InsertColorRGB(pL->Diffuse(), Buf, hParent);

	sprintf(Buf, "Specular = ");
	InsertColorRGB(pL->Specular(), Buf, hParent);
	
	return hParent;
}

string& GraphEdit::MakeName(AlphaState::TestFunction TF, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (TF)
	{
	case AlphaState::TF_ALWAYS:
		m_strName += "Always";
		break;

	case AlphaState::TF_EQUAL:
		m_strName += "x == y";
		break;

	case AlphaState::TF_GEQUAL:
		m_strName += "x >= y";
		break;

	case AlphaState::TF_GREATER:
		m_strName += "x > y";
		break;

	case AlphaState::TF_LEQUAL:
		m_strName += "x <= y";
		break;

	case AlphaState::TF_LESS:
		m_strName += "x < y";
		break;

	case AlphaState::TF_NEVER:
		m_strName += "Never";
		break;

	case AlphaState::TF_NOTEQUAL:
		m_strName += "x != y";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::CorrectionMode CM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (CM)
	{
	case Texture::CorrectionMode::CM_AFFINE:
		m_strName += "Affine";
		break;

	case Texture::CorrectionMode::CM_PERSPECTIVE:
		m_strName += "Perspective";
		break;
	
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(ColorRGB Color, const string& strPrefix)
{
	m_strName = strPrefix;
	char Buf[STRLEN];	
	sprintf(Buf, "%f %f %f", Color.r, Color.g, Color.b);
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(Texture::ApplyMode AM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (AM)
	{
	case Texture::ApplyMode::AM_REPLACE:
		m_strName += "Replace";
		break;
		
	case Texture::ApplyMode::AM_DECAL:
		m_strName += "Decal";
		break;
		
	case Texture::ApplyMode::AM_MODULATE:
		m_strName += "Modulate";
		break;
		
	case Texture::ApplyMode::AM_BLEND:
		m_strName += "Blend";
		break;
		
	case Texture::ApplyMode::AM_ADD:
		m_strName += "Add";
		break;
		
	case Texture::ApplyMode::AM_COMBINE:
		m_strName += "Combine";
		break;
		
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(AlphaState::SrcBlendFunction SBF, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (SBF)
	{
	case AlphaState::SBF_DST_ALPHA:
		m_strName += "Dst Alpha";
		break;

	case AlphaState::SBF_DST_COLOR:
		m_strName += "Dst Color";
		break;

	case AlphaState::SBF_ONE:
		m_strName += "One";
		break;

	case AlphaState::SBF_ONE_MINUS_DST_ALPHA:
		m_strName += "One Minus Dst Alpha";
		break;

	case AlphaState::SBF_ONE_MINUS_DST_COLOR:
		m_strName += "One Minus Dst Color";
		break;

	case AlphaState::SBF_ONE_MINUS_SRC_ALPHA:
		m_strName += "One Minus Src Alpha";
		break;

	case AlphaState::SBF_SRC_ALPHA:
		m_strName += "Src Alpha";
		break;

	case AlphaState::SBF_SRC_ALPHA_SATURATE:
		m_strName += "Src Alpha Saturate";
		break;

	case AlphaState::SBF_ZERO:
		m_strName += "Zero";
		break;		
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::ApplyCombineFunction ACF, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (ACF)
	{
	case Texture::ApplyCombineFunction::ACF_REPLACE:
		m_strName += "Replace";
		break;

	case Texture::ApplyCombineFunction::ACF_MODULATE:
		m_strName += "Modulate";
		break;

	case Texture::ApplyCombineFunction::ACF_ADD:
		m_strName += "Add";
		break;

	case Texture::ApplyCombineFunction::ACF_ADD_SIGNED:
		m_strName += "Add Signed";
		break;

	case Texture::ApplyCombineFunction::ACF_SUBTRACT:
		m_strName += "Subtract";
		break;

	case Texture::ApplyCombineFunction::ACF_INTERPOLATE:
		m_strName += "Interpolate";
		break;

	case Texture::ApplyCombineFunction::ACF_DOT3_RGB:
		m_strName += "Dot3 RGB";
		break;

	case Texture::ApplyCombineFunction::ACF_DOT3_RGBA:
		m_strName += "Dot3 RGBA";
		break;
		
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::ApplyCombineSrc ACS, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (ACS)
	{
	case Texture::ApplyCombineSrc::ACS_TEXTURE:
		m_strName += "Texture";
		break;
		
	case Texture::ApplyCombineSrc::ACS_PRIMARY_COLOR:
		m_strName += "Primary Color";
		break;
		
	case Texture::ApplyCombineSrc::ACS_CONSTANT:
		m_strName += "Constant";
		break;
		
	case Texture::ApplyCombineSrc::ACS_PREVIOUS:
		m_strName += "Previous";
		break;
		
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(AlphaState::DstBlendFunction DBF, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (DBF)
	{
	case AlphaState::DBF_DST_ALPHA:
		m_strName += "Dbf Dst Alpha";
		break;

	case AlphaState::DBF_ONE:
		m_strName += "One";
		break;

	case AlphaState::DBF_ONE_MINUS_DST_ALPHA:
		m_strName += "One Minus Dst Alpha";
		break;

	case AlphaState::DBF_ONE_MINUS_SRC_ALPHA:
		m_strName += "One Minus Src Alpha";
		break;

	case AlphaState::DBF_ONE_MINUS_SRC_COLOR:
		m_strName += "One Minus Src Color";
		break;

	case AlphaState::DBF_SRC_ALPHA:
		m_strName += "Src Alpha";
		break;

	case AlphaState::DBF_SRC_COLOR:
		m_strName += "Src Color";
		break;

	case AlphaState::DBF_ZERO:
		m_strName += "Zero";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::ApplyCombineOperand ACO, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (ACO)
	{
	case Texture::ApplyCombineOperand::ACO_SRC_COLOR:
		m_strName += "Src Color";
		break;

	case Texture::ApplyCombineOperand::ACO_ONE_MINUS_SRC_COLOR:
		m_strName += "One Minus Src Color";
		break;

	case Texture::ApplyCombineOperand::ACO_SRC_ALPHA:
		m_strName += "Src Alpha";
		break;

	case Texture::ApplyCombineOperand::ACO_ONE_MINUS_SRC_ALPHA:
		m_strName += "One Minus Src Alpha";
		break;

	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::ApplyCombineScale ACSC, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (ACSC)
	{
	case Texture::ApplyCombineScale::ACSC_ONE:
		m_strName += "One";
		break;

	case Texture::ApplyCombineScale::ACSC_TWO:
		m_strName += "Two";
		break;

	case Texture::ApplyCombineScale::ACSC_FOUR:
		m_strName += "Four";
		break;
	
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::WrapMode WM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (WM)
	{
	case Texture::WrapMode::WM_CLAMP_S_CLAMP_T:
		m_strName += "Clamp S Clamp T";
		break;

	case Texture::WrapMode::WM_CLAMP_S_WRAP_T:
		m_strName += "Clamp S Wrap T";
		break;

	case Texture::WrapMode::WM_WRAP_S_CLAMP_T:
		m_strName += "Wrap S Clamp T";
		break;
	
	case Texture::WrapMode::WM_WRAP_S_WRAP_T:
		m_strName += "Wrap S Wrap T";
		break;

	case Texture::WrapMode::WM_CLAMP_BORDER_S_CLAMP_BORDER_T:
		m_strName += "Clamp Border S Clamp Border T";
		break;

	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::MipmapMode MM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (MM)
	{
	case Texture::MipmapMode::MM_NONE:
		m_strName += "None";
		break;

	case Texture::MipmapMode::MM_NEAREST:
		m_strName += "Nearest";
		break;

	case Texture::MipmapMode::MM_LINEAR:
		m_strName += "Linear";
		break;

	case Texture::MipmapMode::MM_NEAREST_NEAREST:
		m_strName += "Nearest Nearest";
		break;

	case Texture::MipmapMode::MM_NEAREST_LINEAR:
		m_strName += "Nearest Linear";
		break;

	case Texture::MipmapMode::MM_LINEAR_NEAREST:
		m_strName += "Linear Nearest";
		break;

	case Texture::MipmapMode::MM_LINEAR_LINEAR:
		m_strName += "Linear Linear";
		break;

	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::EnvmapMode EM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (EM)
	{
	case Texture::EnvmapMode::EM_NONE:
		m_strName += "None";
		break;

	case Texture::EnvmapMode::EM_IGNORE:
		m_strName += "Ignore";
		break;

	case Texture::EnvmapMode::EM_SPHERE:
		m_strName += "Sphere";
		break;

	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

string& GraphEdit::MakeName(Texture::FilterMode FM, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (FM)
	{
	case Texture::FilterMode::FM_NEAREST:
		m_strName += "Nearest";
		break;

	case Texture::FilterMode::FM_LINEAR:
		m_strName += "Linear";
		break;
	
	default:
		m_strName += "Unknown";
		break;
	}	
	return m_strName;
}

string& GraphEdit::MakeName(float n, const string& strPrefix)
{
	m_strName = strPrefix;
	char Buf[STRLEN];
	sprintf(Buf, "%f", n);
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(int n, const string& strPrefix)
{
	m_strName = strPrefix;
	char Buf[STRLEN];
	sprintf(Buf, "%d", n);
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(bool b, const string& strPrefix)
{
	m_strName = strPrefix;
	char Buf[STRLEN];
	if (b)
	{
		sprintf(Buf, "true");
	}
	else
	{
		sprintf(Buf, "false");
	}
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(const Matrix3& rMat, const string& strPrefix)
{
	char Buf[STRLEN];
	m_strName = strPrefix;
	sprintf(Buf, "%f %f %f %f %f %f %f %f %f", 			
			rMat[0][0], rMat[0][1], rMat[0][2],
			rMat[1][0], rMat[1][1], rMat[1][2],
			rMat[2][0], rMat[2][1], rMat[2][2]);
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(const Vector3& rVec3, const string& strPrefix)
{
	char Buf[STRLEN];
	m_strName = strPrefix;
	sprintf(Buf, "%f %f %f", rVec3.x, rVec3.y, rVec3.z);
	m_strName += Buf;
	return m_strName;
}

string& GraphEdit::MakeName(Light::Type LType, const string& strPrefix)
{
	m_strName = strPrefix;
	switch (LType)
	{
	case Light::Type::LT_AMBIENT:
		m_strName += "Ambient";
		break;
	case Light::Type::LT_DIRECTIONAL:
		m_strName += "Directional";
		break;
	case Light::Type::LT_POINT:
		m_strName += "Point";
		break;
	case Light::Type::LT_SPOT:
		m_strName += "Spot";
		break;
	case Light::Type::LT_QUANTITY:
		m_strName += "Quantity";
		break;
	default:
		m_strName += "Unknown";
		break;
	}
	return m_strName;
}

void GraphEdit::InsertDirectionalLight(DirectionalLight* pDL, HTREEITEM hParent)
{
	char Buf[STRLEN];
	
	sprintf(Buf, "%s", MakeName(pDL->GetType(), "Type = ").c_str());
	GetTreeCtrl().InsertItem(Buf, hParent);
	InsertVector3(pDL->Direction(), "Direction = ", hParent);
}

void GraphEdit::InsertPointLight(PointLight* pPLight, HTREEITEM hParent)
{
	char Buf[STRLEN];	
	sprintf(Buf, "%s", MakeName(pPLight->GetType(), "Type = ").c_str());
	GetTreeCtrl().InsertItem(Buf, hParent);
	InsertVector3(pPLight->Location(), "Location = ", hParent);
}


void GraphEdit::InsertVector3(Vector3& rVec3, const string& strPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];	
	sprintf(Buf, "%s %f %f %f", strPrefix.c_str(), rVec3.x, rVec3.y, rVec3.z);
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertAmbientLight(AmbientLight* pAL, HTREEITEM hParent)
{
	char Buf[STRLEN];	
	sprintf(Buf, "%s", MakeName(pAL->GetType(), "Type = ").c_str());
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertLightState(LightState* pLS, HTREEITEM hParent)
{
	hParent = GetTreeCtrl().InsertItem(MakeName(pLS, "Light State: "), hParent);
	mapObjToItem[pLS] = hParent;
	mapItemToObj[hParent] = pLS;	

	int i, n = pLS->GetQuantity();
	for (i = 0; i < n; i++)
	{
		Light* pLight = pLS->Get(i);
		HTREEITEM hItem = InsertLight(pLight, hParent);
		if (MgcIsExactlyClass(AmbientLight, pLight))
		{
			AmbientLight* pAL = MgcDynamicCast(AmbientLight, pLight);
			InsertAmbientLight(pAL, hItem);		
		}
		else if (MgcIsExactlyClass(DirectionalLight, pLight))
		{
			DirectionalLight* pDL = MgcDynamicCast(DirectionalLight, pLight);
			InsertDirectionalLight(pDL, hItem);
		}
		else if (MgcIsExactlyClass(PointLight, pLight))
		{
			PointLight* pPLight = MgcDynamicCast(PointLight, pLight);
			InsertPointLight(pPLight, hItem);
		}
	}
}

void GraphEdit::InsertController(Controller* pCont, HTREEITEM hParent)
{
	do
	{
		if (MgcIsExactlyClass(IKController, (pCont)))
		{
			IKController* pIK = MgcDynamicCast(IKController, pCont);
			InsertIKController(pIK, hParent);
		}
		else if (MgcIsExactlyClass(SkinController, (pCont)))
		{
			SkinController* pSkin = MgcDynamicCast(SkinController, pCont);
			InsertSkinController(pSkin, hParent);
		}
		else if (MgcIsExactlyClass(KeyframeController, (pCont)))
		{
			KeyframeController* pKeyframe = MgcDynamicCast(KeyframeController, pCont);
			InsertKeyframeController(pKeyframe, hParent);
		}
	} while (pCont = pCont->GetNext());
}

void GraphEdit::InsertIKController(IKController* pIK, HTREEITEM hParent)
{
	hParent = GetTreeCtrl().InsertItem(MakeName(pIK, "IK Controller: "), hParent);
	mapObjToItem[pIK] = hParent;
	mapItemToObj[hParent] = pIK;
	
	InsertCommonControllerDetails(pIK, hParent);
}

char* GraphEdit::MakeName(Object* pObj, const char* szPrefix)
{
	static char Buf[STRLEN];	
	if (pObj->GetName())
	{
		sprintf(Buf, "%s Name = %s, ID = %d", szPrefix, pObj->GetName(), pObj->GetID());		
	}
	else
	{
		sprintf(Buf, "%s Name = <Unknown>, ID = %d", szPrefix, pObj->GetID());
	}	
	return Buf;
}

void GraphEdit::InsertCommonControllerDetails(Controller* pCont, HTREEITEM hParent)
{
	
	string str = "Repeat Type = ";
	switch (pCont->Repeat())
	{
	case Controller::RepeatType::RT_CLAMP:
		str += "RT_CLAMP";	
		break;

	case Controller::RepeatType::RT_WRAP:
		str += "RT_WRAP";
		break;

	case Controller::RepeatType::RT_CYCLE:
		str += "RT_CYCLE";
		break;

	case Controller::RepeatType::RT_QUANTITY:
		str += "RT_QUANTITY";
		break;

	default:
		str += "UNKNOWN";
	}	
	GetTreeCtrl().InsertItem(str.c_str(), hParent);	

	char Buf[STRLEN];
	sprintf(Buf, "Min Time = %f", pCont->MinTime());
	GetTreeCtrl().InsertItem(Buf, hParent);
	sprintf(Buf, "Max Time = %f", pCont->MaxTime());
	GetTreeCtrl().InsertItem(Buf, hParent);
	sprintf(Buf, "Phase = %f", pCont->Phase());
	GetTreeCtrl().InsertItem(Buf, hParent);
	sprintf(Buf, "Frequency = %f", pCont->Frequency());
	GetTreeCtrl().InsertItem(Buf, hParent);
	sprintf(Buf, "Active = %d", (int)pCont->Active());
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertSkinController(SkinController* pSkin, HTREEITEM hParent)
{
	//to be honest stringstreams blow. i wouldn't blame anybody for using sscanf - its so much easier

	hParent = GetTreeCtrl().InsertItem(MakeName(pSkin, "SkinController: "), hParent);
	mapObjToItem[pSkin] = hParent;
	mapItemToObj[hParent] = pSkin;
	
	//insert the common controller details
	InsertCommonControllerDetails(pSkin, hParent);
	
	int i, n = pSkin->BoneQuantity();
	char Buf[STRLEN];
	sprintf(Buf, "Number Bones = %d", n);
	GetTreeCtrl().InsertItem(Buf, hParent);
	for (i = 0; i < n; i++)
	{
		HTREEITEM hSkinVertexParent = GetTreeCtrl().InsertItem(MakeName(pSkin->Bones()[i], "Node Pointed To: "), hParent);
		InsertSkinVertices(pSkin->SkinVertices()[i], pSkin->SkinVertexQuantities()[i], hSkinVertexParent);
	}	
}

void GraphEdit::InsertSkinVertices(SkinController::SkinVertex* pVerts, int nVertices, HTREEITEM hParent)
{
	int i;
	char Buf[STRLEN];

	for (i = 0; i < nVertices; i++)
	{
		sprintf(Buf, "Index = %d", pVerts[i].m_iIndex);
		GetTreeCtrl().InsertItem(Buf, hParent);
		
		sprintf(Buf, "Weight = %f", pVerts[i].m_fWeight);
		GetTreeCtrl().InsertItem(Buf, hParent);

		InsertVector3(pVerts[i].m_kOffset, "Offset = ", hParent);		
	}
}

void GraphEdit::InsertKeyframeController(KeyframeController* pKeyframe, HTREEITEM hParent)
{
	char Buf[STRLEN];

	hParent = GetTreeCtrl().InsertItem(MakeName(pKeyframe, "Keyframe Controller: "), hParent);
	mapObjToItem[pKeyframe] = hParent;
	mapItemToObj[hParent] = pKeyframe;
	//insert the common controller details
	InsertCommonControllerDetails(pKeyframe, hParent);
	int i, n = pKeyframe->GetTranslationQuantity();		
	sprintf(Buf, "Translation Quantity = %d", n);
	GetTreeCtrl().InsertItem(Buf, hParent);
	
	sprintf(Buf, "Translation Times: ");
	HTREEITEM hTransParent = GetTreeCtrl().InsertItem(Buf, hParent);
	for (i = 0; i < n; i++)
	{		
		if (pKeyframe->GetTranslationTimes())
			sprintf(Buf, "%d: %f", i, pKeyframe->GetTranslationTimes()[i]);
		else
			sprintf(Buf, "%d: %f", i, pKeyframe->GetSharedTimes()[i]);			
	
		GetTreeCtrl().InsertItem(Buf, hTransParent);
	}
		
	sprintf(Buf, "Translations: ");
	hTransParent = GetTreeCtrl().InsertItem(Buf, hParent);
	for (i = 0; i < n; i++)
	{
		InsertVector3(pKeyframe->GetTranslations()[i], "Translate =", hTransParent);
	}

	n = pKeyframe->GetRotationQuantity();		
	sprintf(Buf, "Rotation Quantity = %d", n);
	GetTreeCtrl().InsertItem(Buf, hParent);
	sprintf(Buf, "Rotation Times: ");
	hTransParent = GetTreeCtrl().InsertItem(Buf, hParent);
	for (i = 0; i < n; i++)
	{
		if (pKeyframe->GetRotationTimes())
			sprintf(Buf, "%d: %f", i, pKeyframe->GetRotationTimes()[i]);
		else
			sprintf(Buf, "%d: %f", i, pKeyframe->GetSharedTimes()[i]);
		GetTreeCtrl().InsertItem(Buf, hTransParent);
	}
	
	sprintf(Buf, "Rotations: ");
	hTransParent = GetTreeCtrl().InsertItem(Buf, hParent);
	for (i = 0; i < n; i++)
	{
		InsertQuaternion(pKeyframe->GetRotations()[i], "Rotate =", hTransParent);
	}
}

void GraphEdit::InsertRenderState(Spatial* pNode, HTREEITEM hParent)
{
	//check for a light state
	RenderState* pRS = pNode->GetRenderState(RenderState::Type::RS_LIGHT);
	if (pRS != NULL)
	{
		LightState* pLS = MgcDynamicCast(LightState, (pRS));
		InsertLightState(pLS, hParent);				
	}
	
	//check for a material state
	pRS = pNode->GetRenderState(RenderState::Type::RS_MATERIAL);
	if (pRS != NULL)
	{
		MaterialState* pMS = MgcDynamicCast(MaterialState, (pRS));
		InsertMaterialState(pMS, hParent);		
	}

	//check for wireframe state
	pRS = pNode->GetRenderState(RenderState::Type::RS_WIREFRAME);
	if (pRS != NULL)
	{
		WireframeState* pWS = MgcDynamicCast(WireframeState, pRS);
		InsertWireframeState(pWS, hParent);
	}

	//check for cull state
	pRS = pNode->GetRenderState(RenderState::Type::RS_CULL);
	if (pRS != NULL)
	{
		CullState* pCS = MgcDynamicCast(CullState, pRS);
		InsertCullState(pCS, hParent);
	}

	//check for a texture state
	pRS = pNode->GetRenderState(RenderState::Type::RS_TEXTURE);
	if (pRS != NULL)
	{
		TextureState* pTS = MgcDynamicCast(TextureState, pRS);
		InsertTextureState(pTS, hParent);
	}

	//check for alpha state
	pRS = pNode->GetRenderState(RenderState::Type::RS_ALPHA);
	if (pRS != NULL)
	{
		AlphaState* pAS = MgcDynamicCast(AlphaState, pRS);
		InsertAlphaState(pAS, hParent);
	}
}

void GraphEdit::InsertTextureState(TextureState* pTS, HTREEITEM hParent)
{
	int i, n = pTS->GetQuantity();	

	hParent = GetTreeCtrl().InsertItem(MakeName(pTS, "TextureState: "), hParent);
	mapItemToObj[hParent] = pTS;
	mapObjToItem[pTS] = hParent;

	for (i = 0; i < n; i++)
	{
		InsertTexture(pTS->Get(i), hParent);
	}
}

void GraphEdit::InsertInteger(int n, const string& strPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];
	sprintf(Buf, "%s %d", strPrefix.c_str(), n);
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertTexture(Texture* pText, HTREEITEM hParent)
{
	hParent = GetTreeCtrl().InsertItem(MakeName(pText, "Texture: "), hParent);
	mapItemToObj[hParent] = pText;
	mapObjToItem[pText] = hParent;
	GetTreeCtrl().InsertItem(MakeName(pText->Correction(), "Correction: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->Apply(), "Apply: ").c_str(), hParent);
	InsertColorRGB(pText->BlendColor(), "Blend Color: ", hParent);	
	InsertColorRGB(pText->BorderColor(), "Border Color: ", hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->Wrap(), "Wrap: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->Filter(), "Filter: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->Envmap(), "EnvMap: ").c_str(), hParent);
	InsertFloat(pText->Priority(), "Priority: ", hParent);
	InsertInteger(pText->UserData(), "User Data: ", hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineFuncRGB(), "CombineFuncRGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineFuncAlpha(), "CombineFuncAlpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc0RGB(), "CombineSrc0RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc1RGB(), "CombineSrc1RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc2RGB(), "CombineSrc2RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc0Alpha(), "CombineSrc0Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc1Alpha(), "CombineSrc1Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineSrc2Alpha(), "CombineSrc2Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp0RGB(), "CombineOp0RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp1RGB(), "CombineOp1RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp2RGB(), "CombineOp2RGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp0Alpha(), "CombineOp0Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp1Alpha(), "CombineOp1Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineOp2Alpha(), "CombineOp2Alpha: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineScaleRGB(), "CombineScaleRGB: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pText->CombineScaleAlpha(), "CombineScaleAlpha: ").c_str(), hParent);
}


void GraphEdit::InsertWireframeState(WireframeState* pWS, HTREEITEM hParent)
{	
	char Buf[STRLEN];

	hParent = GetTreeCtrl().InsertItem(MakeName(pWS, "Wireframe: "), hParent);
	mapObjToItem[pWS] = hParent;
	mapItemToObj[hParent] = pWS;
	
	//wireframe details	
	sprintf(Buf, "Enabled = ");
	InsertBool(pWS->Enabled(), Buf, hParent);
}

void GraphEdit::InsertMaterialState(MaterialState* pMat, HTREEITEM hParent)
{
	hParent = GetTreeCtrl().InsertItem(MakeName(pMat, "Material State: "), hParent);
	mapObjToItem[pMat] = hParent;
	mapItemToObj[hParent] = pMat;
	
	string strPrefix;
	
	strPrefix = "Ambient = ";
	InsertColorRGB(pMat->Ambient(), strPrefix, hParent);

	strPrefix = "Emissive = ";
	InsertColorRGB(pMat->Emissive(), strPrefix, hParent);

	strPrefix = "Diffuse = ";
	InsertColorRGB(pMat->Diffuse(), strPrefix, hParent);

	strPrefix = "Specular = ";
	InsertColorRGB(pMat->Specular(), strPrefix, hParent);
	
	strPrefix = "Shininess = ";
	InsertFloat(pMat->Shininess(), strPrefix, hParent);

	strPrefix = "Alpha = ";
	InsertFloat(pMat->Alpha(), strPrefix, hParent);
}

void GraphEdit::InsertFloat(float f, const string& strPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];
	sprintf(Buf, "%s %f", strPrefix.c_str(), f);
	HTREEITEM hItem = GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertMatrix3(Matrix3& rMat, const char* acPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];
	sprintf(Buf, "%s %f %f %f %f %f %f %f %f %f", 
			acPrefix, 
			rMat[0][0], rMat[0][1], rMat[0][2],
			rMat[1][0], rMat[1][1], rMat[1][2],
			rMat[2][0], rMat[2][1], rMat[2][2]);
	HTREEITEM hItem = GetTreeCtrl().InsertItem(Buf, hParent);
}


void GraphEdit::InsertAlphaState(AlphaState* pAlpha, HTREEITEM hParent)
{	
	hParent = GetTreeCtrl().InsertItem(MakeName(pAlpha, "Alpha State: "), hParent);	
	mapItemToObj[hParent] = pAlpha;
	mapObjToItem[pAlpha] = hParent;
	InsertBool(pAlpha->BlendEnabled(), "BlendEnabled: ", hParent);
	GetTreeCtrl().InsertItem(MakeName(pAlpha->SrcBlend(), "SrcBlend: ").c_str(), hParent);
	GetTreeCtrl().InsertItem(MakeName(pAlpha->DstBlend(), "DstBlend: ").c_str(), hParent);
	InsertBool(pAlpha->TestEnabled(), "TestEnabled: ", hParent);
	GetTreeCtrl().InsertItem(MakeName(pAlpha->Test(), "Test: ").c_str(), hParent);
	InsertFloat(pAlpha->Reference(), "Reference: ", hParent);
}

void GraphEdit::InsertSpatial(Spatial* pSpat, HTREEITEM hParent)
{
	char Buf[STRLEN];
	
	sprintf(Buf, "Rotate = ");
	InsertMatrix3(pSpat->Rotate(), Buf, hParent);

	sprintf(Buf, "Translate = ");
	InsertVector3(pSpat->Translate(), Buf, hParent);

	sprintf(Buf, "Scale = ");
	InsertFloat(pSpat->Scale(), Buf, hParent);

	sprintf(Buf, "WorldRotate = ");
	InsertMatrix3(pSpat->WorldRotate(), Buf, hParent);

	sprintf(Buf, "WorldTranslate = ");
	InsertVector3(pSpat->WorldTranslate(), Buf, hParent);

	sprintf(Buf, "WorldScale = ");
	InsertFloat(pSpat->WorldScale(), Buf, hParent);

	sprintf(Buf, "ForceCull = ");
	InsertBool(pSpat->ForceCull(), Buf, hParent);
}

void GraphEdit::InsertBumpMapNode(BumpMap* pBump, HTREEITEM hParent)
{
	InsertTextureState(pBump->GetTextureState(), hParent);
	InsertTexture(pBump->GetNormalMap(), hParent);
	InsertLight(pBump->GetLight(), hParent);
	InsertAlphaState(pBump->GetAlphaState(), hParent);	
	InsertNodes(pBump, hParent);	
}

void GraphEdit::InsertNodes(Node* pNode, HTREEITEM hParent)
{
	const RTTI* pRTTI = pNode->GetRTTI();
	InsertSpatial(pNode, hParent);
	
	//insert the children - first insert render states	
	InsertRenderState(pNode, hParent);
	//insert the child controllers
	Controller* pCont = pNode->GetControllers();
	if (pCont)
		InsertController(pCont, hParent);
	
	//then insert spatial objects
	int i, n = pNode->GetQuantity();
	for (i = 0; i < n; i++)
	{			
		if (MgcIsDerivedFromClass(Node, (pNode->GetChild(i))))
		{
			BumpMap* pBump;
			if (pBump = MgcDynamicCast(BumpMap, (pNode->GetChild(i))))
			{				
				pRTTI = pBump->GetRTTI();
				HTREEITEM hParent1 = GetTreeCtrl().InsertItem(MakeName(pBump, pRTTI->GetName()), hParent);
				mapObjToItem[pBump] = hParent1;
				mapItemToObj[hParent1] = pBump;
				InsertBumpMapNode(pBump, hParent1);
			}
			else
			{
				Node* pNew = MgcDynamicCast(Node, (pNode->GetChild(i)));
				HTREEITEM hParent1 = GetTreeCtrl().InsertItem(MakeName(pNode, pRTTI->GetName()), hParent);
				mapObjToItem[pNew] = hParent1;
				mapItemToObj[hParent1] = pNew;
				InsertNodes(pNew, hParent1);
			}
		}
		else if (MgcIsDerivedFromClass(TriMesh, (pNode->GetChild(i))))
		{
			TriMesh* pNew = MgcDynamicCast(TriMesh, (pNode->GetChild(i)));
			InsertTriMesh(pNew, hParent);	
		}		

	}
}

void GraphEdit::InsertQuaternion(Quaternion& rQuat, const string& strPrefix, HTREEITEM hParent)
{	
	char Buf[STRLEN];	
	sprintf(Buf, "%s %f %f %f %f", strPrefix.c_str(), rQuat.w, rQuat.x, rQuat.y, rQuat.z);
	HTREEITEM hItem = GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertNormals(TriMesh* pMesh, HTREEITEM hParent)
{
	char Buf[STRLEN];
	if (pMesh->Normals())
	{
		int i, n = pMesh->GetVertexQuantity();		
		for (i = 0; i < n; i++)
		{
			sprintf(Buf, "%d = ", i);
			InsertVector3(pMesh->Normal(i), Buf, hParent);
		}
	}
}

void GraphEdit::InsertVertexColors(TriMesh* pMesh, HTREEITEM hParent)
{
	char Buf[STRLEN];
	if (pMesh->Colors())
	{
		int i, n = pMesh->GetVertexQuantity();		
		for (i = 0; i < n; i++)
		{
			sprintf(Buf, "%d = ", i);
			InsertColorRGB(pMesh->Color(i), Buf, hParent);
		}
	}
}

void GraphEdit::InsertVertices(TriMesh* pMesh, HTREEITEM hParent)
{
	int i, n = pMesh->GetVertexQuantity();	
	char Buf[STRLEN];

	for (i = 0; i < n; i++)
	{
		sprintf(Buf, "%d: ", i);
		InsertVector3(pMesh->Vertex(i), Buf, hParent);
	}
}

void GraphEdit::InsertColorRGB(ColorRGB& rCol, const string& strPrefix, HTREEITEM hParent)
{	
	char Buf[STRLEN];
	
	sprintf(Buf, "%s %f %f %f", strPrefix.c_str(), rCol.r, rCol.g, rCol.b);
	GetTreeCtrl().InsertItem(Buf, hParent);	
}

void GraphEdit::InsertConnectivity(TriMesh* pMesh, HTREEITEM hParent)
{
	int i, n = pMesh->GetTriangleQuantity();
	char Buf[STRLEN];
	for (i = 0; i < n; i++)
	{
		sprintf(Buf, "%d %d %d", pMesh->Connectivity()[i*3], pMesh->Connectivity()[i*3+1], pMesh->Connectivity()[i*3+2]);
		GetTreeCtrl().InsertItem(Buf, hParent);
	}
}

void GraphEdit::InsertBool(bool& b, const string& strPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];	
	sprintf(Buf, "%s %d", strPrefix.c_str(), (int)b);	
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertCullState(CullState* pCS, HTREEITEM hParent)
{	
	hParent = GetTreeCtrl().InsertItem(MakeName(pCS, "Cull State: "), hParent);
	mapObjToItem[pCS] = hParent;
	mapItemToObj[hParent] = pCS;
	InsertBool(pCS->Enabled(), "Enabled = ", hParent);
	InsertFrontType(pCS->FrontFace(), "Front Type = ", hParent);
	InsertCullType(pCS->CullFace(), "Cull Face = ", hParent);
}

void GraphEdit::InsertFrontType(CullState::FrontType& ft, const string& strPrefix, HTREEITEM hParent)
{	
	char Buf[STRLEN];	
	sprintf(Buf, "%s %d", strPrefix.c_str(), (int)ft);
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::InsertCullType(CullState::CullType& ct, const string& strPrefix, HTREEITEM hParent)
{
	char Buf[STRLEN];	
	sprintf(Buf, "%s %d", strPrefix.c_str(), ct);
	GetTreeCtrl().InsertItem(Buf, hParent);
}

void GraphEdit::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	TRACE("DblClick\n");	
	CFormView::OnLButtonDblClk(nFlags, point);
}

void GraphEdit::OnRclickTreeGraph(NMHDR* pNMHDR, LRESULT* pResult) 
{	
	/*CMenu Menu;
	Menu.LoadMenu(IDR_MENU_GRAPHEDIT);
	CMenu* pMenu = Menu.GetSubMenu(0);
	HTREEITEM hSel = GetTreeCtrl().GetSelectedItem();
	RECT Rect;
	GetTreeCtrl().GetItemRect(hSel, &Rect, TRUE);
	CPoint Point;
	Point.x = Rect.left;
	Point.y = Rect.top;
	ClientToScreen(&Point);
	pMenu->TrackPopupMenu(TPM_LEFTALIGN, Point.x, Point.y, this);	
	*pResult = 0;*/
}

void GraphEdit::UpdateSpatial(Spatial* pSpatial, HTREEITEM hItem)
{	
	HTREEITEM hChild = GetTreeCtrl().GetChildItem(hItem);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->Rotate(), "Rotate = ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->Translate(), "Translate = ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->Scale(), "Scale = ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->WorldRotate(), "WorldRotate = ").c_str());	

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->WorldTranslate(), "WorldTranslate = ").c_str());	

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->WorldScale(), "WorldScale = ").c_str());	

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pSpatial->ForceCull(), "ForceCull = ").c_str());		
}

void GraphEdit::UpdateAlphaState(AlphaState* pAlpha, HTREEITEM hItem)
{
	HTREEITEM hChild = GetTreeCtrl().GetChildItem(hItem);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->BlendEnabled(), "BlendEnabled: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->SrcBlend(), "SrcBlend: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->DstBlend(), "DstBlend: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->TestEnabled(), "TestEnabled: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->Test(), "Test: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pAlpha->Reference(), "Reference: ").c_str());
}

void GraphEdit::UpdateLight(Light* pLight, HTREEITEM hItem)
{
	HTREEITEM hChild = GetTreeCtrl().GetChildItem(hItem);	
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Attenuate(), "Attenuate: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Constant(), "Constant: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Linear(), "Linear: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Quadratic(), "Quadratic: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->On(), "On: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Intensity(), "Intensity: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Ambient(), "Ambient: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Diffuse(), "Diffuse: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pLight->Specular(), "Specular: ").c_str());
}

void GraphEdit::UpdateMaterial(MaterialState* pMat, HTREEITEM hItem)
{
	HTREEITEM hChild = GetTreeCtrl().GetChildItem(hItem);	
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Ambient(), "Ambient: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Emissive(), "Emissive: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Diffuse(), "Diffuse: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Specular(), "Specular: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Shininess(), "Shininess: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pMat->Alpha(), "Alpha: ").c_str());
}

void GraphEdit::UpdateTexture(Texture* pText, HTREEITEM hItem)
{
	HTREEITEM hChild = GetTreeCtrl().GetChildItem(hItem);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Correction(), "Correction: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Apply(), "Apply: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->BlendColor(), "Blend Color: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->BorderColor(), "Border Color: ").c_str());	

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Wrap(), "Wrap: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Filter(), "Filter: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Envmap(), "EnvMap: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->Priority(), "Priority: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName((int)(pText->UserData()), "User Data: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineFuncRGB(), "CombineFuncRGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineFuncAlpha(), "CombineFuncAlpha: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc0RGB(), "CombineSrc0RGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc1RGB(), "CombineSrc1RGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc2RGB(), "CombineSrc2RGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc0Alpha(), "CombineSrc0Alpha: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc1Alpha(), "CombineSrc1Alpha: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineSrc2Alpha(), "CombineSrc2Alpha: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp0RGB(), "CombineOp0RGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp1RGB(), "CombineOp1RGB: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp2RGB(), "CombineOp2RGB: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp0Alpha(), "CombineOp0Alpha: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp1Alpha(), "CombineOp1Alpha: ").c_str());

	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineOp2Alpha(), "CombineOp2Alpha: ").c_str());
		
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineScaleRGB(), "CombineScaleRGB: ").c_str());
	
	hChild = GetTreeCtrl().GetNextSiblingItem(hChild);
	GetTreeCtrl().SetItemText(hChild, MakeName(pText->CombineScaleAlpha(), "CombineScaleAlpha: ").c_str());	
}

void GraphEdit::ChangeTexture(Texture* pText, HTREEITEM hItem)
{
	CString str = GetTreeCtrl().GetItemText(hItem);
	if (str.Find("CombineFuncRGB") != -1)
	{
		DlgTextureApplyCombineFunction Dlg;	
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);			
		if (it != mapItemToObj.end())
		{		
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACF = pText->CombineFuncRGB();
			if (Dlg.DoModal() == IDOK)
			{	
				pText->CombineFuncRGB() = Dlg.m_eACF;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);				
			}
		}
	}
	else if (str.Find("CombineFuncAlpha") != -1)
	{
		DlgTextureApplyCombineFunction Dlg;	
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);			
		if (it != mapItemToObj.end())
		{		
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACF = pText->CombineFuncAlpha();
			if (Dlg.DoModal() == IDOK)
			{	
				pText->CombineFuncAlpha() = Dlg.m_eACF;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);				
			}
		}
	}
	else if (str.Find("Apply") != -1)
	{
		DlgTextureApplyMode Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);			
		if (it != mapItemToObj.end())
		{		
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eAM = pText->Apply();
			if (Dlg.DoModal() == IDOK)
			{	
				pText->Apply() = Dlg.m_eAM;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);				
			}
		}
	}
	else if (str.Find("CombineSrc0RGB") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc0RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc0RGB() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineSrc1RGB") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc1RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc1RGB() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineSrc2RGB") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc2RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc2RGB() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("Blend Color") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_nRed = pText->BlendColor().r;
			Dlg.m_nGreen= pText->BlendColor().g;
			Dlg.m_nBlue = pText->BlendColor().b;
			if (Dlg.DoModal() == IDOK)
			{
				pText->BlendColor() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("Border Color") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_nRed = pText->BorderColor().r;
			Dlg.m_nGreen= pText->BorderColor().g;
			Dlg.m_nBlue = pText->BorderColor().b;
			if (Dlg.DoModal() == IDOK)
			{
				pText->BorderColor() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineSrc0Alpha") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc0Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc0Alpha() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineSrc1Alpha") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc1Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc1Alpha() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineSrc2Alpha") != -1)
	{
		DlgTextureApplyCombineSource Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACS = pText->CombineSrc2Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineSrc2Alpha() = Dlg.m_eACS;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp0RGB") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp0RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp0RGB() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp1RGB") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp1RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp1RGB() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp2RGB") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp2RGB();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp2RGB() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp0Alpha") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp0Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp0Alpha() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp1Alpha") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp1Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp1Alpha() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
	else if (str.Find("CombineOp2Alpha") != -1)
	{
		DlgTextureApplyCombineOp Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Texture* pText = MgcDynamicCast(Texture, (it->second));
			Dlg.m_eACO = pText->CombineOp2Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pText->CombineOp2Alpha() = Dlg.m_eACO;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pText);		
			}
		}
	}
}

void GraphEdit::ChangeMaterial(MaterialState* pMat, HTREEITEM hItem)
{
	CString str = GetTreeCtrl().GetItemText(hItem);
	if (str.Find("Ambient") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nRed = pMat->Ambient().r;
			Dlg.m_nGreen= pMat->Ambient().g;
			Dlg.m_nBlue = pMat->Ambient().b;
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Ambient() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
	else if (str.Find("Emissive") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nRed = pMat->Emissive().r;
			Dlg.m_nGreen= pMat->Emissive().g;
			Dlg.m_nBlue = pMat->Emissive().b;
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Emissive() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
	else if (str.Find("Diffuse") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nRed = pMat->Diffuse().r;
			Dlg.m_nGreen= pMat->Diffuse().g;
			Dlg.m_nBlue = pMat->Diffuse().b;
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Diffuse() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
	else if (str.Find("Specular") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nRed = pMat->Specular().r;
			Dlg.m_nGreen= pMat->Specular().g;
			Dlg.m_nBlue = pMat->Specular().b;
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Specular() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
	else if (str.Find("Shininess") != -1)
	{
		DlgFloat Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nVal = pMat->Shininess();
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Shininess() = Dlg.m_nVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
	else if (str.Find("Alpha") != -1)
	{
		DlgFloat Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			MaterialState* pMat = MgcDynamicCast(MaterialState, (it->second));
			Dlg.m_nVal = pMat->Alpha();
			if (Dlg.DoModal() == IDOK)
			{
				pMat->Alpha() = Dlg.m_nVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pMat);		
			}
		}
	}
}

void GraphEdit::ChangeAlphaState(AlphaState* pAlpha, HTREEITEM hItem)
{
	CString str = GetTreeCtrl().GetItemText(hItem);
	if (str.Find("SrcBlend") != -1)
	{
		DlgAlphaStateSrcBlendFunc Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_eSBF = pAlpha->SrcBlend();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->SrcBlend() = Dlg.m_eSBF;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);		
			}
		}		
	}
	else if (str.Find("BlendEnabled") != -1) 
	{
		DlgBoolean Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_bVal = pAlpha->BlendEnabled();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->BlendEnabled() = Dlg.m_bVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);
			}
		}
	}
	else if (str.Find("DstBlend") != -1) 
	{
		DlgAlphaStateDstBlendFunc Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_eDBF = pAlpha->DstBlend();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->DstBlend() = Dlg.m_eDBF;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);		
			}
		}		
	}
	else if (str.Find("TestEnabled") != -1) 
	{
		DlgBoolean Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_bVal = pAlpha->TestEnabled();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->TestEnabled() = Dlg.m_bVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);
			}
		}
	}
	else if (str.Find("Test") != -1) 
	{
		DlgAlphaStateTestFunc Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_eTF = pAlpha->Test();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->Test() = Dlg.m_eTF;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);		
			}
		}		
	}
	else if (str.Find("Reference") != -1) 
	{
		DlgFloat Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			AlphaState* pAlpha = MgcDynamicCast(AlphaState, (it->second));
			Dlg.m_nVal = pAlpha->Reference();
			if (Dlg.DoModal() == IDOK)
			{
				pAlpha->Reference() = Dlg.m_nVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pAlpha);		
			}
		}
	}
}

void GraphEdit::ChangeLight(Light* pLight, HTREEITEM hItem)
{
	CString str = GetTreeCtrl().GetItemText(hItem);
	if (str.Find("Ambient") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Light* pLight = MgcDynamicCast(Light, (it->second));
			Dlg.m_nRed = pLight->Ambient().r;
			Dlg.m_nGreen= pLight->Ambient().g;
			Dlg.m_nBlue = pLight->Ambient().b;
			if (Dlg.DoModal() == IDOK)
			{
				pLight->Ambient() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pLight);		
			}
		}
	}
	else if (str.Find("Diffuse") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Light* pLight = MgcDynamicCast(Light, (it->second));
			Dlg.m_nRed = pLight->Diffuse().r;
			Dlg.m_nGreen= pLight->Diffuse().g;
			Dlg.m_nBlue = pLight->Diffuse().b;
			if (Dlg.DoModal() == IDOK)
			{
				pLight->Diffuse() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pLight);		
			}
		}
	}	
	else if (str.Find("Specular") != -1)
	{
		DlgColorRGB Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Light* pLight = MgcDynamicCast(Light, (it->second));
			Dlg.m_nRed = pLight->Specular().r;
			Dlg.m_nGreen= pLight->Specular().g;
			Dlg.m_nBlue = pLight->Specular().b;
			if (Dlg.DoModal() == IDOK)
			{
				pLight->Specular() = ColorRGB(Dlg.m_nRed, Dlg.m_nGreen, Dlg.m_nBlue);
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pLight);		
			}
		}
	}	
	else if (str.Find("On") != -1)
	{
		DlgBoolean Dlg;
		map<HTREEITEM, Object*>::iterator it;
		HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
		it = mapItemToObj.find(hParent);
		if (it != mapItemToObj.end())
		{
			Light* pLight = MgcDynamicCast(Light, (it->second));
			Dlg.m_bVal = pLight->On();
			if (Dlg.DoModal() == IDOK)
			{
				pLight->On() = Dlg.m_bVal;
				WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
				pDoc->UpdateAllViews(NULL, (LPARAM)pLight);		
			}
		}
	}	

}

void GraphEdit::OnEditChange() 
{	
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();	
	HTREEITEM hParent = GetTreeCtrl().GetParentItem(hItem);
	map<HTREEITEM, Object*>::iterator it = mapItemToObj.find(hParent);
	
	if (it != mapItemToObj.end())
	{	
		Texture* pText;
		MaterialState* pMat;
		Light* pLight;
		AlphaState* pAlpha;
		Spatial* pSpatial;
		
		if (pText = MgcDynamicCast(Texture, (it->second)))
		{		
			ChangeTexture(pText, hItem);

		}
		else if (pMat = MgcDynamicCast(MaterialState, (it->second)))
		{
			ChangeMaterial(pMat, hItem);
		}
		else if (pLight = MgcDynamicCast(Light, (it->second)))
		{
			ChangeLight(pLight, hItem);
		}
		else if (pAlpha = MgcDynamicCast(AlphaState, (it->second)))
		{
			ChangeAlphaState(pAlpha, hItem);
		}
		else if (pSpatial = MgcDynamicCast(Spatial, (it->second)))
		{
			ChangeSpatial(pSpatial, hItem);
		}
	}
}

void GraphEdit::ChangeSpatial(Spatial* pSpatial, HTREEITEM hItem)
{
	CString str = GetTreeCtrl().GetItemText(hItem);
	if (str.Find("Translate =") != -1)
	{
		DlgVector3 Dlg;
		Dlg.m_x = pSpatial->Translate().x;
		Dlg.m_y = pSpatial->Translate().y;
		Dlg.m_z = pSpatial->Translate().z;
		if (Dlg.DoModal() == IDOK)
		{
			pSpatial->Translate().x = Dlg.m_x;
			pSpatial->Translate().y = Dlg.m_y;
			pSpatial->Translate().z = Dlg.m_z;
			pSpatial->UpdateGS(0.0f);
			WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();			
			pDoc->UpdateAllViews(NULL, (LPARAM)pSpatial);
		}		
	}
	if (str.Find("ForceCull =") != -1)
	{
		DlgBoolean Dlg;
		Dlg.m_bVal = pSpatial->ForceCull();
		if (Dlg.DoModal() == IDOK)
		{
			pSpatial->ForceCull() = Dlg.m_bVal;
			WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();			
			pDoc->UpdateAllViews(NULL, (LPARAM)pSpatial);
		}
	}	
}

void GraphEdit::OnEditCopy() 
{
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
	map<HTREEITEM, Object*>::iterator it;
	
	it = mapItemToObj.find(hItem);
	if (it != mapItemToObj.end())
	{
		Spatial* pSpatial;
		if (pSpatial = MgcDynamicCast(Spatial, (it->second)))
		{
			m_pCopy = pSpatial;
		}
	}
}

void GraphEdit::OnEditCut() 
{
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
	map<HTREEITEM, Object*>::iterator it;
	
	it = mapItemToObj.find(hItem);
	if (it != mapItemToObj.end())
	{
		Spatial* pSpatial;
		if (pSpatial = MgcDynamicCast(Spatial, (it->second)))
		{		
			m_pCut = pSpatial;
		}
	}
}

void GraphEdit::OnEditDelete() 
{	
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
	map<HTREEITEM, Object*>::iterator it;

	it = mapItemToObj.find(hItem);
	Object* pObj = it->second;
	if (it != mapItemToObj.end())
	{
		Texture* pText;
		MaterialState* pMat;
		Node* pNode;
		Light* pLight;
		if (pText = MgcDynamicCast(Texture, pObj))
		{
			TextureState* pTS;
			HTREEITEM hParent;
			hParent = GetTreeCtrl().GetParentItem(hItem);
			it = mapItemToObj.find(hParent);
			if (it != mapItemToObj.end())
			{
				pTS = (TextureState*)it->second;
				int i, n = pTS->GetQuantity();
				for (i = 0; i < n; i++)
				{
					if (pText == pTS->Get(i))
					{
						pTS->Remove(i);
						GetTreeCtrl().DeleteItem(hItem);
						mapItemToObj.erase(hItem);
						mapObjToItem.erase(pText);
						break;
					}
				}
			}
		}
		else if (pMat = MgcDynamicCast(MaterialState, pObj))		
		{
			HTREEITEM hParent;
			hParent = GetTreeCtrl().GetParentItem(hItem);
			it = mapItemToObj.find(hParent);
			if (it != mapItemToObj.end())
			{
				Spatial* pSpatial = MgcDynamicCast(Spatial, (it->second));
				pSpatial->RemoveRenderState(RenderState::Type::RS_MATERIAL);
				GetTreeCtrl().DeleteItem(hItem);
				mapItemToObj.erase(hItem);
				mapObjToItem.erase(pMat);
			}
		}
		else if (pLight = MgcDynamicCast(Light, pObj))
		{
			HTREEITEM hParent;
			hParent = GetTreeCtrl().GetParentItem(hItem);
			it = mapItemToObj.find(hParent);
			if (it != mapItemToObj.end())
			{
				LightState* pLState = MgcDynamicCast(LightState, (it->second));
				pLState->Detach(pLight);
				GetTreeCtrl().DeleteItem(hItem);
				mapItemToObj.erase(hItem);
				mapObjToItem.erase(pMat);
			}
		}
		else if (pNode = MgcDynamicCast(Node, pObj))
		{
			HTREEITEM hParent;
			hParent = GetTreeCtrl().GetParentItem(hItem);
			it = mapItemToObj.find(hParent);
			if (it != mapItemToObj.end())
			{
				Node* pParent = MgcDynamicCast(Node, (it->second));
				pParent->DetachChild(pNode);
				GetTreeCtrl().DeleteItem(hItem);
				mapItemToObj.erase(hItem);
				mapObjToItem.erase(pMat);
			}
		}
	}
	WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
	pDoc->GetScene()->UpdateGS(0.0f);
	pDoc->GetScene()->UpdateRS();
	pDoc->UpdateAllViews(NULL);
}

void GraphEdit::OnEditPaste() 
{
	if (m_pCut)
	{
		HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
		map<HTREEITEM, Object*>::iterator it;
		it = mapItemToObj.find(hItem);
		if (it != mapItemToObj.end())
		{		
			Node* pNode;
			if (pNode = MgcDynamicCast(Node, (it->second)))
			{				
				MoveSpatial(pNode, m_pCut);
				pNode->UpdateRS();
				pNode->UpdateGS(0.0f);
				map<Object*, HTREEITEM>::iterator it1;
				it1 = mapObjToItem.find(m_pCut);
				if (it1 != mapObjToItem.end())
				{
					GetTreeCtrl().DeleteItem(it1->second);
					TriMesh* pTriMesh;
					if (pTriMesh = MgcDynamicCast(TriMesh, m_pCut))
					{						
						InsertTriMesh(pTriMesh, hItem);	
					}												
				}
			}
		}
		m_pCut = NULL;
	}
	else if (m_pCopy)
	{
		HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
		map<HTREEITEM, Object*>::iterator it;
		it = mapItemToObj.find(hItem);
		if (it != mapItemToObj.end())
		{		
			Node* pNode;
			if (pNode = MgcDynamicCast(Node, (it->second)))
			{						
				/*if (MgcIsExactlyClass(TriMesh, m_pCopy))
				{
					TriMeshPtr pTriMesh(new TriMesh(0, 0, 0, 0, 0, 0, 0));
					CopyTriMesh(pTriMesh, MgcDynamicCast(TriMesh, m_pCopy));
					pNode->AttachChild(pTriMesh);
					pNode->UpdateRS();
					pNode->UpdateGS(0.0f);
					InsertTriMesh(pTriMesh, hItem);
				}*/
				Node* pTo;
				CopyNode(pTo, MgcDynamicCast(Node, m_pCopy));
				pNode->AttachChild(pTo);
				pNode->UpdateGS(0.0f);
				pNode->UpdateRS();
				const RTTI* pRTTI = pTo->GetRTTI();
				HTREEITEM hChild = GetTreeCtrl().InsertItem(MakeName(pTo, pRTTI->GetName()), hItem);
				mapObjToItem[pTo] = hChild;
				mapItemToObj[hChild] = pTo;
				InsertNodes(pTo, hChild);																
			}
		}
		m_pCopy = NULL;
	}	
}

void GraphEdit::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	Object* pObj = (Object*)lHint;
	Texture* pText;
	MaterialState* pMat;
	Light* pLight;
	AlphaState* pAlpha;
	Spatial* pSpatial;

	if (pText = MgcDynamicCast(Texture, pObj))
	{		
		map<Object*, HTREEITEM>::iterator it;
		it = mapObjToItem.find(pObj);
		UpdateTexture(pText, it->second);
	}
	else if (pMat = MgcDynamicCast(MaterialState, pObj))
	{
		map<Object*, HTREEITEM>::iterator it;
		it = mapObjToItem.find(pObj);
		UpdateMaterial(pMat, it->second);
	}
	else if (pLight = MgcDynamicCast(Light, pObj))
	{
		map<Object*, HTREEITEM>::iterator it;
		it = mapObjToItem.find(pObj);
		UpdateLight(pLight, it->second);
	}
	else if (pAlpha = MgcDynamicCast(AlphaState, pObj))
	{
		map<Object*, HTREEITEM>::iterator it;
		it = mapObjToItem.find(pObj);
		UpdateAlphaState(pAlpha, it->second);
	}
	else if (pSpatial = MgcDynamicCast(Spatial, pObj))
	{
		map<Object*, HTREEITEM>::iterator it;
		it = mapObjToItem.find(pObj);
		ASSERT(it != mapObjToItem.end());
		UpdateSpatial(pSpatial, it->second);
	}
}

void GraphEdit::OnDblclkTreeGraph(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEditChange();
	*pResult = 0;
}

void GraphEdit::OnEditAddTexture() 
{
	HTREEITEM hParent = GetTreeCtrl().GetSelectedItem();
	map<HTREEITEM, Object*>::iterator it;

	it = mapItemToObj.find(hParent);
	if (it != mapItemToObj.end())
	{
		Object* pObj = it->second;
		TextureState* pTextState;
		if (pTextState = MgcDynamicCast(TextureState, pObj))
		{
			//assume the texturestate belongs to a trimesh
			HTREEITEM hTriMesh = GetTreeCtrl().GetParentItem(hParent);
			it = mapItemToObj.find(hTriMesh);
			TriMesh* pTriMesh = MgcDynamicCast(TriMesh, (it->second));
			int nQuantity = pTextState->GetQuantity();
			if (nQuantity < TextureState::MAX_TEXTURES)
			{			
				CFileDialog Dlg(TRUE, "mif");
				if (Dlg.DoModal() == IDOK)
				{
					Texture* pText = new Texture;				
					Image* pImage = Image::Load(Dlg.GetPathName());
					pText->SetImage(pImage);
					pText->Apply() = Mgc::Texture::ApplyMode::AM_MODULATE;
					pText->Filter() = Mgc::Texture::FM_LINEAR;
					pText->Mipmap() = Mgc::Texture::MM_LINEAR;
					pText->Wrap() = Mgc::Texture::WM_WRAP_S_WRAP_T;
					pTextState->Set(nQuantity, pText);
					InsertTexture(pText, hParent);

					//reconstruct the trimesh with the uv coordinates from the 1st texture
					if (pTextState->GetQuantity() == 2)
					{
						Vector2* aText1 = new Vector2[pTriMesh->GetVertexQuantity()];
						memcpy(aText1, pTriMesh->Textures(), pTriMesh->GetVertexQuantity() * sizeof(Vector2));
						pTriMesh->Reconstruct(pTriMesh->GetVertexQuantity(), pTriMesh->Vertices(), pTriMesh->Normals(),
											  pTriMesh->Colors(), pTriMesh->Textures(), pTriMesh->GetTriangleQuantity(), 
											  pTriMesh->Connectivity(), aText1, pTriMesh->Textures2(),
											  pTriMesh->Textures3(), pTriMesh->TexturesBump());
					}
					else if (pTextState->GetQuantity() == 3)
					{
						Vector2* aText2 = new Vector2[pTriMesh->GetVertexQuantity()];
						memcpy(aText2, pTriMesh->Textures1(), pTriMesh->GetVertexQuantity() * sizeof(Vector2));
						pTriMesh->Reconstruct(pTriMesh->GetVertexQuantity(), pTriMesh->Vertices(), pTriMesh->Normals(),
											  pTriMesh->Colors(), pTriMesh->Textures(), pTriMesh->GetTriangleQuantity(), 
											  pTriMesh->Connectivity(), pTriMesh->Textures1(), aText2,
											  pTriMesh->Textures3(), pTriMesh->TexturesBump());
					}
					else if (pTextState->GetQuantity() == 4)
					{
						Vector2* aText3 = new Vector2[pTriMesh->GetVertexQuantity()];
						memcpy(aText3, pTriMesh->Textures2(), pTriMesh->GetVertexQuantity() * sizeof(Vector2));
						pTriMesh->Reconstruct(pTriMesh->GetVertexQuantity(), pTriMesh->Vertices(), pTriMesh->Normals(),
											  pTriMesh->Colors(), pTriMesh->Textures(), pTriMesh->GetTriangleQuantity(), 
											  pTriMesh->Connectivity(), pTriMesh->Textures1(), pTriMesh->Textures2(),
											  aText3, pTriMesh->TexturesBump());
					}
					pTriMesh->UpdateRS();
					pTriMesh->UpdateGS(0.0f);
				}
			}
		}
		WMSceneViewerDoc* pDoc = (WMSceneViewerDoc*)GetDocument();
		pDoc->UpdateAllViews(NULL);
	}
}

void GraphEdit::OnEditAddAlphaState() 
{
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
	map<HTREEITEM, Object*>::iterator it;
	it = mapItemToObj.find(hItem);
	Spatial* pSpatial;
	if (pSpatial = MgcDynamicCast(Spatial, (it->second)))
	{
		AlphaState* pAlpha = new AlphaState;
		pSpatial->SetRenderState(pAlpha);
		InsertAlphaState(pAlpha, hItem);
		pSpatial->UpdateRS();
		pSpatial->UpdateGS(0.0f);
	}
}

