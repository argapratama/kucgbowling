// DlgBoolean.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgBoolean.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgBoolean dialog


DlgBoolean::DlgBoolean(CWnd* pParent /*=NULL*/)
	: CDialog(DlgBoolean::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgBoolean)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgBoolean::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgBoolean)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgBoolean, CDialog)
	//{{AFX_MSG_MAP(DlgBoolean)
	ON_BN_CLICKED(IDC_RADIO_TRUE, OnRadioTrue)
	ON_BN_CLICKED(IDC_RADIO_FALSE, OnRadioFalse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgBoolean message handlers


void DlgBoolean::OnRadioTrue() 
{	
	m_bVal = true;		
}

void DlgBoolean::OnRadioFalse() 
{
	m_bVal = false;	
}
