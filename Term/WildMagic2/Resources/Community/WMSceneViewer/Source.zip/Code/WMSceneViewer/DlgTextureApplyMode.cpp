// DlgTextureApplyMode.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgTextureApplyMode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyMode dialog

using Texture::ApplyMode;


DlgTextureApplyMode::DlgTextureApplyMode(CWnd* pParent /*=NULL*/)
	: CDialog(DlgTextureApplyMode::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgTextureApplyMode)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgTextureApplyMode::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgTextureApplyMode)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgTextureApplyMode, CDialog)
	//{{AFX_MSG_MAP(DlgTextureApplyMode)
	ON_BN_CLICKED(IDC_RADIO_REPLACE, OnRadioReplace)
	ON_BN_CLICKED(IDC_RADIO_DECAL, OnRadioDecal)
	ON_BN_CLICKED(IDC_RADIO_MODULATE, OnRadioModulate)
	ON_BN_CLICKED(IDC_RADIO_BLEND, OnRadioBlend)
	ON_BN_CLICKED(IDC_RADIO_ADD, OnRadioAdd)
	ON_BN_CLICKED(IDC_RADIO_COMBINE, OnRadioCombine)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyMode message handlers

void DlgTextureApplyMode::OnRadioReplace() 
{
	m_eAM = ApplyMode::AM_REPLACE;
}

void DlgTextureApplyMode::OnRadioDecal() 
{
	m_eAM = ApplyMode::AM_DECAL;	
}

void DlgTextureApplyMode::OnRadioModulate() 
{
	m_eAM = ApplyMode::AM_MODULATE;		
}

void DlgTextureApplyMode::OnRadioBlend() 
{
	m_eAM = ApplyMode::AM_BLEND;		
}

void DlgTextureApplyMode::OnRadioAdd() 
{
	m_eAM = ApplyMode::AM_ADD;	
}

void DlgTextureApplyMode::OnRadioCombine() 
{
	m_eAM = ApplyMode::AM_COMBINE;
}
