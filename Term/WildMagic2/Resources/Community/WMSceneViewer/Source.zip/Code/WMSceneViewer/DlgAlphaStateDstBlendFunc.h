#if !defined(AFX_DLGALPHASTATEDSTBLENDFUNC_H__C4DC8DD6_28BC_473D_A8BD_A7A43A13ADF7__INCLUDED_)
#define AFX_DLGALPHASTATEDSTBLENDFUNC_H__C4DC8DD6_28BC_473D_A8BD_A7A43A13ADF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlphaStateDstBlendFunc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateDstBlendFunc dialog

class DlgAlphaStateDstBlendFunc : public CDialog
{
// Construction
public:
	DlgAlphaStateDstBlendFunc(CWnd* pParent = NULL);   // standard constructor
	AlphaState::DstBlendFunction m_eDBF;

// Dialog Data
	//{{AFX_DATA(DlgAlphaStateDstBlendFunc)
	enum { IDD = IDD_ALPHASTATE_DST_BLEND_FUNC };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgAlphaStateDstBlendFunc)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgAlphaStateDstBlendFunc)
	afx_msg void OnRadioZero();
	afx_msg void OnRadioOne();
	afx_msg void OnRadioSrcColor();
	afx_msg void OnRadioOneMinusSrcColor();
	afx_msg void OnRadioSrcAlpha();
	afx_msg void OnRadioOneMinusSrcAlpha();
	afx_msg void OnRadioDstAlpha();
	afx_msg void OnRadioOneMinusDstAlpha();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALPHASTATEDSTBLENDFUNC_H__C4DC8DD6_28BC_473D_A8BD_A7A43A13ADF7__INCLUDED_)
