// DlgTextureApplyCombineOp.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgTextureApplyCombineOp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineOp dialog


DlgTextureApplyCombineOp::DlgTextureApplyCombineOp(CWnd* pParent /*=NULL*/)
	: CDialog(DlgTextureApplyCombineOp::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgTextureApplyCombineOp)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgTextureApplyCombineOp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgTextureApplyCombineOp)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgTextureApplyCombineOp, CDialog)
	//{{AFX_MSG_MAP(DlgTextureApplyCombineOp)
	ON_BN_CLICKED(IDC_RADIO_SRC_COLOR, OnRadioSrcColor)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_SRC_COLOR, OnRadioOneMinusSrcColor)
	ON_BN_CLICKED(IDC_RADIO_SRC_ALPHA, OnRadioSrcAlpha)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_SRC_ALPHA, OnRadioOneMinusSrcAlpha)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineOp message handlers

void DlgTextureApplyCombineOp::OnRadioSrcColor() 
{
	m_eACO = Texture::ACO_SRC_COLOR;
}

void DlgTextureApplyCombineOp::OnRadioOneMinusSrcColor() 
{
	m_eACO = Texture::ACO_ONE_MINUS_SRC_COLOR;	
}

void DlgTextureApplyCombineOp::OnRadioSrcAlpha() 
{
	m_eACO = Texture::ACO_SRC_ALPHA;
}

void DlgTextureApplyCombineOp::OnRadioOneMinusSrcAlpha() 
{
	m_eACO = Texture::ACO_ONE_MINUS_SRC_ALPHA;	
}
