// DlgAlphaStateTestFunc.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgAlphaStateTestFunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateTestFunc dialog


DlgAlphaStateTestFunc::DlgAlphaStateTestFunc(CWnd* pParent /*=NULL*/)
	: CDialog(DlgAlphaStateTestFunc::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgAlphaStateTestFunc)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgAlphaStateTestFunc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgAlphaStateTestFunc)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgAlphaStateTestFunc, CDialog)
	//{{AFX_MSG_MAP(DlgAlphaStateTestFunc)
	ON_BN_CLICKED(IDC_RADIO_NEVER, OnRadioNever)
	ON_BN_CLICKED(IDC_RADIO_LESS, OnRadioLess)
	ON_BN_CLICKED(IDC_RADIO_EQUAL, OnRadioEqual)
	ON_BN_CLICKED(IDC_RADIO_LEQUAL, OnRadioLequal)
	ON_BN_CLICKED(IDC_RADIO_GREATER, OnRadioGreater)
	ON_BN_CLICKED(IDC_RADIO_GEQUAL, OnRadioGequal)
	ON_BN_CLICKED(IDC_RADIO_NOT_EQUAL, OnRadioNotEqual)
	ON_BN_CLICKED(IDC_RADIO_ALWAYS, OnRadioAlways)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateTestFunc message handlers

void DlgAlphaStateTestFunc::OnRadioNever() 
{
	m_eTF = AlphaState::TF_NEVER;
}

void DlgAlphaStateTestFunc::OnRadioLess() 
{
	m_eTF = AlphaState::TF_LESS;	
}

void DlgAlphaStateTestFunc::OnRadioEqual() 
{
	m_eTF = AlphaState::TF_EQUAL;		
}

void DlgAlphaStateTestFunc::OnRadioLequal() 
{
	m_eTF = AlphaState::TF_LEQUAL;	
}

void DlgAlphaStateTestFunc::OnRadioGreater() 
{
	m_eTF = AlphaState::TF_GREATER;		
}

void DlgAlphaStateTestFunc::OnRadioGequal() 
{
	m_eTF = AlphaState::TF_GEQUAL;		
}

void DlgAlphaStateTestFunc::OnRadioNotEqual() 
{
	m_eTF = AlphaState::TF_NOTEQUAL;
}

void DlgAlphaStateTestFunc::OnRadioAlways() 
{
	m_eTF = AlphaState::TF_ALWAYS;
}
