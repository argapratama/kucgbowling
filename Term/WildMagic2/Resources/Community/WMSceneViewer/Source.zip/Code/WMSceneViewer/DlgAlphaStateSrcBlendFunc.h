#if !defined(AFX_DLGALPHASTATESRCBLENDFUNC_H__E00E75E1_FD84_4E7D_9B8D_FD7EDC30A1C0__INCLUDED_)
#define AFX_DLGALPHASTATESRCBLENDFUNC_H__E00E75E1_FD84_4E7D_9B8D_FD7EDC30A1C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlphaStateSrcBlendFunc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateSrcBlendFunc dialog

class DlgAlphaStateSrcBlendFunc : public CDialog
{
// Construction
public:
	DlgAlphaStateSrcBlendFunc(CWnd* pParent = NULL);   // standard constructor
	AlphaState::SrcBlendFunction m_eSBF;
	
// Dialog Data
	//{{AFX_DATA(DlgAlphaStateSrcBlendFunc)
	enum { IDD = IDD_ALPHASTATE_SRC_BLEND_FUNC };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgAlphaStateSrcBlendFunc)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgAlphaStateSrcBlendFunc)
	afx_msg void OnRadioZero();
	afx_msg void OnRadioOne();
	afx_msg void OnRadioDstColor();
	afx_msg void OnRadioOneMinusDestColor();
	afx_msg void OnRadioSrcAlphaSaturate();
	afx_msg void OnRadioSrcAlpha();
	afx_msg void OnRadioOneMinusSrcAlpha();
	afx_msg void OnRadioDstAlpha();
	afx_msg void OnRadioOneMinusDstAlpha();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALPHASTATESRCBLENDFUNC_H__E00E75E1_FD84_4E7D_9B8D_FD7EDC30A1C0__INCLUDED_)
