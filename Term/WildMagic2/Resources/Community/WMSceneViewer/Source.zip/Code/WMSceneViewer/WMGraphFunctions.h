#if !defined(WMGRAPHFUNCTIONS_INCLUDED)
#define WMGRAPHFUNCTIONS_INCLUDED


void CopyNode(Node*& pTo, Node* pFrom);
void CopyGeometry(Geometry* pDest, Geometry* pSource);
void CopyMaterialState(MaterialState* pDest, MaterialState* pSource);
void CopyTextureState(TextureState* pDest, TextureState* pSource);
void CopyTexture(Texture* pDest, Texture* pSource);
void CopyRenderState(Spatial* pDest, Spatial* pSource);
void CopyTriMesh(TriMesh* pDest, TriMesh* pSource);
void CopySpatial(Spatial* pDest, Spatial* pSource);
void CopyKeyframeController(KeyframeController* pDest, KeyframeController* pSource);
void CopySkinController(SkinController* pDest, SkinController* pSource);
void CopyController(Controller* pDest, Controller* pSource);
void CopyObject(Object* pDest, Object* pSource);
void MoveSpatial(Node* pTo, Spatial* pFrom);
void DeleteNode(Node* pNode);
Object* FindObjectByID(Object* pObj, int nID);

template <class T>
vector< Pointer<T> > GetChildren(Node* pNode); 
template <class T>
vector< Pointer<T> > GetControllers(Object* pObj);
template <class T>
vector < Pointer <T> > GetTree(Node* pNode);
template <class T>
int CountChildren(Node* pNode);

template <class T>
vector< Pointer<T> > GetChildren<T>(Node* pNode)
{
	vector< Pointer<T> > vec;
	int i, n = pNode->GetQuantity();

	for (i = 0; i < n; i++)
	{
		T* pObj;
		if (pObj = MgcDynamicCast(T, (pNode->GetChild(i))))
		{
			vec.push_back(pObj);
		}
	}
	return vec;
}

template <class T>
vector< Pointer<T> > GetControllers(Object* pObj)
{
	vector< Pointer<T> > vec;	
	Controller* pCont = pObj->GetControllers();	
	T* pToFind;
	while (pCont)
	{
		if (pToFind = MgcDynamicCast(T, pCont))
		{
			vec.push_back(pToFind);
		}
		pCont = pCont->GetNext();
	}	
	return vec;
}

template <class T>
vector < Pointer <T> > GetTree(Node* pNode)
{
	vector < Pointer <T> > vec;
	int i, n = pNode->GetQuantity();	
	
	for (i = 0; i < n; i++)
	{
		T* pType = NULL;
		if ((pType = MgcDynamicCast(T, (pNode->GetChild(i)))) != NULL)
		{
			vec.push_back(pType);
			vector< Pointer<T> > vecTemp = GetTree<T>(pType);
			vec.insert(vec.end(), vecTemp.begin(), vecTemp.end());			
		}
	}
	return vec;
}

template <class T>
int CountChildren(Node* pNode)
{
	int i, n = pNode->GetQuantity();
	int nCount = 0;

	for (i = 0; i < n; i++)
	{
		if (MgcDynamicCast(T, (pNode->GetChild(i))))
		{
			nCount++;
		}
	}
	return nCount;
}


#endif
