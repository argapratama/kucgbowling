// DlgAlphaStateDstBlendFunc.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgAlphaStateDstBlendFunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateDstBlendFunc dialog


DlgAlphaStateDstBlendFunc::DlgAlphaStateDstBlendFunc(CWnd* pParent /*=NULL*/)
	: CDialog(DlgAlphaStateDstBlendFunc::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgAlphaStateDstBlendFunc)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgAlphaStateDstBlendFunc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgAlphaStateDstBlendFunc)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgAlphaStateDstBlendFunc, CDialog)
	//{{AFX_MSG_MAP(DlgAlphaStateDstBlendFunc)
	ON_BN_CLICKED(IDC_RADIO_ZERO, OnRadioZero)
	ON_BN_CLICKED(IDC_RADIO_ONE, OnRadioOne)
	ON_BN_CLICKED(IDC_RADIO_SRC_COLOR, OnRadioSrcColor)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_SRC_COLOR, OnRadioOneMinusSrcColor)
	ON_BN_CLICKED(IDC_RADIO_SRC_ALPHA, OnRadioSrcAlpha)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_SRC_ALPHA, OnRadioOneMinusSrcAlpha)
	ON_BN_CLICKED(IDC_RADIO_DST_ALPHA, OnRadioDstAlpha)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_DST_ALPHA, OnRadioOneMinusDstAlpha)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateDstBlendFunc message handlers

void DlgAlphaStateDstBlendFunc::OnRadioZero() 
{
	m_eDBF = AlphaState::DBF_ZERO;
}

void DlgAlphaStateDstBlendFunc::OnRadioOne() 
{
	m_eDBF = AlphaState::DBF_ONE;
}

void DlgAlphaStateDstBlendFunc::OnRadioSrcColor() 
{
	m_eDBF = AlphaState::DBF_SRC_COLOR;
}

void DlgAlphaStateDstBlendFunc::OnRadioOneMinusSrcColor() 
{
	m_eDBF = AlphaState::DBF_ONE_MINUS_SRC_COLOR;
}

void DlgAlphaStateDstBlendFunc::OnRadioSrcAlpha() 
{
	m_eDBF = AlphaState::DBF_SRC_ALPHA;
}

void DlgAlphaStateDstBlendFunc::OnRadioOneMinusSrcAlpha() 
{
	m_eDBF = AlphaState::DBF_ONE_MINUS_SRC_ALPHA;	
}

void DlgAlphaStateDstBlendFunc::OnRadioDstAlpha() 
{
	m_eDBF = AlphaState::DBF_DST_ALPHA;
}

void DlgAlphaStateDstBlendFunc::OnRadioOneMinusDstAlpha() 
{
	m_eDBF = AlphaState::DBF_ONE_MINUS_DST_ALPHA;	
}
