// DlgVector3.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgVector3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgVector3 dialog


DlgVector3::DlgVector3(CWnd* pParent /*=NULL*/)
	: CDialog(DlgVector3::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgVector3)
	m_x = 0.0f;
	m_y = 0.0f;
	m_z = 0.0f;
	//}}AFX_DATA_INIT
}


void DlgVector3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgVector3)
	DDX_Text(pDX, IDC_EDIT_X, m_x);
	DDX_Text(pDX, IDC_EDIT_Y, m_y);
	DDX_Text(pDX, IDC_EDIT_Z, m_z);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgVector3, CDialog)
	//{{AFX_MSG_MAP(DlgVector3)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgVector3 message handlers
