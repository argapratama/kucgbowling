// DlgColorRGB.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgColorRGB.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgColorRGB dialog


DlgColorRGB::DlgColorRGB(CWnd* pParent /*=NULL*/)
	: CDialog(DlgColorRGB::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgColorRGB)
	m_nBlue = 0.0f;
	m_nGreen = 0.0f;
	m_nRed = 0.0f;
	//}}AFX_DATA_INIT
}


void DlgColorRGB::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgColorRGB)
	DDX_Text(pDX, IDC_EDIT_BLUE, m_nBlue);
	DDX_Text(pDX, IDC_EDIT_GREEN, m_nGreen);
	DDX_Text(pDX, IDC_EDIT_RED, m_nRed);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgColorRGB, CDialog)
	//{{AFX_MSG_MAP(DlgColorRGB)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgColorRGB message handlers
