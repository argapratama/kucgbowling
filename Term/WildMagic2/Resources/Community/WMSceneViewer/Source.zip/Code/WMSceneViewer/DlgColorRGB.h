#if !defined(AFX_DLGCOLORRGB_H__6FE46161_957A_4A15_8D8A_D84DCAF9BE42__INCLUDED_)
#define AFX_DLGCOLORRGB_H__6FE46161_957A_4A15_8D8A_D84DCAF9BE42__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgColorRGB.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgColorRGB dialog

class DlgColorRGB : public CDialog
{
// Construction
public:
	DlgColorRGB(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DlgColorRGB)
	enum { IDD = IDD_COLORRGB };
	float	m_nBlue;
	float	m_nGreen;
	float	m_nRed;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgColorRGB)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgColorRGB)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCOLORRGB_H__6FE46161_957A_4A15_8D8A_D84DCAF9BE42__INCLUDED_)
