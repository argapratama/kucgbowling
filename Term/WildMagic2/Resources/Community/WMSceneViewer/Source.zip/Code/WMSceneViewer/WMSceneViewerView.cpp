// WMSceneViewerView.cpp : implementation of the WMSceneViewerView class
//

#include "stdafx.h"
#include "WMSceneViewer.h"

#include "WMSceneViewerDoc.h"
#include "WMSceneViewerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerView

IMPLEMENT_DYNCREATE(WMSceneViewerView, CView)

BEGIN_MESSAGE_MAP(WMSceneViewerView, CView)
	//{{AFX_MSG_MAP(WMSceneViewerView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerView construction/destruction

WMSceneViewerView::WMSceneViewerView()
{
	// TODO: add construction code here

}

WMSceneViewerView::~WMSceneViewerView()
{
}

BOOL WMSceneViewerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerView drawing

void WMSceneViewerView::OnDraw(CDC* pDC)
{
	WMSceneViewerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	RECT rect;
	GetClientRect(&rect);
	CBrush Brush(RGB(0,0,0));
	//pDC->FillRect(&rect, &Brush);
	Render(pDC->m_hDC);	
}

void WMSceneViewerView::SetRenderer(WglRendererWrap *pRenderer)
{
	m_pRenderer = pRenderer;	
}

void WMSceneViewerView::SetCamera(Camera *pCam)
{
	m_pCamera = pCam;
}

void WMSceneViewerView::SetCameraOrigin(const Vector3& vLoc, const Vector3& vDir, const Vector3& vUp, const Vector3& vLeft)
{
	m_vOrigLoc = vLoc;
	m_vOrigDir = vDir;
	m_vOrigUp = vUp;
	m_vOrigLeft = vLeft;
}

void WMSceneViewerView::ResetCamera()
{
	m_pCamera->SetFrame(m_vOrigLoc, m_vOrigDir, m_vOrigUp, m_vOrigLeft);
	m_pCamera->Update();
}


void WMSceneViewerView::InitCamera()
{
	m_pCamera->SetFrustum(1.0f,1000.0f,-0.55f,0.55f,0.4125f,-0.4125f);
	WMSceneViewerDoc* pDoc = GetDocument();	
	NodePtr pNode = pDoc->GetScene();
	Bound WorldBound = pNode->WorldBound();	
	Vector3 kCLoc(3*WorldBound.Radius(), WorldBound.Center().y, WorldBound.Center().z);
	Vector3 kCLeft(0.0f,-1.0f,0.0f);
	Vector3 kCUp(0.0f,0.0f,1.0f);	
	Vector3 kCDir(-1.0f,0.0f,0.0f);	
	SetCameraOrigin(kCLoc, kCLeft, kCUp, kCDir);
	ResetCamera();	
	m_bCameraInitialized = true;	
}

void WMSceneViewerView::Render(HDC hDC)
{
	WMSceneViewerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
//	TRACE("BeginRender\n");
	if (m_bCameraInitialized)
	{		
		Vector3 v;
		v = m_pCamera->GetLocation();	
		//TRACE("Id = %d, Location == %f %f %f\n", m_pCamera->GetID(), v.x, v.y, v.z);		
		m_pRenderer->SetRenderContext(hDC);
		m_pRenderer->SetBackgroundColor(ColorRGB(0.2f, 0.2f, 0.2f));
		m_pRenderer->ClearBuffers();
		m_pRenderer->BeginScene();
		if ((Node*)pDoc->GetScene() != NULL)
		{
			m_pRenderer->Draw((Node*)pDoc->GetScene());
		}
		char szText[200];
		*szText = 0;
		//sprintf(szText, "%d", m_pCamera->GetID());
		//for some weird reason if the following functions isn't 
		//called the scene isn't shown in when using multiple panes
		m_pRenderer->Draw(0, 0, ColorRGB::WHITE, szText); 
		m_pRenderer->EndScene();
		m_pRenderer->DisplayBackBuffer();
		m_pRenderer->UnsetRenderContext();
	}
	//TRACE("EndRender\n");
}

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerView diagnostics

#ifdef _DEBUG
void WMSceneViewerView::AssertValid() const
{
	CView::AssertValid();
}

void WMSceneViewerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

WMSceneViewerDoc* WMSceneViewerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(WMSceneViewerDoc)));
	return (WMSceneViewerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerView message handlers

void WMSceneViewerView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	WMSceneViewerDoc* pDoc = GetDocument();
	if (pDoc->GetScene())
	{
		InitCamera();
	}
	CClientDC dc(this);
	Render(dc.m_hDC);
}

int WMSceneViewerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	RECT rect;
	GetClientRect(&rect);
	rect.right =  (rect.right == 0)? 10:rect.right;
	rect.bottom =  (rect.bottom == 0)? 10:rect.bottom;

	WglRendererWrap* pRenderer = new WglRendererWrap(m_hWnd, rect.right, rect.bottom);
	SetRenderer(pRenderer);
	
	OpenGLCamera* pCamera = new OpenGLCamera(rect.right, rect.bottom);
	SetCamera(pCamera);
	pRenderer->SetCamera(pCamera);

	return 0;
}

void WMSceneViewerView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CClientDC dc(this);
	Render(dc.m_hDC);	
}

void WMSceneViewerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	if (m_pRenderer != NULL)
	{	
		m_pRenderer->Resize(cx, cy);
		CClientDC dc(this);
		Render(dc.m_hDC);
	}	
}

void WMSceneViewerView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == VK_LEFT)
	{
		RotateCamera(1, 0);
		GetDocument()->UpdateAllViews(NULL);
	}
	if (nChar == VK_RIGHT)
	{
		RotateCamera(-1, 0);
		GetDocument()->UpdateAllViews(NULL);
	}
	if (nChar == VK_UP)
	{
		RotateCamera(0, 1);
		GetDocument()->UpdateAllViews(NULL);
	}
	if (nChar == VK_DOWN)
	{
		RotateCamera(0, -1);
		GetDocument()->UpdateAllViews(NULL);
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void WMSceneViewerView::RotateCamera(int dx, int dy)
{
	Vector3 vLoc(m_pCamera->GetLocation());
	Matrix3 RotY, RotX;		
	
	RotX.FromAxisAngle(m_pCamera->GetUp(), dx * 0.0174f);//1 degree	
	RotY.FromAxisAngle(m_pCamera->GetLeft(), dy*0.0174);//1 degree	
	
	vLoc = RotX*RotY*vLoc;	
	Vector3 vLookAt(0, m_vOrigLoc.y, m_vOrigLoc.z);
	Vector3 vDir(vLookAt - vLoc);
	vDir.Unitize();
	Vector3 vLeft(m_pCamera->GetUp().UnitCross(vDir));
	Vector3 vUp(vDir.UnitCross(vLeft));
	m_pCamera->SetFrame(vLoc, vLeft, vUp, vDir);
	m_pCamera->Update();	
}

