// WMSceneViewerDoc.cpp : implementation of the WMSceneViewerDoc class
//

#include "stdafx.h"
#include "WMSceneViewer.h"

#include "WMSceneViewerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerDoc

IMPLEMENT_DYNCREATE(WMSceneViewerDoc, CDocument)

BEGIN_MESSAGE_MAP(WMSceneViewerDoc, CDocument)
	//{{AFX_MSG_MAP(WMSceneViewerDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerDoc construction/destruction

WMSceneViewerDoc::WMSceneViewerDoc()
{
	// TODO: add one-time construction code here

}

WMSceneViewerDoc::~WMSceneViewerDoc()
{
}

BOOL WMSceneViewerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerDoc serialization

void WMSceneViewerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerDoc diagnostics

#ifdef _DEBUG
void WMSceneViewerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void WMSceneViewerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerDoc commands


BOOL WMSceneViewerDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	// TODO: Add your specialized code here and/or call the base class
	//strip unnecessary nodes like movetool, rotate tool etc
	m_pScene->UpdateGS(0);
	m_pScene->UpdateRS();

	Stream kStream;
	kStream.Insert(m_pScene);	
	kStream.Save(lpszPathName);	
	CString strPath(lpszPathName);
	int n = strPath.ReverseFind('.');
	strPath.Delete(strPath.Find('.'), strPath.GetLength() - n);
	strPath += ".txt";
	kStream.SaveText(strPath);
	return TRUE;
}

BOOL WMSceneViewerDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	Stream kStream;
	//change the current directory to the path that the model is in. assuems that the textures
	//are in the same directory.
	char CurDir[256];
	GetCurrentDirectory(256, CurDir);
	CString strPathName(lpszPathName);
	int n;
	n = strPathName.ReverseFind('\\');
	strPathName.Delete(n, strPathName.GetLength() - n);
	SetCurrentDirectory(strPathName);
    bool bLoaded = kStream.Load(lpszPathName);		
	SetCurrentDirectory(CurDir);

    if (!bLoaded)
        return FALSE;
	
	m_pScene = (Node*)kStream.GetObjectAt(0);
	m_pScene->UpdateGS(0.0f);
    m_pScene->UpdateRS();	
		
//	UpdateAllViews(NULL);

	//force a full window repaint instead of a render only (which is what UpdateAllViews would do)
	POSITION pos = GetFirstViewPosition();
	while (pos != NULL)
	{
		CView* pView = GetNextView(pos);
//		if (pView->IsKindOf(RUNTIME_CLASS(WMSceneViewerView)))
		{
			pView->Invalidate(TRUE);
		}			
	}   
	

	return TRUE;
}
