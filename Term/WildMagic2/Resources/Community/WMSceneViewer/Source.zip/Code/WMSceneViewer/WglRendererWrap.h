// WglRendererWrap.h: interface for the WglRendererWrap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WGLRENDERERWRAP_H__9B75A089_0D0E_4943_BF85_7D68D9CE63EC__INCLUDED_)
#define AFX_WGLRENDERERWRAP_H__9B75A089_0D0E_4943_BF85_7D68D9CE63EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MgcWglRenderer.h>

class BoneNode;

class WglRendererWrap : public WglRenderer  
{
private:
//	bool	m_bShowVertices;

protected:

public:
	MgcDeclareRTTI;
	virtual void DisplayBackBuffer();
	virtual void Draw(Node* pScene);
	virtual void Draw(int iX, int iY, const ColorRGB& rkColor, const char* acText);
	void UnsetRenderContext();
	void SetRenderContext(HDC hDC);
	WglRendererWrap(HWND hwnd, int nWidth, int nHeight);
	virtual ~WglRendererWrap();
};

MgcSmartPointer(WglRendererWrap);

#endif // !defined(AFX_WGLRENDERERWRAP_H__9B75A089_0D0E_4943_BF85_7D68D9CE63EC__INCLUDED_)
