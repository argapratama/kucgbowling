#if !defined(AFX_DLGTEXTUREAPPLYMODE_H__6A2E7253_0FEF_4A1A_BB77_0A255B35EA80__INCLUDED_)
#define AFX_DLGTEXTUREAPPLYMODE_H__6A2E7253_0FEF_4A1A_BB77_0A255B35EA80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgTextureApplyMode.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyMode dialog

class DlgTextureApplyMode : public CDialog
{
// Construction
public:
	DlgTextureApplyMode(CWnd* pParent = NULL);   // standard constructor
	Texture::ApplyMode m_eAM;

// Dialog Data
	//{{AFX_DATA(DlgTextureApplyMode)
	enum { IDD = IDD_TEXTURE_APPLY_MODE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgTextureApplyMode)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgTextureApplyMode)
	afx_msg void OnRadioReplace();
	afx_msg void OnRadioDecal();
	afx_msg void OnRadioModulate();
	afx_msg void OnRadioBlend();
	afx_msg void OnRadioAdd();
	afx_msg void OnRadioCombine();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGTEXTUREAPPLYMODE_H__6A2E7253_0FEF_4A1A_BB77_0A255B35EA80__INCLUDED_)
