// WMSceneViewer.h : main header file for the WMSCENEVIEWER application
//

#if !defined(AFX_WMSCENEVIEWER_H__39AC977A_8A02_4E06_AA07_4C1FF40A18E6__INCLUDED_)
#define AFX_WMSCENEVIEWER_H__39AC977A_8A02_4E06_AA07_4C1FF40A18E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#include "MgcWglRenderer.pkg"


#pragma comment(lib,"comctl32.lib")
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"MagicFM.lib")
#pragma comment(lib,"MagicWM.lib")

#pragma comment(lib,"MgcWglRenderer.lib")

/////////////////////////////////////////////////////////////////////////////
// WMSceneViewerApp:
// See WMSceneViewer.cpp for the implementation of this class
//

#include "WglRendererWrap.h"

class WMSceneViewerApp : public CWinApp
{
public:
	WMSceneViewerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WMSceneViewerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(WMSceneViewerApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WMSCENEVIEWER_H__39AC977A_8A02_4E06_AA07_4C1FF40A18E6__INCLUDED_)
