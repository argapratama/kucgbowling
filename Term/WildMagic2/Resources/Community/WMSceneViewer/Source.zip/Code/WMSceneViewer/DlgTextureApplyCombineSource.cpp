// DlgTextureApplyCombineSource.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgTextureApplyCombineSource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using Texture::ApplyCombineSrc;

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineSource dialog


DlgTextureApplyCombineSource::DlgTextureApplyCombineSource(CWnd* pParent /*=NULL*/)
	: CDialog(DlgTextureApplyCombineSource::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgTextureApplyCombineSource)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgTextureApplyCombineSource::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgTextureApplyCombineSource)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgTextureApplyCombineSource, CDialog)
	//{{AFX_MSG_MAP(DlgTextureApplyCombineSource)
	ON_BN_CLICKED(IDC_RADIO_TEXTURE, OnRadioTexture)
	ON_BN_CLICKED(IDC_RADIO_PRIMARY_COLOR, OnRadioPrimaryColor)
	ON_BN_CLICKED(IDC_RADIO_CONSTANT, OnRadioConstant)
	ON_BN_CLICKED(IDC_RADIO_PREVIOUS, OnRadioPrevious)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineSource message handlers

void DlgTextureApplyCombineSource::OnRadioTexture() 
{
	m_eACS = ApplyCombineSrc::ACS_TEXTURE;
}

void DlgTextureApplyCombineSource::OnRadioPrimaryColor() 
{
	m_eACS = ApplyCombineSrc::ACS_PRIMARY_COLOR;
}

void DlgTextureApplyCombineSource::OnRadioConstant() 
{
	m_eACS = ApplyCombineSrc::ACS_CONSTANT;
}

void DlgTextureApplyCombineSource::OnRadioPrevious() 
{
	m_eACS = ApplyCombineSrc::ACS_PREVIOUS;
}
