// DlgAlphaStateSrcBlendFunc.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgAlphaStateSrcBlendFunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateSrcBlendFunc dialog


DlgAlphaStateSrcBlendFunc::DlgAlphaStateSrcBlendFunc(CWnd* pParent /*=NULL*/)
	: CDialog(DlgAlphaStateSrcBlendFunc::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgAlphaStateSrcBlendFunc)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DlgAlphaStateSrcBlendFunc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgAlphaStateSrcBlendFunc)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgAlphaStateSrcBlendFunc, CDialog)
	//{{AFX_MSG_MAP(DlgAlphaStateSrcBlendFunc)
	ON_BN_CLICKED(IDC_RADIO_ZERO, OnRadioZero)
	ON_BN_CLICKED(IDC_RADIO_ONE, OnRadioOne)
	ON_BN_CLICKED(IDC_RADIO_DST_COLOR, OnRadioDstColor)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_DEST_COLOR, OnRadioOneMinusDestColor)
	ON_BN_CLICKED(IDC_RADIO_SRC_ALPHA_SATURATE, OnRadioSrcAlphaSaturate)
	ON_BN_CLICKED(IDC_RADIO_SRC_ALPHA, OnRadioSrcAlpha)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_SRC_ALPHA, OnRadioOneMinusSrcAlpha)
	ON_BN_CLICKED(IDC_RADIO_DST_ALPHA, OnRadioDstAlpha)
	ON_BN_CLICKED(IDC_RADIO_ONE_MINUS_DST_ALPHA, OnRadioOneMinusDstAlpha)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateSrcBlendFunc message handlers

void DlgAlphaStateSrcBlendFunc::OnRadioZero() 
{
	m_eSBF = AlphaState::SBF_ZERO;
}

void DlgAlphaStateSrcBlendFunc::OnRadioOne() 
{
	m_eSBF = AlphaState::SBF_ONE;
}

void DlgAlphaStateSrcBlendFunc::OnRadioDstColor() 
{
	m_eSBF = AlphaState::SBF_DST_COLOR;
}

void DlgAlphaStateSrcBlendFunc::OnRadioOneMinusDestColor() 
{
	m_eSBF = AlphaState::SBF_ONE_MINUS_DST_COLOR;
}

void DlgAlphaStateSrcBlendFunc::OnRadioSrcAlphaSaturate() 
{
	m_eSBF = AlphaState::SBF_SRC_ALPHA_SATURATE;		
}

void DlgAlphaStateSrcBlendFunc::OnRadioSrcAlpha() 
{
	m_eSBF = AlphaState::SBF_SRC_ALPHA;	
}

void DlgAlphaStateSrcBlendFunc::OnRadioOneMinusSrcAlpha() 
{
	m_eSBF = AlphaState::SBF_ONE_MINUS_SRC_ALPHA;
}

void DlgAlphaStateSrcBlendFunc::OnRadioDstAlpha()
{
	m_eSBF = AlphaState::SBF_DST_ALPHA;
}

void DlgAlphaStateSrcBlendFunc::OnRadioOneMinusDstAlpha() 
{
	m_eSBF = AlphaState::SBF_ONE_MINUS_DST_ALPHA;
}
