#if !defined(AFX_DLGTEXTUREAPPLYCOMBINEOP_H__BAC3A5D7_0DBE_412F_A4C6_5CDF413180CD__INCLUDED_)
#define AFX_DLGTEXTUREAPPLYCOMBINEOP_H__BAC3A5D7_0DBE_412F_A4C6_5CDF413180CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgTextureApplyCombineOp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineOp dialog

class DlgTextureApplyCombineOp : public CDialog
{
// Construction
public:
	DlgTextureApplyCombineOp(CWnd* pParent = NULL);   // standard constructor
	Texture::ApplyCombineOperand m_eACO;
// Dialog Data
	//{{AFX_DATA(DlgTextureApplyCombineOp)
	enum { IDD = IDD_TEXTURE_APPLY_COMBINE_OP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgTextureApplyCombineOp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgTextureApplyCombineOp)
	afx_msg void OnRadioSrcColor();
	afx_msg void OnRadioOneMinusSrcColor();
	afx_msg void OnRadioSrcAlpha();
	afx_msg void OnRadioOneMinusSrcAlpha();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGTEXTUREAPPLYCOMBINEOP_H__BAC3A5D7_0DBE_412F_A4C6_5CDF413180CD__INCLUDED_)
