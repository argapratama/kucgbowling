// WMSceneViewerDoc.h : interface of the WMSceneViewerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WMSCENEVIEWERDOC_H__A7CF06D5_51CA_4377_AF72_6D98B9EDC600__INCLUDED_)
#define AFX_WMSCENEVIEWERDOC_H__A7CF06D5_51CA_4377_AF72_6D98B9EDC600__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class WMSceneViewerDoc : public CDocument
{
private:
	NodePtr	m_pScene;

protected: // create from serialization only
	WMSceneViewerDoc();
	DECLARE_DYNCREATE(WMSceneViewerDoc)

// Attributes
public:

// Operations
public:
	Node* GetScene() {return m_pScene;}
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WMSceneViewerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~WMSceneViewerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(WMSceneViewerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WMSCENEVIEWERDOC_H__A7CF06D5_51CA_4377_AF72_6D98B9EDC600__INCLUDED_)
