#if !defined(AFX_DLGTEXTUREAPPLYCOMBINEFUNCTION_H__771CE75B_BD3F_447F_BF33_DAB701BA7272__INCLUDED_)
#define AFX_DLGTEXTUREAPPLYCOMBINEFUNCTION_H__771CE75B_BD3F_447F_BF33_DAB701BA7272__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgTextureApplyCombineFunction.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgTextureApplyCombineFunction dialog


class DlgTextureApplyCombineFunction : public CDialog
{
// Construction
public:
	Texture::ApplyCombineFunction m_eACF;
	DlgTextureApplyCombineFunction(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DlgTextureApplyCombineFunction)
	enum { IDD = IDD_TEXTURE_APPLY_COMBINE_FUNCTION };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgTextureApplyCombineFunction)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgTextureApplyCombineFunction)
	afx_msg void OnRadioDot3Rgb();
	afx_msg void OnRadioAddSigned();
	afx_msg void OnRadioDot3Rgba();
	afx_msg void OnRadioInterpolate();
	afx_msg void OnRadioModulate();
	afx_msg void OnRadioReplace();
	afx_msg void OnRadioSubtract();
	afx_msg void OnRadioAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGTEXTUREAPPLYCOMBINEFUNCTION_H__771CE75B_BD3F_447F_BF33_DAB701BA7272__INCLUDED_)
