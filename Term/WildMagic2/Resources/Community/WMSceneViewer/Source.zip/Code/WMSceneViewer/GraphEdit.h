#if !defined(AFX_GRAPHEDIT_H__B4F5F46E_9469_422A_B4F8_4DDA0F047626__INCLUDED_)
#define AFX_GRAPHEDIT_H__B4F5F46E_9469_422A_B4F8_4DDA0F047626__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GraphEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// GraphEdit form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class BoneNode;

class GraphEdit : public CFormView
{
private:
	string	m_strName;
	map<Object*, HTREEITEM> mapObjToItem;
	map<HTREEITEM, Object*> mapItemToObj;
	Stream		m_BufferStream;
	SpatialPtr	m_pCopy;
	SpatialPtr	m_pCut;

	void ReadQuaternion();
	void ReadBool();
	void ReadMatrix3();
	void ReadVector3();
	void ReadFloat();
	void ReadColorRGB();
	void ReadCullType();
	void ReadFrontType();
	void EmptyAllMaps();

	static char* MakeName(Object* pObj, const char* szPrefix);
	string& MakeName(Light::Type LType, const string& strPrefix);
	string& MakeName(int n, const string& strPrefix);
	string& MakeName(float n, const string& strPrefix);		
	string& MakeName(bool b, const string& strPrefix);
	string& MakeName(const Matrix3& rMat, const string& strPrefix);
	string& MakeName(const Vector3& rVec3, const string& strPrefix);
	string& MakeName(ColorRGB Color, const string& strPrefix);
	string& MakeName(Texture::CorrectionMode CM, const string& strPrefix);
	string& MakeName(Texture::ApplyMode AM, const string& strPrefix);
	string& MakeName(Texture::ApplyCombineFunction ACF, const string& strPrefix);
	string& MakeName(Texture::ApplyCombineSrc ACS, const string& strPrefix);
	string& MakeName(Texture::ApplyCombineOperand ACO, const string& strPrefix);
	string& MakeName(Texture::ApplyCombineScale ACSC, const string& strPrefix);
	string& MakeName(Texture::WrapMode WM, const string& strPrefix);
	string& MakeName(Texture::MipmapMode MM, const string& strPrefix);
	string& MakeName(Texture::EnvmapMode EM, const string& strPrefix);
	string& MakeName(Texture::FilterMode FM, const string& strPrefix);	
	string& MakeName(AlphaState::SrcBlendFunction SBF, const string& strPrefix);
	string& MakeName(AlphaState::DstBlendFunction DBF, const string& strPrefix);
	string& MakeName(AlphaState::TestFunction TF, const string& strPrefix);
	

	void ChangeTexture(Texture* pText, HTREEITEM hItem);
	void ChangeMaterial(MaterialState* pMat, HTREEITEM hItem);
	void ChangeLight(Light* pLight, HTREEITEM hItem);
	void ChangeAlphaState(AlphaState* pAlpha, HTREEITEM hItem);
	void ChangeSpatial(Spatial* pSpatial, HTREEITEM hItem);
	
	void UpdateLight(Light* pLight, HTREEITEM hItem);
	void UpdateVector3(const Vector3& rVec3, const char* acPrefix, HTREEITEM hItem);
	void UpdateMaterial(MaterialState* pText, HTREEITEM hItem);
	void UpdateTexture(Texture* pText, HTREEITEM hItem);
	void UpdateAlphaState(AlphaState* pAlpha, HTREEITEM hItem);
	void UpdateSpatial(Spatial* pSpatial, HTREEITEM hItem);
	
	void InsertQuaternion(Quaternion& rQuat, const string& strPrefix, HTREEITEM hParent);
	void InsertMatrix3(Matrix3& rMat, const char* pszPrefix, HTREEITEM hParent);
	void InsertVector3(Vector3& rVec3, const string& strPrefix, HTREEITEM hParent);
	void InsertFloat(float f, const string& strPrefix, HTREEITEM hParent);
	void InsertInteger(int n, const string& strPrefix, HTREEITEM hParent);
	void InsertFrontType(CullState::FrontType& ft, const string& strPrefix, HTREEITEM hParent);
	void InsertCullType(CullState::CullType& ct, const string& strPrefix, HTREEITEM hParent);
	void InsertBool(bool& b, const string& strPrefix, HTREEITEM hParent);
	void InsertColorRGB(ColorRGB& rCol, const string& strPrefix, HTREEITEM hParent);
	void InsertAmbientLight(AmbientLight* pAL, HTREEITEM hParent);
	void InsertDirectionalLight(DirectionalLight* pDL, HTREEITEM hParent);
	void InsertVertices(TriMesh* pMesh, HTREEITEM hParent);
	void InsertVertexColors(TriMesh* pMesh, HTREEITEM hParent);
	void InsertNormals(TriMesh* pMesh, HTREEITEM hParent);
	HTREEITEM InsertLight(Light* pL, HTREEITEM hParent);
	void InsertSpatial(Spatial* pSpat, HTREEITEM hParent);
	void InsertConnectivity(TriMesh* pMesh, HTREEITEM hParent);
	void InsertSkinVertices(SkinController::SkinVertex* pVerts, int nVertices, HTREEITEM hParent);
	void InsertCommonControllerDetails(Controller* pCont, HTREEITEM hParent);
	//void BuildNodes(Node* pNode, HTREEITEM hParent);
	void InsertNodes(Node* pNode, HTREEITEM hParent);
	void InsertTriMesh(TriMesh* pTriMesh, HTREEITEM hParent);
	void InsertLightState(LightState* pLS, HTREEITEM hParent);
	void InsertWireframeState(WireframeState* pWS, HTREEITEM hParent);
	void InsertCullState(CullState* pCS, HTREEITEM hParent);
	void InsertController(Controller* pCont, HTREEITEM hParent);
	void InsertKeyframeController(KeyframeController* pKeyframe, HTREEITEM hParent);
	void InsertSkinController(SkinController* pSkin, HTREEITEM hParent);
	void InsertIKController(IKController* pIK, HTREEITEM hParent);
	void InsertMaterialState(MaterialState* pMat, HTREEITEM hParent);
	void InsertRenderState(Spatial* pNode, HTREEITEM hParent);	
	void InsertTextureState(TextureState* pTS, HTREEITEM hParent);
	void InsertTexture(Texture* pText, HTREEITEM hParent);
	void InsertAlphaState(AlphaState* pAlpha, HTREEITEM hParent);
	void InsertPointLight(PointLight* pPLight, HTREEITEM hParent);
	void InsertBumpMapNode(BumpMap* pNode, HTREEITEM hParent);
	void SetTreeItemText(HTREEITEM hItem, const string& strText);

	CTreeCtrl& GetTreeCtrl();	

public:
	void InsertKeyframeController(KeyframeController* pKF, Node* pKey);
	void InsertBoneNode(BoneNode* pTri, Node* pKey);
	void InsertTriMesh(TriMesh* pTri, Node* pKey);
	void SetFloatTreeItemText(float* pKey);	
	void SetBoolTreeItemText(bool* pKey);	
	void SetColorRGBTreeItemText(ColorRGB* pKey);
	void SetVector3TreeItemText(Vector3* pKey);
	void SetMatrix3TreeItemText(Matrix3* pKey);

protected:
	GraphEdit();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(GraphEdit)

// Form Data
public:
	//{{AFX_DATA(GraphEdit)
	enum { IDD = IDD_GRAPHEDIT_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GraphEdit)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~GraphEdit();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(GraphEdit)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRclickTreeGraph(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditChange();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditDelete();
	afx_msg void OnEditPaste();
	afx_msg void OnDblclkTreeGraph(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditAddTexture();
	afx_msg void OnEditAddAlphaState();	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRAPHEDIT_H__B4F5F46E_9469_422A_B4F8_4DDA0F047626__INCLUDED_)
