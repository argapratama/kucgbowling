// MainFrm.cpp : implementation of the MainFrame class
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "WMSceneViewerView.h"
#include "MainFrm.h"
#include "GraphEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MainFrame

IMPLEMENT_DYNCREATE(MainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(MainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(MainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_SPLIT, OnViewSplit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// MainFrame construction/destruction

MainFrame::MainFrame() :
	m_pStatSplitter(NULL),
	m_pStatSplitter1(NULL)
{
	m_apPanes = new CRuntimeClass*[4];
	m_apPanes[0] = RUNTIME_CLASS(GraphEdit);
	m_apPanes[1] = RUNTIME_CLASS(WMSceneViewerView);
	m_apPanes[2] = RUNTIME_CLASS(WMSceneViewerView);
	m_apPanes[3] = RUNTIME_CLASS(WMSceneViewerView);
}

MainFrame::~MainFrame()
{
	if (m_pStatSplitter)
	{		
		delete m_pStatSplitter;
	}
	if (m_pStatSplitter1)
	{
		delete m_pStatSplitter1;
	}
	delete[] m_apPanes;
}

int MainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	
	return 0;
}

BOOL MainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// MainFrame diagnostics

#ifdef _DEBUG
void MainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void MainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// MainFrame message handlers

void MainFrame::View2Panes()
{
	CCreateContext cc;
	CView* pOldView = GetActiveView();
	cc.m_pCurrentDoc = GetActiveDocument();
	cc.m_pCurrentFrame = this;
	cc.m_pLastView = pOldView;
	cc.m_pNewDocTemplate = 0;
	cc.m_pNewViewClass = 0;
	CSplitterWnd* pOldSplit = m_pStatSplitter;
	m_pStatSplitter = new CSplitterWnd;
	m_pStatSplitter->CreateStatic(this, 1, 2);
	RECT rect;
	GetClientRect(&rect);
	m_pStatSplitter->CreateView(0, 0, m_apPanes[0], CSize(rect.right/2, rect.bottom), &cc);
	m_pStatSplitter->CreateView(0, 1, m_apPanes[1], CSize(rect.right/2, rect.bottom), &cc);	
	GetActiveDocument()->RemoveView(pOldView);
	if (pOldSplit)
	{
		pOldSplit->DestroyWindow();
		delete pOldSplit;
	}
	else
	{
		pOldView->DestroyWindow();
	}
	CView* pNewView = (CView*)m_pStatSplitter->GetPane(0, 0);
	SetActiveView((CView*)m_pStatSplitter->GetPane(0, 0));	
	InitialUpdateFrame(GetActiveDocument(), TRUE);	
	RecalcLayout();
	cc.m_pCurrentDoc = GetActiveDocument();
}

void MainFrame::OnViewSplit() 
{
	View2Panes();	
}
