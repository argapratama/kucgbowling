#include "stdafx.h"
#include "WMGraphFunctions.h"

//using namespace WMGraphFunctions;

Stream StreamBuffer;

void CopyNode(Node*& pTo, Node* pFrom)
{
	//copies the data contained in the node pFrom and into pTo
	StreamBuffer.Load("dummy.mgc");
	StreamBuffer.RemoveAll();
	StreamBuffer.Insert(pFrom);
	int nSize = StreamBuffer.GetMemoryUsed();
	char* acBuffer = new char[nSize];
	StreamBuffer.Save(acBuffer,	nSize);
	StreamBuffer.Load(acBuffer, nSize);
	pTo = (Node*)StreamBuffer.GetObjectAt(0);
		
	/*int i, n = pFrom->GetQuantity();
	
	for (i = 0; i < n; i++)
	{
		if (MgcIsExactlyClass(Node, (pFrom->GetChild(i))))
		{
			Node* pTemp = new Node;
			CopyNode(pTemp, MgcDynamicCast(Node, (pFrom->GetChild(i))));
			pTo->AttachChild(pTemp);
		}
		else if (MgcIsExactlyClass(TriMesh, (pFrom->GetChild(i))))
		{
			TriMesh* pDest = new TriMesh(0, 0, 0, 0, 0, 0, 0);
			CopyTriMesh(pDest, MgcDynamicCast(TriMesh, (pFrom->GetChild(i))));
			pTo->AttachChild(pDest);
		}
	}*/
}


void CopyTriMesh(TriMesh* pDest, TriMesh* pSource)
{
	CopyGeometry(MgcDynamicCast(Geometry, pDest), MgcDynamicCast(Geometry, pSource));
	int nTriQuantity = pSource->GetTriangleQuantity();	
	int* anConnect = new int[nTriQuantity * 3];
	memcpy(anConnect, pSource->Connectivity(), nTriQuantity * 3 * sizeof(int));	
	pDest->Reconstruct(pDest->GetVertexQuantity(), pDest->Vertices(), pDest->Normals(), pDest->Colors(),
						pDest->Textures(), nTriQuantity, anConnect, pDest->Textures1(), pDest->Textures2(), 
						pDest->Textures3(), pDest->TexturesBump());
}

void CopyObject(Object* pDest, Object* pSource)
{
	Controller* pController;
	pController = pSource->GetControllers();
	while (pController)
	{			
		if (MgcIsExactlyClass(KeyframeController, pController))
		{
			KeyframeController*  pDestCont = new KeyframeController;
			CopyKeyframeController(pDestCont, (KeyframeController*)pController);
			pDest->AttachControl(pDestCont);
		}
		else if (MgcIsExactlyClass(SkinController, pController))
		{
			SkinController* pDestCont = new SkinController;
			CopySkinController(pDestCont, (SkinController*)pController);
			pDest->AttachControl(pDestCont);
		}
		pController = pController->GetNext();
	}
}

void CopyKeyframeController(KeyframeController* pDest, KeyframeController* pSource)
{
	CopyController(MgcDynamicCast(Controller, pDest), MgcDynamicCast(Controller, pSource));
	if (pSource->GetSharedQuantity() > 0)
	{	
		int nQuantity = pSource->GetSharedQuantity();
		float* anSharedTimes = new float[nQuantity];
		memcpy(anSharedTimes, pSource->GetSharedTimes(), nQuantity * sizeof(float));
		pDest->SetSharedTimes(anSharedTimes);
		pDest->SetSharedQuantity(nQuantity);
		
		Vector3* aTranslations = new Vector3[nQuantity];
		memcpy(aTranslations, pSource->GetTranslations(), nQuantity * sizeof(Vector3));
		pDest->SetTranslations(aTranslations);
					
		Quaternion* aRotate = new Quaternion[nQuantity];
		memcpy(aRotate, pSource->GetRotations(), nQuantity * sizeof(Quaternion));
		pDest->SetRotations(aRotate);

		float* anScale = new float[nQuantity];
		memcpy(anScale, pSource->GetScales(), nQuantity * sizeof(float));
		pDest->SetScales(anScale);
	}
	else
	{
		int nQuantity = pSource->GetTranslationQuantity();
		if (nQuantity)
		{
			float* anTimes = new float[nQuantity];
			Vector3* aTranslations = new Vector3[nQuantity];
			memcpy(aTranslations, pSource->GetTranslations(), nQuantity * sizeof(Vector3));
			memcpy(anTimes, pSource->GetTranslationTimes(), nQuantity * sizeof(float));
			pDest->SetTranslations(aTranslations);
			pDest->SetTranslationTimes(anTimes);
		}

		nQuantity = pSource->GetRotationQuantity();
		if (nQuantity)
		{
			float* anTimes = new float[nQuantity];
			Quaternion* aRotations = new Quaternion[nQuantity];
			memcpy(anTimes, pSource->GetRotationTimes(), nQuantity * sizeof(float));
			memcpy(aRotations, pSource->GetTranslations(), nQuantity * sizeof(Quaternion));
			pDest->SetRotations(aRotations);
			pDest->SetRotationTimes(anTimes);
		}

		nQuantity = pSource->GetScaleQuantity();
		if (nQuantity)
		{
			float* anTimes = new float[nQuantity];
			float* anScales = new float[nQuantity];
			memcpy(anTimes, pSource->GetScaleTimes(), nQuantity * sizeof(float));
			memcpy(anScales, pSource->GetScales(), nQuantity * sizeof(float));
			pDest->SetScales(anScales);
			pDest->SetScaleTimes(anTimes);
		}
	}
}

void CopySkinController(SkinController* pDest, SkinController* pSource)
{
	CopyController(MgcDynamicCast(Controller, pDest), MgcDynamicCast(Controller, pSource));
	int nBones = pSource->BoneQuantity();
	pDest->BoneQuantity() = nBones;
	pDest->Bones() = new Node*[nBones];
	pDest->SkinVertexQuantities() = new int[nBones];
	pDest->SkinVertices() = new SkinController::SkinVertex*[nBones];
	
	int i, j;
	for (i = 0; i < nBones; i++)
	{
		pDest->Bones()[i] = pSource->Bones()[i];
		pDest->SkinVertexQuantities()[i] = pSource->SkinVertexQuantities()[i];
		pDest->SkinVertices()[i] = new SkinController::SkinVertex[pDest->SkinVertexQuantities()[i]];
		for (j = 0; j < pDest->SkinVertexQuantities()[i]; j++)
		{			
			pDest->SkinVertices()[i][j] = pSource->SkinVertices()[i][j];
		}
	}	
}

void CopyController(Controller* pDest, Controller* pSource)
{
	pDest->MinTime() = pSource->MinTime();
	pDest->MaxTime() = pSource->MaxTime();
	pDest->Phase() = pSource->Phase();
	pDest->Frequency() = pSource->Frequency();
	pDest->Active() = pSource->Active();
}

void CopyGeometry(Geometry* pDest, Geometry* pSource)
{
	CopySpatial(MgcDynamicCast(Spatial, pDest), MgcDynamicCast(Spatial, pSource));
	
	int nVertices = pSource->GetVertexQuantity();
	Vector3* aVertices = new Vector3[nVertices];
	memcpy(aVertices, pSource->Vertices(), nVertices * sizeof(Vector3));

	Vector3* aNormals = 0;
	ColorRGB* aColors = 0;
	Vector2* aTexture = 0;
	Vector2* aTexture1 = 0;
	Vector2* aTexture2 = 0;
	Vector2* aTexture3 = 0;
	Vector2* aTextureBump = 0;

	if (pSource->Normals())
	{	
		aNormals = new Vector3[nVertices];
		memcpy(aNormals, pSource->Normals(), nVertices * sizeof(Vector3));
	}
	
	if (pSource->Colors())
	{	
		aColors = new ColorRGB[nVertices];
		memcpy(aColors, pSource->Colors(), nVertices * sizeof(Vector3));
	}

	if (pSource->Textures())
	{	
		aTexture = new Vector2[nVertices];
		memcpy(aTexture, pSource->Textures(), nVertices * sizeof(Vector2));
	}

	if (pSource->Textures1())
	{	
		aTexture1 = new Vector2[nVertices];
		memcpy(aTexture1, pSource->Textures1(), nVertices * sizeof(Vector2));
	}

	if (pSource->Textures2())
	{	
		aTexture2 = new Vector2[nVertices];
		memcpy(aTexture2, pSource->Textures2(), nVertices * sizeof(Vector2));
	}

	if (pSource->Textures3())
	{	
		aTexture3 = new Vector2[nVertices];
		memcpy(aTexture3, pSource->Textures3(), nVertices * sizeof(Vector2));
	}

	if (pSource->TexturesBump())
	{	
		aTextureBump = new Vector2[nVertices];
		memcpy(aTextureBump, pSource->TexturesBump(), nVertices * sizeof(Vector2));
	}

	pDest->Reconstruct(nVertices, aVertices, aNormals, aColors, aTexture, aTexture1, aTexture2, aTexture3, aTextureBump);
}

void CopyRenderState(Spatial* pDest, Spatial* pSource)
{
	MaterialState* pMat;
	if (pMat = MgcDynamicCast(MaterialState, (pSource->GetRenderState(RenderState::RS_MATERIAL))))
	{
		MaterialState* pMat1 = new MaterialState;
		CopyMaterialState(pMat1, pMat);
		pDest->SetRenderState(pMat1);
	}

	TextureState* pText;
	if (pText = MgcDynamicCast(TextureState, (pSource->GetRenderState(RenderState::RS_TEXTURE))))
	{
		TextureState* pText1 = new TextureState;
		CopyTextureState(pText1, pText);
		pDest->SetRenderState(pText1);
	}
}

void CopyTextureState(TextureState* pDest, TextureState* pSource)
{
	int i, n = pSource->GetQuantity();
	for (i = 0; i < n; i++)
	{
		Texture* pText = new Texture;
		CopyTexture(pText, pSource->Get(i));
		pDest->Set(i, pText);
	}
}

void CopyTexture(Texture* pDest, Texture* pSource)
{
	pDest->Apply() = pSource->Apply();
	pDest->BlendColor() = pSource->BlendColor();
	pDest->BorderColor() = pSource->BorderColor();
	pDest->CombineFuncAlpha() = pSource->CombineFuncAlpha();
	pDest->CombineFuncRGB() = pSource->CombineFuncRGB();
	pDest->CombineOp0Alpha() = pSource->CombineOp0Alpha();
	pDest->CombineOp0RGB() = pSource->CombineOp0RGB();
	pDest->CombineOp1Alpha() = pSource->CombineOp1Alpha();
	pDest->CombineOp1RGB() = pSource->CombineOp1RGB();
	pDest->CombineOp2Alpha() = pSource->CombineOp2Alpha();
	pDest->CombineOp2RGB() = pSource->CombineOp2RGB();
	pDest->CombineScaleAlpha() = pSource->CombineScaleAlpha();
	pDest->CombineScaleRGB() = pSource->CombineScaleRGB();
	pDest->Correction() = pSource->Correction();
	pDest->Envmap() = pSource->Envmap();
	pDest->Filter() = pSource->Filter();
	pDest->UserData() = pSource->UserData();
	pDest->Wrap() = pSource->Wrap();
	pDest->SetImage(pSource->GetImage());
}	

void CopyMaterialState(MaterialState* pDest, MaterialState* pSource)
{
	pDest->Emissive() = pSource->Emissive();
	pDest->Diffuse() = pSource->Diffuse();
	pDest->Ambient() = pSource->Ambient();
	pDest->Specular() = pSource->Specular();
	pDest->Alpha() = pSource->Alpha();
	pDest->Shininess() = pSource->Shininess();
}

void CopySpatial(Spatial* pDest, Spatial* pSource)
{
	CopyObject(MgcDynamicCast(Object, pDest), MgcDynamicCast(Object, pSource));
	CopyRenderState(pDest, pSource);
	pDest->Rotate() = pSource->Rotate();
	pDest->Translate() = pSource->Translate();
	pDest->Scale() = pSource->Scale();

}

void MoveSpatial(Node* pTo, Spatial* pFrom)
{
	//moves pFrom and attaches it as a child of pTo
	Node* pParent;
	pParent = pFrom->GetParent();
	if (pParent)
	{
		pParent->DetachChild(pFrom);
	}
	pTo->AttachChild(pFrom);
}

void DeleteNode(Node* pNode)
{
	//deletes the given node
	Node* pParent = pNode->GetParent();
	pParent->DetachChild(pNode);
}

Object* FindObjectByID(Object* pObj, int nID)
{
	if (pObj->GetID() == nID)
		return pObj;

	Node* pNode;
	if (pNode = MgcDynamicCast(Node, pObj))
	{
		int i, n = pNode->GetQuantity();
		Object* pObj1;
		
		for (i = 0 ; i < n; i++)
		{
			//if (pObj1 = WMGraphFunctions::FindObjectByID(MgcDynamicCast(Object, (pNode->GetChild(i))), nID))
			if (pObj1 = FindObjectByID(MgcDynamicCast(Object, (pNode->GetChild(i))), nID))
			{
				return pObj1;
			}			
		}	
	}	
	return NULL;
}
