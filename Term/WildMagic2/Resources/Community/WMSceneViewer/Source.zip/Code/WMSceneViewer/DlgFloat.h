#if !defined(AFX_DLGFLOAT_H__9B497B32_91A6_44DF_A359_C42B42BF2590__INCLUDED_)
#define AFX_DLGFLOAT_H__9B497B32_91A6_44DF_A359_C42B42BF2590__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgFloat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgFloat dialog

class DlgFloat : public CDialog
{
// Construction
public:
	DlgFloat(CWnd* pParent = NULL);   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(DlgFloat)
	enum { IDD = IDD_FLOAT };
	double	m_nVal;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgFloat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgFloat)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGFLOAT_H__9B497B32_91A6_44DF_A359_C42B42BF2590__INCLUDED_)
