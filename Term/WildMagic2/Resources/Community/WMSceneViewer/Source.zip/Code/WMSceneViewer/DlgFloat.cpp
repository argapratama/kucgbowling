// DlgFloat.cpp : implementation file
//

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "DlgFloat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgFloat dialog


DlgFloat::DlgFloat(CWnd* pParent /*=NULL*/)
	: CDialog(DlgFloat::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgFloat)
	m_nVal = 0.0;
	//}}AFX_DATA_INIT
}


void DlgFloat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgFloat)
	DDX_Text(pDX, IDC_EDIT_X, m_nVal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgFloat, CDialog)
	//{{AFX_MSG_MAP(DlgFloat)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgFloat message handlers
