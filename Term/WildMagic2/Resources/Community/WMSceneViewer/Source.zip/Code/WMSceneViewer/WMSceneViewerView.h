// WMSceneViewerView.h : interface of the WMSceneViewerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WMSCENEVIEWERVIEW_H__8983FDC6_480A_46D0_A543_FD8B7B7457D3__INCLUDED_)
#define AFX_WMSCENEVIEWERVIEW_H__8983FDC6_480A_46D0_A543_FD8B7B7457D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WMSceneViewerDoc.h"

class WMSceneViewerView : public CView
{
private:
	WglRendererWrapPtr	m_pRenderer;
	CameraPtr	m_pCamera;
	bool		m_bCameraInitialized;	

	Vector3 m_vOrigLoc;
	Vector3 m_vOrigDir;
	Vector3 m_vOrigUp;
	Vector3 m_vOrigLeft;

protected: // create from serialization only
	WMSceneViewerView();
	DECLARE_DYNCREATE(WMSceneViewerView)

// Attributes
public:
	void ResetCamera();
	void SetCameraOrigin(const Vector3& vLoc, const Vector3& vDir, const Vector3& vUp, const Vector3& vLeft);
	WMSceneViewerDoc* GetDocument();
	void RotateCamera(int dx, int dy);
	void SetCamera(Camera *pCam);
	void InitCamera();
	void Render(HDC hDC);
	void SetRenderer(WglRendererWrap *pRenderer);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WMSceneViewerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~WMSceneViewerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(WMSceneViewerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in WMSceneViewerView.cpp
inline WMSceneViewerDoc* WMSceneViewerView::GetDocument()
   { return (WMSceneViewerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WMSCENEVIEWERVIEW_H__8983FDC6_480A_46D0_A543_FD8B7B7457D3__INCLUDED_)
