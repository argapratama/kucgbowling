#if !defined(AFX_DLGBOOLEAN_H__4B80D037_9E79_4AFF_B1ED_2708EFC811C0__INCLUDED_)
#define AFX_DLGBOOLEAN_H__4B80D037_9E79_4AFF_B1ED_2708EFC811C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgBoolean.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgBoolean dialog

class DlgBoolean : public CDialog
{
// Construction
public:
	DlgBoolean(CWnd* pParent = NULL);   // standard constructor
	
	bool m_bVal;
// Dialog Data
	//{{AFX_DATA(DlgBoolean)
	enum { IDD = IDD_BOOLEAN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgBoolean)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgBoolean)	
	afx_msg void OnRadioTrue();
	afx_msg void OnRadioFalse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGBOOLEAN_H__4B80D037_9E79_4AFF_B1ED_2708EFC811C0__INCLUDED_)
