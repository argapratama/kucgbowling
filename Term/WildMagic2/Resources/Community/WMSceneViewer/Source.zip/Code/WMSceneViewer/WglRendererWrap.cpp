// WglRendererWrap.cpp: implementation of the WglRendererWrap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WMSceneViewer.h"
#include "WglRendererWrap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


MgcImplementRTTI(WglRendererWrap,WglRenderer);

WglRendererWrap::WglRendererWrap(HWND hwnd, int nWidth, int nHeight) :
	WglRenderer(hwnd, nWidth, nHeight)
{
	
}

WglRendererWrap::~WglRendererWrap()
{

}

void WglRendererWrap::SetRenderContext(HDC hDC)
{	
	BOOL bSuccess = wglMakeCurrent(hDC, m_hWindowRC);
	if (!bSuccess)
	{
		TRACE("Failed to make the render context current\n");
	}
}

void WglRendererWrap::UnsetRenderContext()
{
	BOOL bSuccess = wglMakeCurrent(NULL, NULL);
	if (!bSuccess)
	{
		TRACE("Failed to unset current render context\n");
	}	
}

void WglRendererWrap::DisplayBackBuffer()
{
	WglRenderer::DisplayBackBuffer();	
}

void WglRendererWrap::Draw(Node* pScene)
{
	Renderer::Draw(pScene);
}


void WglRendererWrap::Draw(int iX, int iY, const ColorRGB& rkColor, const char* acText)
{
	WglRenderer::Draw(iX, iY, rkColor, acText);
}

