#if !defined(AFX_DLGALPHASTATETESTFUNC_H__71DCF705_D1A3_47EA_AC40_5895BE1222B8__INCLUDED_)
#define AFX_DLGALPHASTATETESTFUNC_H__71DCF705_D1A3_47EA_AC40_5895BE1222B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlphaStateTestFunc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DlgAlphaStateTestFunc dialog

class DlgAlphaStateTestFunc : public CDialog
{
// Construction
public:
	DlgAlphaStateTestFunc(CWnd* pParent = NULL);   // standard constructor
	AlphaState::TestFunction m_eTF;

// Dialog Data
	//{{AFX_DATA(DlgAlphaStateTestFunc)
	enum { IDD = IDD_ALPHASTATE_TEST_FUNC };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DlgAlphaStateTestFunc)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DlgAlphaStateTestFunc)
	afx_msg void OnRadioNever();
	afx_msg void OnRadioLess();
	afx_msg void OnRadioEqual();
	afx_msg void OnRadioLequal();
	afx_msg void OnRadioGreater();
	afx_msg void OnRadioGequal();
	afx_msg void OnRadioNotEqual();
	afx_msg void OnRadioAlways();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALPHASTATETESTFUNC_H__71DCF705_D1A3_47EA_AC40_5895BE1222B8__INCLUDED_)
