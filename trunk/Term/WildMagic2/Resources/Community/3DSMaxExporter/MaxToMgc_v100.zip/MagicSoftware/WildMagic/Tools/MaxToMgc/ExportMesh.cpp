// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "UnimaterialMesh.h"
#include "MaxToMgc.h"

// GetTriObject() - Determine whether or not a MAX node has an associated mesh object.
// [in] pkNode - Node to test
// [out] bNeedDel - bool, true if the caller should delete the returned mesh pointer
//       after use, false otherwise
// [returns] pointer to mesh object, or NULL, if the node has no associated mesh

TriObject* MgcSceneBuilder::GetTriObject (INode* pkNode, bool* bNeedDel)
{
    ::Object* pkObj = pkNode->EvalWorldState(m_timeStart).obj;

// See if the object associated with this node can be converted to a trimesh
    if ( !pkObj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)) ) 
        return NULL;
// Do the conversion
    TriObject* pkTriObj = 
        (TriObject*)pkObj->ConvertToType(m_timeStart, Class_ID(TRIOBJ_CLASS_ID, 0));
    if ( pkTriObj == NULL ) 
        return NULL;
// See whether or not the caller is responsible for deleting the mesh pointer
    *bNeedDel = pkTriObj != pkObj ? true : false; 
    return pkTriObj;
}

// BuildMesh() - Convert a MAX trimesh to one or more equivalent Magic trimeshes.
// [in] pkMaxNode - mesh node in the MAX hierarchy
// [in] pkMgcNode - parent node in Magic scene to which newly created mesh node(s)
//      will be linked
// [returns] pointer to new child node in the Magic scene - this will point directly
//      to a trimesh object, if there is only one Magic mesh, or to a "link"
//      node, whose children are the mulitple trimeshes needed to represent
//      the MAX mesh

Mgc::Node* MgcSceneBuilder::BuildMesh (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
    bool bNeedDel = false;
    TriObject* pkTriObj = GetTriObject(pkMaxNode,&bNeedDel);
    if( !pkTriObj ) 
        return NULL;
    Mesh* pkTriMesh = &pkTriObj->GetMesh();

    vector<UnimaterialMesh*> kUMeshes;
    int iMtlID = -1;
    Mtl* pkMtl = pkMaxNode->GetMtl();
    if ( pkMtl )
        iMtlID = m_kMtlList.GetID(pkMtl);

    SplitGeometry(pkTriMesh,iMtlID,kUMeshes, 
        HasReflection(pkMaxNode->GetObjTMAfterWSM(m_timeStart)));

    Mgc::Node* pkLink;
    bool bHasLink;
    if ( pkMgcNode->GetName() && strcmp(pkMaxNode->GetName(),pkMgcNode->GetName()) == 0 )
        bHasLink = true;
    else 
        bHasLink = false;
// If only a single Magic mesh is required to represent the MAX mesh, then link
// it directly to the parent node in the Magic scene, otherwise create a "link"
// node, whose children will be the individual Magic meshes needed to represent the
// MAX mesh
    char* acMaxName = pkMaxNode->GetName();

    if ( kUMeshes.size() > 1  )
    {
        if ( !bHasLink )
            pkLink = BuildSpatial(pkMaxNode,pkMgcNode);
        else 
            pkLink = pkMgcNode; 

        for (int i = 0; i < (int)kUMeshes.size(); i++)
        {
            Mgc::TriMesh* pkTriMesh = kUMeshes[i]->ToTriMesh();
            char acMeshNumber[6];
            sprintf(acMeshNumber,"_%d",i + 1);
            char* acMgcName = new char[strlen(acMaxName) + strlen(acMeshNumber) + 1];
            strcpy(acMgcName,acMaxName);
            strcat(acMgcName,acMeshNumber);         
            pkTriMesh->SetName(acMgcName);
            delete [] acMgcName;
            pkLink->AttachChild(pkTriMesh);
        }
    }
    else
    {
        Mgc::TriMesh* pkTriMesh = kUMeshes[0]->ToTriMesh();
        if ( !bHasLink )
        {
            pkTriMesh->SetName(acMaxName);
            ProcessMeshTransform(pkMaxNode,pkTriMesh);
        }
        else
        {
            char* acMgcName = new char[strlen(acMaxName) + 3];
            strcpy(acMgcName,acMaxName);
            strcat(acMgcName,"_1");
            pkTriMesh->SetName(acMgcName);
            delete [] acMgcName;
        }
        pkMgcNode->AttachChild(pkTriMesh);
        pkLink = (Mgc::Node*)pkTriMesh;
    }

    if( bNeedDel ) 
        delete pkTriObj;
    
    for (int i = 0; i < (int)kUMeshes.size(); i++)
        delete kUMeshes[i];

    return pkLink;
}

// SplitGeometry() -  If a mesh is encountered that has multi-submaterials *and* 
// uses two or more submaterials, that mesh needs to be split since Wild Magic only
// supports one material per object.
// [in] pkMaxMesh - pointer to MAX mesh to be split
// [out] rkUMeshes - vector, which will receive the individual UnimaterialMesh's
//       required to represent the MAX mesh
// [in] bHasReflection - true, if the node's transform contains a relection, false
//      otherwise

void MgcSceneBuilder::SplitGeometry(Mesh* pkMaxMesh, int iMtlID, 
    vector<UnimaterialMesh*>& rkUMeshes, bool bHasReflection)
{
    int i, j;
// compute vertex normals
    Mgc::Vector3* akNormal = NULL;
    if( m_pkSettings->bIncludeNormals ){
        pkMaxMesh->buildNormals();
        akNormal = new Mgc::Vector3[pkMaxMesh->numVerts];
        for (i = 0; i < pkMaxMesh->numFaces; i++)
        {
            Face& rkFace = pkMaxMesh->faces[i];
            for (j = 0; j < 3; j++)
            {
                int iVertex = rkFace.getVert(j);
                akNormal[iVertex] = GetVertexNormal(pkMaxMesh,i,iVertex);
            }
        }       
    }
// number of submaterials
    MaterialTree& rkTree = m_kMtlTree[iMtlID];
    int iSubquantity = 0;
    if ( iMtlID >= 0 )
        iSubquantity = rkTree.NumSubmaterialTrees();
// compute the maximum submaterial index used by the geometry object
    int iFace, iSubID, iMaxSubID = -1;
    for (iFace = 0; iFace < pkMaxMesh->numFaces; iFace++)
    {
        iSubID = pkMaxMesh->faces[iFace].getMatID();
        if ( iSubID >= iSubquantity )
        {
            if ( iSubquantity > 0 )
                iSubID = iSubID % iSubquantity;
            else
                iSubID = 0;
        }
        if ( iSubID > iMaxSubID )
            iMaxSubID = iSubID;
    }

// partition the faces by material ID
    vector<int>* akPartition = new vector<int>[iMaxSubID+1];
    for (iFace = 0; iFace < pkMaxMesh->numFaces; iFace++)
    {
        iSubID = pkMaxMesh->faces[iFace].getMatID();
        if ( iSubID >= iSubquantity )
        {
            if ( iSubquantity > 0 )
                iSubID = iSubID % iSubquantity;
            else
                iSubID = 0;
        }
        akPartition[iSubID].push_back(iFace);
    }

// allocate the unimaterial meshes
    for (iSubID = 0; iSubID <= iMaxSubID; iSubID++)
    {
        if ( akPartition[iSubID].size() == 0 )
        {
// submaterial ID not used
            continue;
        }

        UnimaterialMesh* pkMesh = new UnimaterialMesh;
        pkMesh->HasReflection() = bHasReflection;

        if ( iMtlID >= 0 )
        {
// TO DO.  For now, just grab the first non-null texture.  Later we should see 
// multiple textures for special effects.
            if ( iSubquantity > 0 )
            {
                MaterialTree& rkSubtree = rkTree.GetSubmaterialTree(iSubID);
                pkMesh->MState() = rkSubtree.MState();
                for (i = 0; i < (int)rkSubtree.NumSubtextureTrees(); i++)
                {
                    if ( rkSubtree.TState(i) )
                    {
                        pkMesh->TState() =
                            rkSubtree.TState(i);
                        break;
                    }
                }
            }
            else
            {
                pkMesh->MState() = rkTree.MState();
                for (i = 0; i < (int)rkTree.NumSubtextureTrees(); i++)
                {
                    if ( rkTree.TState(i) )
                    {
                        pkMesh->TState() = rkTree.TState(i);
                        break;
                    }
                }
            }
        }

        PackVertices(pkMesh,pkMaxMesh,akPartition[iSubID],akNormal);

        if ( m_pkSettings->bIncludeVertexColors && pkMaxMesh->numCVerts > 0 )
            PackColors(pkMesh,pkMaxMesh,akPartition[iSubID]);

        if ( m_pkSettings->bIncludeTexCoords && pkMaxMesh->numTVerts > 0 )
            PackTextures(pkMesh,pkMaxMesh,akPartition[iSubID]);

        rkUMeshes.push_back(pkMesh);
    }

    delete[] akPartition;
    delete[] akNormal;

// Duplicate vertex data to meet Wild Magic constraints on one
// color/normal/uv per vertex position.
    for (i = 0; i < (int)rkUMeshes.size(); i++)
        rkUMeshes[i]->DuplicateGeometry();  
}

// ProcessMeshTransform() - Get the mesh's local transform. If the MAX mesh is
// non-uniformly, or negatively scaled, then fold the scale values into the model
// data, since Magic supports only positive, uniform scale.
// [in] pkNode - node in MAX hierarchy
// [out] pkMgcTriMesh - Magic mesh whose transform is to be set

void MgcSceneBuilder::ProcessMeshTransform (INode* pkNode, Mgc::TriMesh* pkMgcMesh)
{
    Mgc::Matrix3 kScaleOrient;
    Mgc::Vector3 kScale;

    GetLocalTransform(pkNode,&pkMgcMesh->Translate(),&pkMgcMesh->Rotate(), 
        &kScale,&kScaleOrient,m_timeStart);

// Need a fuzzy comparison here
    if ( IsUniformScale(kScale) )
    {
// positive uniform scale
        pkMgcMesh->Scale() = kScale.x;
    }
    else
    {
// nonuniform and/or negative scale gets folded into model data
        int i, iVMax = pkMgcMesh->GetVertexQuantity();
        Mgc::Vector3* akVertex = pkMgcMesh->Vertices();
        for (i = 0; i < iVMax; i++)
        {
            Mgc::Vector3& rkV = akVertex[i];
            rkV = kScaleOrient*rkV;
            rkV.x *= kScale.x;
            rkV.y *= kScale.y;
            rkV.z *= kScale.z;
        }

        Mgc::Vector3* akNormal = pkMgcMesh->Normals();
        if ( akNormal )
        {
            for (i = 0; i < iVMax; i++)
                akNormal[i] = kScaleOrient*akNormal[i];
        }
    }
}

// PackVertices() - Take a partition of a MAX mesh (represented by a vector of face
// indices), and pack the corresponding vertices and normals into a UnimaterialMesh.
// [out] pkUniMesh - UniMaterial mesh to pack
// [in] pkMaxMesh - MAX mesh from which to extract vertices
// [in] rkPartition - vector of face indices representing the mesh partition
// [in] akNormal - array of mesh normal vectors, from which to extract the partition's
//      normals

void MgcSceneBuilder::PackVertices (UnimaterialMesh* pkUniMesh, Mesh* pkMaxMesh, 
    vector<int>& rkPartition, Mgc::Vector3* akNormal)
{
// get vertex indices used by the partition
    set<int> kVIndex;
    int i, j;
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        Face& rkFace = pkMaxMesh->faces[rkPartition[i]];
        for (j = 0; j < 3; j++)
            kVIndex.insert(rkFace.v[j]);
    }

// Pack into contiguous arrays.  The packing relies on the STL set having
// elements in increasing order.  If kVIndex[i] = j, then aiVMap[j] = i.
// The aiVMap array is made large enough to hold all possible j, but
// aiVMap[j] = -1 if there is no corresponding i.
    int iVMax = *kVIndex.rbegin();
    int* aiVMap = new int[iVMax+1];
    memset(aiVMap,0xFF,(iVMax+1)*sizeof(int));

    pkUniMesh->VQuantity() = kVIndex.size();
    pkUniMesh->Vertex() = new Mgc::Vector3[pkUniMesh->VQuantity()];
    pkUniMesh->Normal() = new Mgc::Vector3[pkUniMesh->VQuantity()];

    set<int>::iterator kIter = kVIndex.begin();
    for (i = 0; i < (int)kVIndex.size(); i++, kIter++)
    {
        j = *kIter;
        aiVMap[j] = i;

        pkUniMesh->Vertex()[i].x = pkMaxMesh->verts[j].x;
        pkUniMesh->Vertex()[i].y = pkMaxMesh->verts[j].y;
        pkUniMesh->Vertex()[i].z = pkMaxMesh->verts[j].z;
        pkUniMesh->Normal()[i] = akNormal[j];
    }

// remap vertex face connectivity
    pkUniMesh->FQuantity() = rkPartition.size();
    pkUniMesh->Face() = new int[3*pkUniMesh->FQuantity()];
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        Face& rkFace = pkMaxMesh->faces[rkPartition[i]];
        if ( !pkUniMesh->HasReflection() )
        {
            for (j = 0; j < 3; j++)
                pkUniMesh->Face()[3*i+j] = aiVMap[rkFace.v[j]];
        }
        else{
            for (j = 2; j >= 0; j--)
                pkUniMesh->Face()[3*i+j] = aiVMap[rkFace.v[j]];
        }
    }
    delete[] aiVMap;
}

// PackColors() - Take a partition of a MAX mesh (represented by a vector of face
// indices), and pack the corresponding vertex colors into a UnimaterialMesh.
// [out] pkUniMesh - UniMaterial mesh to pack
// [in] pkMaxMesh - MAX mesh from which to extract colors
// [in] rkPartition - vector of face indices representing the mesh partition

void MgcSceneBuilder::PackColors(UnimaterialMesh* pkUniMesh, Mesh* pkMaxMesh, 
    vector<int>& rkPartition)
{
// get color indices used by the partition
    set<int> kCIndex;
    int i, j;
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        TVFace& rkCFace = pkMaxMesh->vcFace[rkPartition[i]];
        for (j = 0; j < 3; j++)
            kCIndex.insert(rkCFace.t[j]);
    }

// Pack into contiguous arrays.  The packing relies on the STL set having
// elements in increasing order.  If kCIndex[i] = j, then aiCMap[j] = i.
// The aiCMap array is made large enough to hold all possible j, but
// aiCMap[j] = -1 if there is no corresponding i.
    int iCMax = *kCIndex.rbegin();
    int* aiCMap = new int[iCMax+1];
    memset(aiCMap,0xFF,(iCMax+1)*sizeof(int));

    pkUniMesh->CQuantity() = kCIndex.size();
    pkUniMesh->Color() = new Mgc::ColorRGB[pkUniMesh->CQuantity()];

    set<int>::iterator kIter = kCIndex.begin();
    for (i = 0; i < (int)kCIndex.size(); i++, kIter++)
    {
        j = *kIter;
        aiCMap[j] = i;

        pkUniMesh->Color()[i].r= pkMaxMesh->vertCol[j].x;
        pkUniMesh->Color()[i].g = pkMaxMesh->vertCol[j].y;
        pkUniMesh->Color()[i].b = pkMaxMesh->vertCol[j].z;
    }

    // remap color face connectivity
    pkUniMesh->CFace() = new int[3*pkUniMesh->FQuantity()];
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        TVFace& rkCFace = pkMaxMesh->vcFace[rkPartition[i]];
        for (j = 0; j < 3; j++)
            pkUniMesh->CFace()[3*i+j] = aiCMap[rkCFace.t[j]];
    }
    delete[] aiCMap;
}

// PackTextures() - Take a partition of a MAX mesh (represented by a vector of face
// indices), and pack the corresponding texture coordinates into a UnimaterialMesh.
// [out] pkUniMesh - UniMaterial mesh to pack
// [in] pkMaxMesh - MAX mesh from which to extract texture coords
// [in] rkPartition - vector of face indices representing the mesh partition

void MgcSceneBuilder::PackTextures(UnimaterialMesh* pkUniMesh, Mesh* pkMaxMesh, 
    vector<int>& rkPartition)
{
// get texture indices used by the partition
    set<int> kTIndex;
    int i, j;
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        TVFace& rkTFace = pkMaxMesh->tvFace[rkPartition[i]];
        for (j = 0; j < 3; j++)
            kTIndex.insert(rkTFace.t[j]);
    }

// Pack into contiguous arrays.  The packing relies on the STL set having
// elements in increasing order.  If kTIndex[i] = j, then aiTMap[j] = i.
// The aiTMap array is made large enough to hold all possible j, but
// aiTMap[j] = -1 if there is no corresponding i.
    int iTMax = *kTIndex.rbegin();
    int* aiTMap = new int[iTMax+1];
    memset(aiTMap,0xFF,(iTMax + 1)*sizeof(int));

    pkUniMesh->TQuantity() = kTIndex.size();
    pkUniMesh->Texture() = new Mgc::Vector2[pkUniMesh->TQuantity()];

    set<int>::iterator kIter = kTIndex.begin();
    for (i = 0; i < (int)kTIndex.size(); i++, kIter++)
    {
        j = *kIter;
        aiTMap[j] = i;

        pkUniMesh->Texture()[i].x = pkMaxMesh->tVerts[j].x;
        pkUniMesh->Texture()[i].y = pkMaxMesh->tVerts[j].y;
    }

// remap texture face connectivity
    pkUniMesh->TFace() = new int[3*pkUniMesh->FQuantity()];
    for (i = 0; i < (int)rkPartition.size(); i++)
    {
        TVFace& rkTFace = pkMaxMesh->tvFace[rkPartition[i]];
        for (j = 0; j < 3; j++)
            pkUniMesh->TFace()[3*i+j] = aiTMap[rkTFace.t[j]];
    }
    delete[] aiTMap;
}

// GetVertexNormal() - Get a vertex normal, for a specified MAX mesh vertex index
// [in] pkMaxMesh - MAX mesh containing the vertex
// [in] iFace - index of face to which vertex belongs
// [in] iVertex - index of vertex for which to retrieve normal
// [returns] Mgc::Vector3, corresponding to normal

Mgc::Vector3 MgcSceneBuilder::GetVertexNormal(Mesh* pkMaxMesh, int iFace, int iVertex)
{
    Point3 kNormal;

    RVertex* pkRV = pkMaxMesh->getRVertPtr(iVertex);
    
    if ( pkRV->rFlags & SPECIFIED_NORMAL )
    {
        kNormal = pkRV->rn.getNormal();
    }
    else
    {
// If RVertex does not contain a specified normal vector, the normal
// is calculated from a smoothing group, if it exists.  If no such
// group exists, the face normal is used.
        Face& rkFace = pkMaxMesh->faces[iFace];
        DWORD dwSmoothingGroup = rkFace.smGroup;
        int iNumNormals = pkRV->rFlags & NORCT_MASK;
        if ( iNumNormals && dwSmoothingGroup )
        {
            if ( iNumNormals == 1 )
            {
// only one normal exists in group, rkRV already stored it
                kNormal = pkRV->rn.getNormal();
            }
            else
            {
// Lookup the normal from the smoothing group that contains the face.
                for (int i = 0; i < iNumNormals; i++)
                {
                    if ( pkRV->ern[i].getSmGroup() & dwSmoothingGroup ){
                        kNormal = pkRV->ern[i].getNormal();
                        break;
                    }
                }
            }
        }
        else
        {
// use the face normal when no smoothing group exists
            kNormal = pkMaxMesh->FaceNormal(iFace, true);
        }
    }

    return Mgc::Vector3(kNormal.x,kNormal.y,kNormal.z);
}
