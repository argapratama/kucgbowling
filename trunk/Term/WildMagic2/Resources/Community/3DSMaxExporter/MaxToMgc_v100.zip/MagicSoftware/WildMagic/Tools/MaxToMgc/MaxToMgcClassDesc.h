// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MAXTOMGCCLASSDESC_H
#define MAXTOMGCCLASSDESC_H

#include "MaxToMgc.h"

extern ClassDesc2* GetMaxToMgcDesc (); 

class MaxToMgcClassDesc : public ClassDesc2 
{
public:
    MaxToMgcClassDesc ();

    int IsPublic ();
    void* Create (BOOL loading = FALSE);
    const TCHAR* ClassName ();
    SClass_ID SuperClassID ();
    Class_ID ClassID ();
    const TCHAR* Category ();
    const TCHAR* InternalName ();
    HINSTANCE HInstance();
};

#include "MaxToMgcClassDesc.inl"

#endif // #define MAXTOMGCCLASSDESC_H
