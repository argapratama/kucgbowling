// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

///////////////////////////////////////////////////////////
// class MaxToMgc - Contruction / Destruction
///////////////////////////////////////////////////////////

// MaxToMgc() - constructor

MaxToMgc::MaxToMgc ()
{
    m_pkSceneBuilder = NULL;
}

// ~MaxToMgc() - destructor

MaxToMgc::~MaxToMgc () 
{
}

///////////////////////////////////////////////////////////
// class MaxToMgc - Standard methods exported from DLL
///////////////////////////////////////////////////////////

// ExtCount() - Number of extensions supported by plug-in.
// [returns] - constant 1 , only (*.mgc) supported

int MaxToMgc::ExtCount ()
{
    return 1;
}

// Ext() - Returns the i-th filename extension. Since we support only one extension,
// return it as a constant string. (N.B. Why does this not work as a string resource?)
// [in] iExt - index of extension required
// [returns] constant string corresponding to file extension

const TCHAR* MaxToMgc::Ext (int iExt)
{       
    return _T("mgc");
}

// LongDesc() - Long description of the file type to be exported
// [returns] resource string describing the file type

const TCHAR* MaxToMgc::LongDesc ()
{
    return GetResString(IDS_LONGDESCRIPTION);
}

// ShortDesc() - Returns short description of the file type to be exported. 
// [returns] resource string description of file type
    
const TCHAR* MaxToMgc::ShortDesc () 
{           
    return GetResString(IDS_SHORTDESCRIPTION);
}

// AuthorName - Return the name of the plug-in's author.
// [returns] resource string corresponding to name

const TCHAR* MaxToMgc::AuthorName ()
{           
    return GetResString(IDS_AUTHORNAME);
}

// CopyrightMessage() - returns the legal blurb
// [returns] empty string for the moment

const TCHAR* MaxToMgc::CopyrightMessage () 
{   
    return _T("");
}

// OtherMessage1() - Allows the plug-in to return additional info
// [returns] empty string for now

const TCHAR* MaxToMgc::OtherMessage1 () 
{       
    return _T("");
}

// OtherMessage2() - Allows the plug-in to return even more info
// [returns] empty string for now

const TCHAR* MaxToMgc::OtherMessage2 () 
{       
    return _T("");
}

// Version() - Get the version number of the exporter
// [returns] version info packed into unsigned int

unsigned int MaxToMgc::Version ()
{               
    return MAXTOMGC_VERSION;
}

// ShowAbout() - Allows the plug-in to display an About box. Not used yet.
// [in] hWnd - handle to About dialog's parent window

void MaxToMgc::ShowAbout (HWND hWnd)
{           
}

// SupportsOptions() - Max calls this method to determine which options are supported
// for a given file extension.
// [in] iExt - index of extension being queried
// [in] dwOptions - Bitmask of options being queried for this extension
// [returns] BOOL, TRUE if options supported, FALSE otherwise

BOOL MaxToMgc::SupportsOptions (int iExt, DWORD dwOptions)
{
// All options supported
    return TRUE;
}

// DoExport() - Restore the exporter's configuration from disk, display the 
// user interface, build and save the required Magic scene graph, and save
// the exporter's config to disk.
// [in] acFilename - Filename the user has chosen for the Magic scene graph
// [in] pkEport - interface pointer to access MAX's exporter specific functionality
// [in] pkMax - interface pointer to access general MAX functionality
// [in] bSuppressPrompts - Allow, or disallow user input
// [in] dwOptions - Determines whether to export entire scene, or selection only
// [throws] MaxToMagicException

int MaxToMgc::DoExport (const TCHAR* acFilename, ExpInterface* pkExport,Interface* pkMax, 
    BOOL bSuppressPrompts, DWORD dwOptions)
{
// Set parent window for display of warning and error message boxes
    MaxToMgcException::SetHWND(pkMax->GetMAXHWnd());

    try
    {
        m_pkMax = pkMax;
        INode* pkRootNode = NULL;
        BOOL bExportSelected;

        if ( dwOptions == SCENE_EXPORT_SELECTED )
        {
// User has chosen "Export Selected" - check to see that one and only one node
// (corresponding to the top level node of the hierarchy to be exported) has
// been selected
            if ( m_pkMax->GetSelNodeCount() != 1 )
                EXPORT_ERR(IDS_ERR_NODESELECT);
            pkRootNode = m_pkMax->GetSelNode(0);
            bExportSelected = true;
        }
        else
        {
// Export entire scene, starting from the root node in MAX
            pkRootNode = m_pkMax->GetRootNode();
            bExportSelected = false;
        }
// Get the path to the exporter plugin's config file
        m_strConfigFile = m_pkMax->GetDir(APP_PLUGCFG_DIR);
        m_strConfigFile += "\\";
        m_strConfigFile += CONFIG_FILENAME;
// Restore the exporter's configuration state
        ReadConfig();
// Show the exporter dialog
        if ( !bSuppressPrompts )
        {
            if ( !DialogBoxParam(GetPluginHINSTANCE(),MAKEINTRESOURCE(IDD_PANEL), 
                    GetActiveWindow(),MaxToMgcOptionsDlgProc,(LPARAM)this) )
            {
                return TRUE;
            }
        }
// Instantiate the scene graph builder object, which will convert the MAX scene
// to the corresponding Magic scene
        m_pkSceneBuilder = new MgcSceneBuilder();
// Initialize the Magic scene builder
        m_pkSceneBuilder->Initialize(acFilename,bExportSelected,&m_kEffectiveSettings,
            pkExport,pkMax,pkRootNode);
// Build the Magic scene graph corresponding to the MAX scene       
        m_pkSceneBuilder->Build();
// Save the Magic scene graph to disk
        m_pkSceneBuilder->Save();
// Save the exporter's configuration state
        WriteConfig();
    }
    catch( MaxToMgcException* pkEx )
    {
        pkEx->Show();
        delete pkEx;
    }
    
    if ( m_pkSceneBuilder != NULL ) 
        delete m_pkSceneBuilder;

    return TRUE;
}

///////////////////////////////////////////////////////////
// class MaxToMgc - Exporter config file methods 
///////////////////////////////////////////////////////////

// ReadConfig() - Restore the exporter's configuration state from disk. This
// configuration will correspond to the state in which the user left the user
// interface, on the previous occasion the exporter was run.
// [throws] MaxToMagicException

void MaxToMgc::ReadConfig ()
{
    FILE* fpConfig; 
// If config file doesn't exist (e.g. is this is the first time the exporter
// has been run), then default options will be used
    if( (fpConfig = fopen(m_strConfigFile,"rb")) == NULL ) 
        return;
    
    try
    {
        UINT uiVersion;
// Read the config file version number
        if ( fread(&uiVersion,sizeof(UINT),1,fpConfig) != 1 )
            EXPORT_WARN(IDS_WARN_CORRUPTCONFIGFILE);
// Verify that the exporter and config file versions match
        if ( uiVersion != MAXTOMGC_VERSION )
            EXPORT_ERR(IDS_WARN_BADVERSION);

        ExportSettings SettingsBuffer;
// Read the config settings
        if ( fread(&SettingsBuffer,sizeof(ExportSettings),1,fpConfig) != 1 )
            EXPORT_WARN(IDS_WARN_CORRUPTCONFIGFILE);
        
        fclose(fpConfig);
// Only override the default settings if the config file seems to be valid
        memcpy(&m_kUISettings,&SettingsBuffer,sizeof(ExportSettings));
    }
    catch( MaxToMgcException* pkEx )
    {
        pkEx->Show();
        delete pkEx;
    }
}

// user interface options will be saved.
// [throws] MaxToMagicException
 
void MaxToMgc::WriteConfig ()
{
    try
    {
        FILE* fpConfig; 
        if ( (fpConfig = fopen(m_strConfigFile,"wb")) == NULL )
            EXPORT_WARN(IDS_WARN_CREATECONFIGFILE);
// Write version number
        UINT uiVersion = MAXTOMGC_VERSION;
        if ( fwrite(&uiVersion,sizeof(UINT),1,fpConfig) != 1 )
            EXPORT_WARN(IDS_WARN_WRITECONFIG);
// Write exporter configuration
        if ( fwrite(&m_kUISettings,sizeof(ExportSettings),1,fpConfig) != 1 )
            EXPORT_WARN(IDS_WARN_WRITECONFIG);
        
        fclose(fpConfig);
    }
    catch( MaxToMgcException* pkEx )
    {
        pkEx->Show();
        delete pkEx;
    }
}

///////////////////////////////////////////////////////////
// class MaxToMgc - User interface dialog message 
// handling
///////////////////////////////////////////////////////////

// MaxToMgcOptionsDlgProc() - standard window procedure for user interface dialog. 

BOOL CALLBACK MaxToMgc::MaxToMgcOptionsDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
// Get a "this" pointer to the instance of the exporter currently in use
    MaxToMgc *pkExporter = (MaxToMgc*)GetWindowLongPtr(hWnd,GWLP_USERDATA); 

    switch(uMsg)
    {
    case WM_INITDIALOG:
// When the dialog is being initialized, MAX passes a "this" pointer to the current
// instance of the exporter in the message's LPARAM. Cache this for later retrieval
        pkExporter = (MaxToMgc *)lParam;
        SetWindowLongPtr(hWnd, GWLP_USERDATA, lParam); 
// Call the per-instance dialog initialization method
            return pkExporter->OnInitDialog(hWnd);
        case WM_COMMAND:
// User has altered the state of a user interface element - figure out what's changed
// and take the appropriate action
            switch ( LOWORD(wParam) ) 
            {
            case IDC_CHECK_MESHES:
                return pkExporter->OnMeshChecked(hWnd, IsDlgButtonChecked(hWnd, IDC_CHECK_MESHES));
            case IDC_CHECK_OBJECTS:
                return pkExporter->OnObjectsChecked(hWnd, IsDlgButtonChecked(hWnd, IDC_CHECK_OBJECTS));
            case IDC_CHECK_MODIFIERS:
                return pkExporter->OnModifiersChecked(hWnd, IsDlgButtonChecked(hWnd, IDC_CHECK_MODIFIERS));
            case IDC_RADIO_ALLFRAMES:
            case IDC_RADIO_KEYFRAMES:
                return pkExporter->OnEnableFrameSpinners(hWnd, TRUE);
            case IDC_RADIO_CURRENTFRAME:
                return pkExporter->OnEnableFrameSpinners(hWnd, FALSE);
            case IDOK:
                pkExporter->OnOK(hWnd);
                EndDialog(hWnd, 1);
                break;
            case IDCANCEL:
                EndDialog(hWnd, 0);
                break;
            default:
                return FALSE;
            }
            break;
// User has changed the state of a spinner control
        case CC_SPINNER_CHANGE:
            switch(LOWORD(wParam))
            {
            case IDC_SPINNER_ENDFRAME:
                return pkExporter->OnEndFrameSpinnerChanged(hWnd);
            case IDC_SPINNER_STARTFRAME:
                return pkExporter->OnStartFrameSpinnerChanged(hWnd);
            }
            break;
        case WM_CLOSE:
            EndDialog(hWnd, 0);
            return TRUE;
    }
    return FALSE;
}

// OnEnableFrameSpinners() - Enable, or disable frame spinner controls
// [in] hWnd - dialog's window handle
// [in] bEnabled - TRUE to enable spinner , FALSE to disable

BOOL MaxToMgc::OnEnableFrameSpinners (HWND hWnd, BOOL bEnabled)
{
    ISpinnerControl* pkSpinner = GetISpinner( GetDlgItem(hWnd,IDC_SPINNER_STARTFRAME)); 
    pkSpinner->Enable(bEnabled);
    ReleaseISpinner(pkSpinner); 
    pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_ENDFRAME)); 
    pkSpinner->Enable(bEnabled);
    
    return TRUE;
}

// OnEndFrameSpinnerChanged() - Called when user modifies the spinner control 
// corresponding to the end frame of the animation to be exported.
// [in] hWnd - dialog box's window handle

BOOL MaxToMgc::OnEndFrameSpinnerChanged (HWND hWnd)
{
// Get the start frame from the start frame spinner control
    ISpinnerControl* pkSpinner = GetISpinner(GetDlgItem(hWnd, IDC_SPINNER_STARTFRAME)); 
    int iStartFrame = pkSpinner->GetIVal();
    ReleaseISpinner(pkSpinner);
// Ensure that the end frame spinner doesn't display a value less than the start frame  
    pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_ENDFRAME)); 
    int iEndFrame = pkSpinner->GetIVal();
    if ( iStartFrame > iEndFrame )
        pkSpinner->SetValue(iStartFrame,FALSE);

    ReleaseISpinner(pkSpinner); 
    
    return TRUE;
}

// OnInitDialog() - Perform dialog initialization when the dialog gets a
// WM_INITDIALOG message.
// [in] hWnd - dialog's window handle

BOOL MaxToMgc::OnInitDialog (HWND hWnd)
{
    CenterWindow(hWnd,GetParent(hWnd)); 
// Set the user interface state - if a configuration file exists, then the state
// will correspond to the settings the user chose, the last time the exporter was
// used. Otherwise, default settings will be used
    CheckDlgButton(hWnd,IDC_CHECK_OBJECTS,m_kUISettings.bIncludeObjects);
    CheckDlgButton(hWnd,IDC_CHECK_LIGHTS,m_kUISettings.bIncludeLights);
    CheckDlgButton(hWnd,IDC_CHECK_MESHES,m_kUISettings.bIncludeMeshes);
    CheckDlgButton(hWnd,IDC_CHECK_CAMERAS,m_kUISettings.bIncludeCameras);

    CheckDlgButton(hWnd,IDC_CHECK_NORMALS,m_kUISettings.bIncludeNormals);       
    CheckDlgButton(hWnd,IDC_CHECK_MATERIALS,m_kUISettings.bIncludeMaterials);
    CheckDlgButton(hWnd,IDC_CHECK_VERTEXCOLS,m_kUISettings.bIncludeVertexColors);
    CheckDlgButton(hWnd,IDC_CHECK_TEXCOORDS,m_kUISettings.bIncludeTexCoords);
    CheckDlgButton(hWnd,IDC_CHECK_GENERATEMAPS,m_kUISettings.bGenerateMaps);
    
    CheckDlgButton(hWnd,IDC_CHECK_MODIFIERS,m_kUISettings.bIncludeModifiers);
    CheckDlgButton(hWnd,IDC_CHECK_SKINS,m_kUISettings.bIncludeSkins);

    CheckDlgButton(hWnd,IDC_RADIO_CURRENTFRAME,m_kUISettings.bIncludeCurrentFrame);
    CheckDlgButton(hWnd,IDC_RADIO_KEYFRAMES,m_kUISettings.bIncludeKeyFrames);
    CheckDlgButton(hWnd,IDC_RADIO_ALLFRAMES,m_kUISettings.bIncludeAllFrames);
    CheckDlgButton(hWnd,IDC_CHECK_USELOCALTIME,m_kUISettings.bUseLocalTime);
// Disable sub-options if the "Objects" check box is cleared
    if( !m_kUISettings.bIncludeObjects )
        OnObjectsChecked(hWnd,FALSE);
// Disable sub-options if the "Mesh" check box is cleared
    else if ( !m_kUISettings.bIncludeMeshes )
        OnMeshChecked(hWnd,FALSE);
// Disable sub-options if the "Modifiers" check box is cleared
    if ( !m_kUISettings.bIncludeModifiers )
        OnModifiersChecked(hWnd, FALSE);
// Get the number of animation frames in the MAX scene
    int iNumFrames = m_pkMax->GetAnimRange().Duration() / GetTicksPerFrame();
// Set up frame spinner controls
    ISpinnerControl* pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_STARTFRAME)); 
    pkSpinner->LinkToEdit(GetDlgItem(hWnd,IDC_EDIT_STARTFRAME),EDITTYPE_INT); 
    pkSpinner->SetLimits(0,iNumFrames,TRUE); 
    pkSpinner->SetScale(1.0f);
    pkSpinner->SetValue(0,FALSE);
    if ( m_kUISettings.bIncludeCurrentFrame ) 
        pkSpinner->Enable(FALSE);
    ReleaseISpinner(pkSpinner);

    pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_ENDFRAME)); 
    pkSpinner->LinkToEdit(GetDlgItem(hWnd,IDC_EDIT_ENDFRAME),EDITTYPE_INT); 
    pkSpinner->SetLimits(0,iNumFrames,TRUE); 
    pkSpinner->SetScale(1.0f);
    pkSpinner->SetValue(iNumFrames,FALSE);
    if ( m_kUISettings.bIncludeCurrentFrame ) 
        pkSpinner->Enable(FALSE);
    ReleaseISpinner(pkSpinner);

    return TRUE;
}

// OnMeshChecked() - Called when the "Mesh" checkbox has been set or cleared.
// Need to enable or disable all "Mesh" sub-options.
// [in] hWnd - dialog's window handle
// [in] bEnabled - TRUE if the checkbox has been set, FALSE if it has been cleared

BOOL MaxToMgc::OnMeshChecked (HWND hWnd, BOOL bEnabled)
{
// Enable (disable) sub-options
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_NORMALS),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_VERTEXCOLS),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_TEXCOORDS),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_MATERIALS),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_GENERATEMAPS),bEnabled);
        
    return TRUE;
}

// OnModifiersChecked() - Called when the "Modifiers" checkbox has been set or cleared.
// Need to enable or disable all "Modifiers" sub-options.
// [in] hWnd - dialog's window handle
// [in] bEnabled - TRUE if the checkbox has been set, FALSE if it has been cleared

BOOL MaxToMgc::OnModifiersChecked (HWND hWnd, BOOL bEnabled)
{
// Enable (disable) sub-options
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_SKINS),bEnabled);
    
    return TRUE;
}

// OnObjectsChecked() - Called when the "Objects" checkbox has been set or cleared.
// Need to enable, or disable all sub-options
// [in] hWnd - dialog's window handle
// [in] bEnabled - TRUE if the checkbox has been set, FALSE if it has been cleared

BOOL MaxToMgc::OnObjectsChecked (HWND hWnd, BOOL bEnabled)
{
// Enable (disable) sub-options
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_MESHES),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_CAMERAS),bEnabled);
    EnableWindow(GetDlgItem(hWnd,IDC_CHECK_LIGHTS),bEnabled);   
// The mesh check box, and its sub-options are themselves sub-options of the
// "Objects" group - need to cascade the change down to them too.
    OnMeshChecked(hWnd,bEnabled && IsDlgButtonChecked(hWnd, IDC_CHECK_MESHES));
    
    return TRUE;
}

// OnOK() - User has click dialog's OK button - Get exporter options selected by
// user prior to perforning export
// [in] hWnd - dialog box's window handle

void MaxToMgc::OnOK (HWND hWnd)
{
// Retrieve relevant exporter settings
    m_kUISettings.bIncludeObjects = IsDlgButtonChecked(hWnd,IDC_CHECK_OBJECTS);
    m_kUISettings.bIncludeLights = IsDlgButtonChecked(hWnd,IDC_CHECK_LIGHTS);
    m_kUISettings.bIncludeCameras = IsDlgButtonChecked(hWnd,IDC_CHECK_CAMERAS);
    m_kUISettings.bIncludeMeshes = IsDlgButtonChecked(hWnd,IDC_CHECK_MESHES);

    m_kUISettings.bIncludeNormals = IsDlgButtonChecked(hWnd,IDC_CHECK_NORMALS);
    m_kUISettings.bIncludeVertexColors = IsDlgButtonChecked(hWnd,IDC_CHECK_VERTEXCOLS);
    m_kUISettings.bIncludeTexCoords = IsDlgButtonChecked(hWnd,IDC_CHECK_TEXCOORDS);
    m_kUISettings.bIncludeMaterials = IsDlgButtonChecked(hWnd,IDC_CHECK_MATERIALS);
    m_kUISettings.bGenerateMaps = IsDlgButtonChecked(hWnd,IDC_CHECK_GENERATEMAPS);
 
    m_kUISettings.bIncludeModifiers = IsDlgButtonChecked(hWnd,IDC_CHECK_MODIFIERS);
    m_kUISettings.bIncludeSkins = IsDlgButtonChecked(hWnd,IDC_CHECK_SKINS);

    m_kUISettings.bIncludeAllFrames = IsDlgButtonChecked(hWnd,IDC_RADIO_ALLFRAMES);
    m_kUISettings.bIncludeKeyFrames = IsDlgButtonChecked(hWnd,IDC_RADIO_KEYFRAMES);
    m_kUISettings.bIncludeCurrentFrame = IsDlgButtonChecked(hWnd,IDC_RADIO_CURRENTFRAME);
    m_kUISettings.bUseLocalTime = IsDlgButtonChecked(hWnd,IDC_CHECK_USELOCALTIME);
// Get start and end frames from the relevant spinner controls
    if( m_kUISettings.bIncludeAllFrames || m_kUISettings.bIncludeKeyFrames )
    {
        ISpinnerControl* pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_STARTFRAME)); 
        m_kUISettings.iStartFrame = pkSpinner->GetIVal();
        ReleaseISpinner(pkSpinner);

        pkSpinner = GetISpinner(GetDlgItem(hWnd,IDC_SPINNER_ENDFRAME)); 
        m_kUISettings.iEndFrame = pkSpinner->GetIVal();
        ReleaseISpinner(pkSpinner);
    }
// If the user has unchecked the Objects, Mesh, or Modifiers boxes, then the sub-options of those
// categories will be disabled on the user interface, but they may still be checked, which means that
// the corresponding option in m_kUISettings will be set to TRUE. We need to determine the list of
// "effective" settings, which takes into account sub-options which have been disabled on the UI
    m_kEffectiveSettings = m_kUISettings;
    if ( !m_kUISettings.bIncludeObjects )
    {
        m_kEffectiveSettings.bIncludeCameras = FALSE;
        m_kEffectiveSettings.bIncludeLights = FALSE;
        m_kEffectiveSettings.bIncludeMeshes = FALSE;
    }
    if ( !m_kEffectiveSettings.bIncludeMeshes )
    {
        m_kEffectiveSettings.bIncludeNormals = FALSE;
        m_kEffectiveSettings.bIncludeMaterials = FALSE;
        m_kEffectiveSettings.bIncludeVertexColors = FALSE;
        m_kEffectiveSettings.bIncludeTexCoords = FALSE;
        m_kEffectiveSettings.bGenerateMaps = FALSE;
    }
    if ( !m_kUISettings.bIncludeModifiers )
    {
        m_kUISettings.bIncludeSkins = FALSE;
    }
}

// OnStartFrameSpinnerChanged() - Called when user modifies the spinner control
// corresponding to the starting frame of the animation to be exported
// [in] hWnd - dialog box's window handle

BOOL MaxToMgc::OnStartFrameSpinnerChanged (HWND hWnd)
{
// Get the start frame from the spinner control
    ISpinnerControl* pkSpinner = GetISpinner(GetDlgItem(hWnd, IDC_SPINNER_STARTFRAME)); 
    int iStartFrame = pkSpinner->GetIVal();
    ReleaseISpinner(pkSpinner);
// Get the end frame from the end frame spinner control and ensure the end frame is
// not less than the start frame
    pkSpinner = GetISpinner(GetDlgItem(hWnd, IDC_SPINNER_ENDFRAME)); 
    int iEndFrame = pkSpinner->GetIVal();
    if ( iEndFrame < iStartFrame )
        pkSpinner->SetValue(iStartFrame,FALSE);

    ReleaseISpinner(pkSpinner); 
    return TRUE;
}

