// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

#include "UnimaterialMesh.h"

//////////////////////////////////////////////////////////////
// Class MgcSceneBuilder - Construction / Destruction
//////////////////////////////////////////////////////////////

// MgcSceneBuilder() - Constructor

MgcSceneBuilder::MgcSceneBuilder ()
{
    m_acFilename = NULL;
    m_pkMax = NULL;
    m_pkExport = NULL;
    m_pkRootNode = NULL;    
    m_pkSettings = NULL;
    m_timeStart = m_timeEnd = 0;
}

// MgcSceneBuilder() - Destructor

MgcSceneBuilder::~MgcSceneBuilder ()
{
    if ( m_acFilename != NULL ) 
        delete [] m_acFilename;
    m_spkScene = NULL;
    vector<ModifierInfo*>::iterator it;
    for (it = m_kModList.begin(); it < m_kModList.end(); it++)
        delete (*it);
}

//////////////////////////////////////////////////////////////
// Class MgcSceneBuilder - Public Methods
//////////////////////////////////////////////////////////////

// Initialize() - Cache interface pointers provided by MAX, and perform
// sundry object initialization.
// [in] acFilename - string containing the filename to which the scene graph
//      should be saved
// [in] bExportSelected - true if the user chose to export a selected portion of
//      the scene hierarchy, false if the entire scene is to be exported
// [in] pkSettings - ExportSettings pointer with details of the exporter options
//      selected by the user
// [in] pkExport - interface pointer to MAX's exporter specific methods
// [in] pkMax - interface pointer to MAX's general functionality
// [in] pkRootNode - top level node in the hierarchy to be exported (not necessarily
//      the root node of the MAX scene, if the user chose "Export Selected")

void MgcSceneBuilder::Initialize (const TCHAR* acFilename, BOOL bExportSelected, 
    ExportSettings* pkSettings, ExpInterface* pkExport, Interface* pkMax, 
    INode* pkRootNode)
{
    m_pkMax = pkMax;
    m_pkExport = pkExport;
    m_pkRootNode = pkRootNode;  
    m_acFilename = new TCHAR[_tcslen(acFilename) + 1];
    _tcscpy(m_acFilename,acFilename);
    m_pkSettings = pkSettings;
    m_bExportSelected = bExportSelected;
    m_iTicksPerFrame = GetTicksPerFrame();

    if ( m_pkSettings->bIncludeCurrentFrame )
    {
// User has chosen to export the current frame only - get the time at which it occurs
        m_timeStart = m_pkMax->GetTime();
        m_timeEnd = m_timeStart;
    }
    else
    {
// Calculate the start time in ticks, of the first and last frames
        m_timeStart = m_pkSettings->iStartFrame * m_iTicksPerFrame;
        m_timeEnd = m_pkSettings->iEndFrame * m_iTicksPerFrame;
        if ( m_pkSettings->bUseLocalTime )
            m_timeOffset = m_timeStart;
        else
            m_timeOffset = 0;
    }
}


// Build() - Kick off the scene building process. First traverse the MAX
// scene hierarchy to process materials, then traverse again to build the
// node hierarchy, with a final traversal to apply modifiers. 

void MgcSceneBuilder::Build ()
{
    try
    {
// Construct the world root node of the Magic scene.
        m_spkScene = new Mgc::Node();
        Mgc::ZBufferStatePtr pkZBuffState;
        pkZBuffState = new Mgc::ZBufferState;
        pkZBuffState->Compare() = Mgc::ZBufferState::CF_LEQUAL;
        pkZBuffState->Enabled() = true;
        pkZBuffState->Writeable() = true;
        m_spkScene->SetRenderState(pkZBuffState);
// Traverse the MAX hierarchy, and process materials
        ConvertMaterials(m_pkRootNode); 
// Export entire scene
        if ( !m_bExportSelected )
        {
// Process global ambient light settings
            if ( m_pkSettings->bIncludeLights )
                BuildAmbientLight();
// Traverse the MAX hierarchy, building the corresponding Magic graph along the way
            for (int i = 0; i < m_pkRootNode->NumberOfChildren(); i++ )
                Traverse(m_pkRootNode->GetChildNode(i),m_spkScene);
        }
// Export selection only
        else
        {
            Traverse(m_pkRootNode,m_spkScene);
        }
        if ( m_pkSettings->bIncludeModifiers )
        {
            m_spkScene->UpdateGS(TicksToSec(0.0f));
            ApplyModifiers();
        }
    }
    catch ( MaxToMgcException* pkEx )
    {   
// Non-recoverable exception - clean up and exit
        if( IS_FATAL_EX(pkEx ) )
        {
            m_spkScene = NULL;
            throw pkEx;
        }
        else
        {
// This is just a warning - give the user some info.
            pkEx->Show();
            delete pkEx;
        }
    }
}

// Save() - Save the Magic scene to disk

void MgcSceneBuilder::Save ()
{
    Mgc::Stream kStream;
// If we are exporting from a selected node in the MAX hierarchy, rather than
// the scene root, the stream the Magic scene from the node immedately below the Magic
// scene's root.
    if ( m_bExportSelected )
        kStream.Insert(m_spkScene->GetChild(0));
    else
// Export the entire scene
        kStream.Insert(m_spkScene);
// Stream the scene to disk
    kStream.Save(m_acFilename); 
}

//////////////////////////////////////////////////////////////
// Class MgcSceneBuilder - Scene Traversal
//////////////////////////////////////////////////////////////

// Traverse() - Recursively traverse the MAX node hierarchy, constructing and 
// attaching the corresponding objects to the Magic scene graph.
// [in] pkMaxNode - the current node in the MAX hierarchy
// [in] pkMgcNode - the parent node of the next node to be attached to the 
//      Magic hierarchy
// [returns] bool - true if recursion is to continue, false otherwise

bool MgcSceneBuilder::Traverse (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
    Mgc::Node* pkMgcChildNode = NULL;

// Get the MAX node to evaluate its world state at the time of the start frame 
    ObjectState kObjectState = pkMaxNode->EvalWorldState(m_timeStart); 
    bool bSupported = true;

    try
    {
// Determine what kind of object we are dealing with, and process accordingly.
// If a node has an associated object (such as a mesh), and the user has decided not 
// to export objects of that type, we preserve the spatial relationship in the
// hierarchy by linking in a node with the same transform, but no associated object.
// Note that this allows us to export animation information only, independently of any
// geometry, if desired.
        if (kObjectState.obj)
        {
            switch ( kObjectState.obj->SuperClassID() )
            {
            case GEOMOBJECT_CLASS_ID:
                pkMgcChildNode = BuildGeometry(pkMaxNode,pkMgcNode);
                break;
            case CAMERA_CLASS_ID:
                break; // Not supported yet
            case LIGHT_CLASS_ID:
                if ( m_pkSettings->bIncludeLights && !pkMaxNode->IsHidden() )
                    BuildLight(pkMaxNode,pkMgcNode);
                break;
            case HELPER_CLASS_ID:
// "helper" nodes have no associated geometry( e.g. dummy, or bone nodes). Create
// and link a node with the same transform in the Magic scene graph
                pkMgcChildNode = BuildSpatial(pkMaxNode,pkMgcNode);
                break;
            default:
                bSupported = false;
                break;
            }
        }
        if ( !bSupported )
        {
// We don't know what to do with this node - generate an error with the name of this node, so that 
// we can tell the user exactly where the problem occurred.
            string strError = pkMaxNode->GetName();
            strError += ": ";
            strError += GetResString(IDS_ERR_UNSUPPORTEDNODETYPE);
            EXPORT_WARN((char *)strError.c_str());
        }
// Add the required animation info to the newly constructed node
        if ( pkMgcChildNode != NULL )
        {   
            if ( m_pkSettings->bIncludeKeyFrames )
                BuildKeyFrameController(pkMaxNode,pkMgcChildNode);
            else if ( m_pkSettings->bIncludeAllFrames )
                BuildFrameController(pkMaxNode,pkMgcChildNode);
        }
        
        if ( m_pkSettings->bIncludeModifiers )
        {
            ModifierInfo* pkModInfo = new ModifierInfo;
            FindModifiers(pkMaxNode,pkModInfo->kModifiers);
            if ( pkModInfo->kModifiers.empty() )
                delete pkModInfo;
            else
            {
                pkModInfo->pkNode = pkMaxNode;
                m_kModList.push_back(pkModInfo);
            }
        }
            
        int iNumChildren = pkMaxNode->NumberOfChildren();
        if ( iNumChildren == 0 ) 
            return true;

        for (int i = 0; i < iNumChildren; i++)
        {
            if( !Traverse(pkMaxNode->GetChildNode(i),pkMgcChildNode) 
                || m_pkMax->GetCancel() )
            {
                return false;
            }
        }
    }
    catch ( MaxToMgcException* pkEx )
    {
        if ( pkEx->GetSeverity() == Mgc::Exception::SEV_FATAL )
            throw pkEx;
        
        pkEx->Show();
        delete pkEx;
    }

    return true;
}

// BuildGeometry() - Build and link a geometric object into the scene
// [in] pkMaxNode - pointer node with geometry in MAX scene
// [in] pkMgcNode - parent to which to attach new node(s)

Mgc::Node* MgcSceneBuilder::BuildGeometry (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
    Mgc::Node* pkMgcChildNode = NULL;
    Mgc::Node* pkLink = NULL;

// In a MAX scene, geometry nodes can have geometry children, whereas with Magic,
// all geometry nodes must be leaf nodes. If this MAX node has geometry children,
// then a "link" node has to be created, in order to allow the geometry to be attached to 
// the Magic scene as a leaf node
    for (int i = 0; i < pkMaxNode->NumberOfChildren(); i++)
    {
        ObjectState kObjectState = pkMaxNode->EvalWorldState(m_timeStart); 
        if ( kObjectState.obj->SuperClassID() == GEOMOBJECT_CLASS_ID )
        {
            pkLink = BuildSpatial(pkMaxNode, pkMgcNode);
            break;
        }
    }

    if ( pkLink == NULL )
        pkLink = pkMgcNode;

    if ( m_pkSettings->bIncludeMeshes && !pkMaxNode->IsHidden() )
        pkMgcChildNode = BuildMesh(pkMaxNode,pkLink);
    else
        pkMgcChildNode = BuildSpatial(pkMaxNode, pkLink);

    if ( pkLink != pkMgcNode )
        return pkLink;

    return pkMgcChildNode;
}

//////////////////////////////////////////////////////////////
// Class MgcSceneBuilder - Utility methods
//////////////////////////////////////////////////////////////

// IsUniformScale() - Check a vector of scale values for the presence of
// non-uniform scaling.
// [in] rkScale - Mgc::Vector3 of scale values to be verified
// [returns] bool - true if uniform scale, false otherwise

bool MgcSceneBuilder::IsUniformScale( Mgc::Vector3& rkScale)
{
// Need fuzzy comparison
    return (rkScale.x > 0.0f 
            && APPROX_EQ(rkScale.x, rkScale.y) 
            && APPROX_EQ(rkScale.y, rkScale.z));
}

// IsUniformScale() - Check a vector of scale values for the presence of
// non-uniform scaling.
// [in] rkScale - Point3 containing scale values to be verified
// [returns] bool - true if uniform scale, false otherwise

bool MgcSceneBuilder::IsUniformScale (Point3& rkScale)
{
// Need fuzzy comparison
    return (rkScale.x > 0.0f 
            && APPROX_EQ(rkScale.x, rkScale.y) 
            && APPROX_EQ(rkScale.y, rkScale.z));
}

// Point3ProximityTest() - Fuzzy comparison, which determines whether two points
// have (almost) the same coordinates.
// [in] rkPoint1 - the first point in the comparison
// [in] rkPoint2 - the second point in the comparison
// [returns] bool, true if the points are close (within a specified tolerance), 
//           false otherwise

bool MgcSceneBuilder::Point3ProximityTest (Point3& rkPoint1, Point3& rkPoint2)
{   
    if ( fabs(rkPoint1.x - rkPoint2.x ) > MIN_DIFFERENCE 
        || fabs(rkPoint1.y - rkPoint2.y ) > MIN_DIFFERENCE 
        || fabs(rkPoint1.z - rkPoint2.z ) > MIN_DIFFERENCE )
    {
        return false;
    }

    return true;
}




