// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcException.h"
#include <windows.h>

using namespace Mgc;

//////////////////////////////////////////////////////////////
// Class Exception - base class for all exceptions
//////////////////////////////////////////////////////////////

Exception::Exception (char* acContext, int iCode, char* acDescription, int iSeverity) :
    m_acContext(acContext),
    m_iCode(iCode),     
    m_acDescription(acDescription),
    m_iSeverity(iSeverity),
    m_acName(NULL)
{
    if ( acContext )
    {
        m_acContext = new char[strlen(acContext) + 1];
        strcpy(m_acContext,acContext);
    }

    if ( acDescription )
    {
        m_acDescription = new char[strlen(acDescription) + 1];
        strcpy(m_acDescription,acDescription);
    }
}

Exception::~Exception ()
{
    if ( m_acName ) 
        delete [] m_acName;
    if ( m_acContext ) 
        delete [] m_acContext;
    if ( m_acDescription ) 
        delete [] m_acDescription;
}

void Exception::Show ( int iWindow )
{   
    char acMessage[500];
    *acMessage = '\0';
            
    if ( m_acContext )
    {
        strcat(acMessage,m_acContext);
        strcat(acMessage,"\n");
    }
    
    if ( m_iCode != 0 )
    {
        char acCode[20];
        sprintf(acCode,"%d\n",m_iCode);
        strcat(acMessage,acCode);
    }
        
    if ( m_acDescription )
    {
        strcat(acMessage,m_acDescription);
        strcat(acMessage,"\n");
    }

    if ( !m_acName )
        SetName("Magic Exception");

    if(  iWindow == 0 )
        OutputDebugString(acMessage);
    else
    {
        UINT uiType;
        switch ( m_iSeverity )
        {
        case SEV_WARN:
            uiType = MB_OK || MB_ICONEXCLAMATION;
            break;
        case SEV_FATAL:
            uiType = MB_OK || MB_ICONSTOP;
            break;
        default:
            uiType = MB_OK || MB_ICONSTOP;

        }
        ::MessageBox((HWND)iWindow,acMessage,m_acName,uiType);
    }
}

const char* Exception::GetName ()
{
    return m_acName;
}

const char* Exception::GetContext ()
{
    return m_acContext; 
}

const char* Exception::GetDescription ()
{
    return m_acDescription;
}

const int Exception::GetCode ()
{
    return m_iCode;
}

const int Exception::GetSeverity ()
{
    return m_iSeverity;
}

void Exception::SetName (char* acName)
{
    if ( m_acName ) 
        delete [] m_acName;
    m_acName = new char[strlen(acName) + 1];
    strcpy(m_acName,acName);
} 

void Exception::SetContext (char* acContext)
{
    if ( m_acContext ) 
        delete [] m_acContext;
    m_acContext = new char[strlen(acContext) + 1];
    strcpy(m_acContext,acContext);
}

void Exception::SetDescription (char* acDescription)
{
    if ( m_acDescription ) 
        delete [] m_acDescription;
    m_acDescription = new char[strlen(acDescription) + 1];
    strcpy(m_acDescription,acDescription);
}

void Exception::SetCode (int iCode)
{
    m_iCode = iCode;
}

void Exception::SetSeverity (int iSeverity)
{
    m_iSeverity = iSeverity;
}
