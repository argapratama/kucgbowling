// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"
#include "ikctrl.h"
#include <algorithm>
using namespace std;

// CompareKeyTimes() - helper method to sort KeyInfo objects into order of 
// ascending time
// [in] pkFirst - pointer to first KeyInfo object
// [in] pkSecond - pointer to sceond KeyInfo object

static bool CompareKeyTimes (KeyInfo* pkFirst, KeyInfo* pkSecond)
{
    return pkFirst->iTime < pkSecond->iTime;
}

// BuildKeyframeController() - Attaches a key frame controller to a key frame animated node
// Note that animation involving non-uniform scale is NOT supported
// [in] pkMaxNode - Key frame animated node in the MAX node hierarchy
// [in] pkMgcNode - Key frame animated node in the Magic scene graph
// [throws] MaxToMgcException

void MgcSceneBuilder::BuildKeyFrameController (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
// Check that this node is key frame animated
    Control* pkTMC = pkMaxNode->GetTMController();

    if ( !pkTMC->IsKeyable() )
    {
// The node is not keyframed, but it may still be animated, e.g. if it is an IK node. In that
// case, export all frames of the node's animation
        BuildFrameController(pkMaxNode,pkMgcNode);
        return;
    }
// For optimization, check whether the node's translation, rotation and scaling actually
// change over the time interval of interest
    AnimationTiming kTransTiming, kRotTiming, kScaleTiming;
    if ( !GetAnimationTiming(pkMaxNode,kTransTiming,kRotTiming,kScaleTiming) ) 
        return;

    Mgc::KeyframeController* pkMgcKFC = new Mgc::KeyframeController;
    int iNumScaleKeys, iNumRotKeys, iNumTransKeys;
    iNumScaleKeys = iNumRotKeys = iNumTransKeys = 0;
    vector<KeyInfo*> kKeyInfo;

// Process translation keys
    if ( kTransTiming.bActive )
    {
        Control* pkPC = pkTMC->GetPositionController();
        IKeyControl* pkKeyCon = GetKeyControlInterface(pkPC);
        iNumTransKeys = pkKeyCon->GetNumKeys();
        GetTransKeyInfo(iNumTransKeys,pkPC->ClassID(),pkKeyCon,kTransTiming,kKeyInfo);
    }
// Process rotation keys
    if ( kRotTiming.bActive )
    {
        Control* pkRC = pkTMC->GetRotationController();
        IKeyControl* pkKeyCon = GetKeyControlInterface(pkRC);
        iNumRotKeys = pkKeyCon->GetNumKeys();
        GetRotKeyInfo(iNumRotKeys,pkRC->ClassID(),pkKeyCon,kRotTiming,kKeyInfo);
    }
// Process scale keys
    if ( kScaleTiming.bActive )
    {
        Control* pkSC = pkTMC->GetScaleController();
        IKeyControl* pkKeyCon = GetKeyControlInterface(pkSC);
        iNumScaleKeys = pkKeyCon->GetNumKeys();
        GetScaleKeyInfo(iNumScaleKeys,pkSC->ClassID(),pkKeyCon,kScaleTiming,kKeyInfo);
    }

    if ( iNumTransKeys > 0 )
    {
        pkMgcKFC->SetTranslations(new Mgc::Vector3[iNumTransKeys]);
        pkMgcKFC->SetTranslationTimes(new float[iNumTransKeys]);
        pkMgcKFC->SetTranslationQuantity(iNumTransKeys);
    }
    if ( iNumRotKeys > 0 )
    {
        pkMgcKFC->SetRotations(new Mgc::Quaternion[iNumRotKeys]);
        pkMgcKFC->SetRotationTimes(new float[iNumRotKeys]);
        pkMgcKFC->SetRotationQuantity(iNumRotKeys);
    }
    if ( iNumScaleKeys > 0 )
    {
        pkMgcKFC->SetScales(new float[iNumScaleKeys]);
        pkMgcKFC->SetRotationTimes(new float[iNumScaleKeys]);
        pkMgcKFC->SetTranslationQuantity(iNumScaleKeys);
    }
// Sort the vector of KEYINFO objects in order of ascending time
    sort(kKeyInfo.begin(),kKeyInfo.end(),CompareKeyTimes);

    Mgc::Vector3 kTrans,*pkTKey = pkMgcKFC->GetTranslations();
    float* pfTTime = pkMgcKFC->GetTranslationTimes();
    Mgc::Quaternion* pkRKey = pkMgcKFC->GetRotations();
    float* pfRTime = pkMgcKFC->GetRotationTimes();
    Mgc::Matrix3 kRot;
    float* pfSKey = pkMgcKFC->GetScales();
    float* pfSTime = pkMgcKFC->GetScaleTimes();
    Mgc::Vector3 kScale;
    TimeValue timeNow = -1;

    for (int i = 0; i < (int)kKeyInfo.size(); i++ )
    {
        KeyInfo* pkInfo = kKeyInfo[i];
        if ( timeNow != pkInfo->iTime )
        {
            timeNow = pkInfo->iTime;
            GetLocalTransform(pkMaxNode,&kTrans,&kRot,&kScale,NULL,timeNow);
        }
        
        switch  ( pkInfo->eType )
        {
        case TRANSKEY:
            *pkTKey++ = kTrans;
            *pfTTime++ = TicksToSec(timeNow - m_timeOffset);
            break;
        case ROTKEY:
            pkRKey++->FromRotationMatrix(kRot);
            *pfRTime++ = TicksToSec(timeNow - m_timeOffset);
            break;
        case SCALEKEY:
            if ( !IsUniformScale(kScale) )
            {
                try
                {
                    string strError = pkMaxNode->GetName();
                    strError += ": ";
                    strError += GetResString(IDS_WARN_NONUNIFORMSCALE);
                    EXPORT_WARN((char*)strError.c_str());
                }
                catch ( MaxToMgcException* pkEx )
                {
                    pkEx->Show();
                    delete pkEx;
                }
            }
            *pfSKey++ = kScale.x;
            *pfSTime++ = TicksToSec(timeNow - m_timeOffset);
            break;
        }

        delete pkInfo;
    }

    pkMgcKFC->MinTime() = TicksToSec(m_timeStart - m_timeOffset);
    pkMgcKFC->MaxTime() = TicksToSec(m_timeEnd - m_timeOffset);
    pkMgcNode->AttachControl(pkMgcKFC);
}

// BuildFrameController() - Attaches a "frame controller" to a key frame animated node.
// This method exports ALL frames, rather than just key frames, by stuffing the node's transform
// for each frame into a Mgc::KeyframeController. This isn't optimal, in the sense that Magic will 
// still interpolate between the individual frames, however, it is useful in the case where the animator 
// uses IK animation, which the exporter currently doesn't support. Note that animation involving 
// non-uniform scale is NOT supported
// [in] pkMaxNode - Animated node in the MAX node hierarchy
// [in] pkMgcNode - Animated node in the Magic scene graph
// [throws] MaxToMgcException

void MgcSceneBuilder::BuildFrameController (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
// For optimization, check whether the node's translation, rotation and scaling actually
// change over the time interval of interest
    AnimationTiming kTransTiming, kRotTiming, kScaleTiming;
    if ( !GetAnimationTiming(pkMaxNode, kTransTiming, kRotTiming, kScaleTiming) )
        return;

    Mgc::KeyframeController* pkMgcKFC = new Mgc::KeyframeController;        
    Mgc::Vector3* akTData = NULL;
    Mgc::Quaternion* akRData = NULL;
    float* afTTime,* afRTime,* afSTime,* afSData;
    afTTime = afRTime = afSTime = afSData = NULL;
    TimeValue timeStart = 0, timeEnd = 0;
    int iNumFrames = (m_timeEnd - m_timeStart) / m_iTicksPerFrame + 1;

// Set up arrays for controller's translation vectors and corresponding times 
    if ( kTransTiming.bActive )
    {
        timeStart = kTransTiming.timeStart;
        timeEnd = kTransTiming.timeEnd;
        int iNumFrames = (kTransTiming.timeEnd - kTransTiming.timeStart) / m_iTicksPerFrame + 1;
        pkMgcKFC->SetTranslationQuantity(iNumFrames);
        akTData = new Mgc::Vector3[iNumFrames];
        afTTime = new float[iNumFrames];
    }
// Set up arrays for controller's rotation matrices and corresponding times 
    if ( kRotTiming.bActive )
    {
        if ( kRotTiming.timeStart < timeStart )
            timeStart = kRotTiming.timeStart;
        if ( kRotTiming.timeEnd > timeEnd )
            timeEnd = kRotTiming.timeEnd;
        int iNumFrames = (kRotTiming.timeEnd - kRotTiming.timeStart) / m_iTicksPerFrame + 1;
        pkMgcKFC->SetRotationQuantity(iNumFrames);
        akRData = new Mgc::Quaternion[iNumFrames];
        afRTime = new float[iNumFrames];
    }
// Set up arrays for controller's scale values and corresponding times 
    if ( kScaleTiming.bActive )
    {
        if ( kScaleTiming.timeStart < timeStart )
            timeStart = kScaleTiming.timeStart;
        if ( kScaleTiming.timeEnd > timeEnd )
            timeEnd = kScaleTiming.timeEnd;
        int iNumFrames = (kScaleTiming.timeEnd - kScaleTiming.timeStart) / m_iTicksPerFrame + 1;
        pkMgcKFC->SetScaleQuantity(iNumFrames);
        afSTime = new float[iNumFrames];
        afSData = new float[iNumFrames];
    }

    Mgc::Matrix3 kRot;
    Mgc::Vector3 kTrans;
    Mgc::Vector3 kScale;
    float *pfScale = NULL;  
    int iRFrameCounter, iTFrameCounter, iSFrameCounter;
    iRFrameCounter = iTFrameCounter = iSFrameCounter = 0;

// Loop through frame times, and build the controller's transforms for each frame 
    for (TimeValue timeNow = timeStart; timeNow <= timeEnd; timeNow += m_iTicksPerFrame)
    {
        GetLocalTransform(pkMaxNode, &kTrans, &kRot, &kScale, NULL, timeNow);
        if ( kRotTiming.bActive && timeNow >= kRotTiming.timeStart 
            && timeNow <= kRotTiming.timeEnd )
        {
            akRData[iRFrameCounter].FromRotationMatrix(kRot);
            afRTime[iRFrameCounter++] = TicksToSec(timeNow - m_timeOffset);
        }

        if ( kTransTiming.bActive && timeNow >= kTransTiming.timeStart 
            && timeNow <= kTransTiming.timeEnd )
        {
            akTData[iTFrameCounter] = kTrans;
            afTTime[iTFrameCounter++] = TicksToSec(timeNow - m_timeOffset);
        }

        if ( kScaleTiming.bActive && timeNow >= kScaleTiming.timeStart 
            && timeNow <= kScaleTiming.timeEnd )
        {
            if ( !IsUniformScale(kScale) )
            {
                string strError = pkMaxNode->GetName();
                strError += ": ";
                strError += GetResString(IDS_WARN_NONUNIFORMSCALE);
                try
                {
                    EXPORT_WARN((char*)strError.c_str());
                }
                catch ( MaxToMgcException* pkEx )
                {
                    pkEx->Show();
                    delete pkEx;
                }
            }
            afSData[iSFrameCounter] = kScale.x;
            afSTime[iSFrameCounter++] = TicksToSec(timeNow - m_timeOffset);
        }
    }

// Stuff the frame data into a Mgc::KeyframeController
    pkMgcKFC->SetRotations(akRData);
    pkMgcKFC->SetTranslations(akTData);
    pkMgcKFC->SetScales(afSData);
    pkMgcKFC->SetRotationTimes(afRTime);
    pkMgcKFC->SetTranslationTimes(afTTime);
    pkMgcKFC->SetScaleTimes(afSTime);
    pkMgcKFC->MinTime() = TicksToSec(m_timeStart - m_timeOffset);
    pkMgcKFC->MaxTime() = TicksToSec(m_timeEnd - m_timeOffset);
    pkMgcNode->AttachControl(pkMgcKFC);
}

// GetAnimationTiming() - Check whether a node is animated by determining if its transform 
// actually changes "significantly" over the time interval of interest.
// [in] pkNode - Node of interest in the MAX hierarchy.
// [out] rkTTiming - details of the node's translation timing
// [out] rkRTiming - details of the node's rotation timing
// [out] rkSTiming - details of the node's scale timing
// [returns] bool - TRUE if any component of the node's transform is animated, FALSE otherwise

bool MgcSceneBuilder::GetAnimationTiming (INode*pkNode, AnimationTiming &rkTTiming, 
    AnimationTiming& rkRTiming, AnimationTiming& rkSTiming)
{
    int iTicksPerFrame = GetTicksPerFrame();    
    Matrix3 kNodeTM;
    AffineParts kAffParts;
    Point3 kPrevTrans,kRotAxis,kPrevRotAxis,kPrevScaleFactor;
    float fRotAngle,fPrevRotAngle;
    rkTTiming.bActive = rkTTiming.bActive = rkSTiming.bActive = FALSE;

// Get initial components of node's transform
    kNodeTM = pkNode->GetNodeTM(m_timeStart) * Inverse(pkNode->GetParentTM(m_timeStart));
    decomp_affine(kNodeTM, &kAffParts);
    AngAxisFromQ(kAffParts.q,&fPrevRotAngle,kPrevRotAxis);
    kPrevTrans = kAffParts.t;
    kPrevScaleFactor = kAffParts.k;
// Loop through all frames, checking for a change in any component of the node's transform
    for (TimeValue timeNow = m_timeStart + iTicksPerFrame; timeNow <= m_timeEnd; timeNow += iTicksPerFrame)
    {
        kNodeTM = pkNode->GetNodeTM(timeNow) * Inverse(pkNode->GetParentTM(timeNow));
        decomp_affine(kNodeTM,&kAffParts);
        AngAxisFromQ(kAffParts.q,&fRotAngle,kRotAxis);

        if ( !rkTTiming.bActive )
        {
// Test current translation vector against previous vector for change
            if ( !Point3ProximityTest(kAffParts.t,kPrevTrans) )
            {
// Translation has changed - record time of the frame before the change
                rkTTiming.bActive = TRUE;
                rkTTiming.timeStart = timeNow - iTicksPerFrame;
                rkTTiming.timeEnd = timeNow;
            }
        }
        else
        {
// Advance the end time of the animated translation, if the translation vector is still changing
            if ( !Point3ProximityTest(kAffParts.t,kPrevTrans) )
                rkTTiming.timeEnd = timeNow;
        }
        if ( !rkRTiming.bActive )
        {
// Test current rotation angle and axis against previous angle and axis for change
            if ( fabs(fRotAngle - fPrevRotAngle) > MIN_DIFFERENCE || 
                !Point3ProximityTest(kRotAxis,kPrevRotAxis) )
            {
                rkRTiming.bActive = TRUE;
                rkRTiming.timeStart = timeNow - iTicksPerFrame;
                rkRTiming.timeEnd = timeNow;
            }
        }
        else
        {
            if ( fabs(fRotAngle - fPrevRotAngle) > MIN_DIFFERENCE || 
                !Point3ProximityTest(kRotAxis,kPrevRotAxis) )
            {
                rkRTiming.timeEnd = timeNow;
            }
        }

        if ( !rkSTiming.bActive )
        {
// Test current vector of scale values against previous vector, for changes 
            if ( !Point3ProximityTest(kAffParts.k,kPrevScaleFactor) )
            {
                rkSTiming.bActive = TRUE;
                rkSTiming.timeStart = timeNow - iTicksPerFrame;
                rkSTiming.timeEnd = timeNow;
            }
        }
        else
        {
            if ( !Point3ProximityTest(kAffParts.k,kPrevScaleFactor) )
                rkSTiming.timeEnd = timeNow;
        }

        fPrevRotAngle = fRotAngle;
        kPrevRotAxis = kRotAxis;
        kPrevTrans = kAffParts.t;
        kPrevScaleFactor = kAffParts.k;     
    }
    
    return rkTTiming.bActive || rkRTiming.bActive || rkSTiming.bActive;
}

// GetTranslationKeys() - Extract translation keys from a MAX node's position key controller
// [in/out] riNumKeys - as an input, number of key frames to process, as output, the
// corresponding number of Magic keyframes required
// [in] class_ID - MAX class ID for the type of position key controller
// [in] pkKeyCon - MAX node's position key frame controller
// [in] rkTTiming - details of the node's translation animation timing
// [in] rkKeyInfo - vector of KEYINFO objects in which to store the key type and timing info

void MgcSceneBuilder::GetTransKeyInfo (int& riNumKeys, Class_ID& rkClassID, 
    IKeyControl* pkKeyCon, AnimationTiming& rkTTiming, vector<KeyInfo*>& rkKeyInfo)
{       
    KeyInfo* pkInfo;
    int iKeys = riNumKeys;
    riNumKeys = 0;
// Process Tension/Continuity/Bias controller
    if ( rkClassID == Class_ID(TCBINTERP_POSITION_CLASS_ID,0) )
    {
        ITCBPoint3Key kKey;
        for ( int i = 0; i < iKeys; i++ )
        {
            pkKeyCon->GetKey(i,&kKey);
// Don't process the key if occurs before the animation actually starts...
            if ( kKey.time < rkTTiming.timeStart ) 
                continue;
// ... or after the animation has ended
            else if ( kKey.time > rkTTiming.timeEnd ) 
                break;
    
            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = TRANSKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }
    }
// Process Bezier controller
    else if ( rkClassID == Class_ID(HYBRIDINTERP_POSITION_CLASS_ID, 0) )
    {
        IBezPoint3Key kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);          
            if ( kKey.time < rkTTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkTTiming.timeEnd ) 
                break;

            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = TRANSKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }
    }
// Process Linear controller
    else if ( rkClassID == Class_ID(LININTERP_POSITION_CLASS_ID, 0) )
    {
        ILinPoint3Key kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);          
            if ( kKey.time < rkTTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkTTiming.timeEnd ) 
                break;

            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = TRANSKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }   
    }
}

// GetRotationKeys() - Extract rotation keys from a MAX node's rotation key controller
// [in/out] riNumKeys - as an input, number of key frames to process, as output, the
// corresponding number of Magic keyframes required
// [in] class_ID - MAX class ID for the type of rotation key controller
// [in] pkKeyCon - MAX node's rotation key frame controller
// [in] rkTTiming - details of the node's rotation animation timing
// [in] rkKeyInfo - vector of KEYINFO objects in which to store the key type and timing info

void MgcSceneBuilder::GetRotKeyInfo (int& riNumKeys, Class_ID& rkClassID, 
    IKeyControl* pkKeyCon, AnimationTiming& rkRTiming, vector<KeyInfo*>& rkKeyInfo)
{
    KeyInfo *pkInfo;
    int iKeys = riNumKeys;
    riNumKeys = 0;
// Process Tension/Continuity/Bias controller
    if ( rkClassID == Class_ID(TCBINTERP_ROTATION_CLASS_ID,0) )
    {
        ITCBRotKey kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);
            if(  kKey.time < rkRTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkRTiming.timeEnd ) 
                break;
            
            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = ROTKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }       
    }
// Process Bezier controller
    else if ( rkClassID == Class_ID(HYBRIDINTERP_ROTATION_CLASS_ID, 0) )
    {
        IBezQuatKey kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);          
            if ( kKey.time < rkRTiming.timeStart )
                continue;
            if ( kKey.time > rkRTiming.timeEnd ) 
                break;

            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = ROTKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }
    }
// Process Linear controller
    else if ( rkClassID == Class_ID(LININTERP_ROTATION_CLASS_ID, 0) )
    {
        ILinRotKey kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);           
            if ( kKey.time < rkRTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkRTiming.timeEnd ) 
                break;

            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = ROTKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }   
    }
}

// GetScaleKeys() - Extract scale keys from a MAX node's scale key controller
// [in/out] riNumKeys - as an input, number of key frames to process, as output, the
// corresponding number of Magic keyframes required
// [in] class_ID - MAX class ID for the type of scale key controller
// [in] pkKeyCon - MAX node's scale key frame controller
// [in] rkSTiming - details of the node's scale animation timing
// [in] rkKeyInfo - vector of KEYINFO objects in which to store the key type and timing info

void MgcSceneBuilder::GetScaleKeyInfo (int& riNumKeys, Class_ID& rkClassID, IKeyControl* pkKeyCon, 
    AnimationTiming& rkSTiming, vector<KeyInfo*>& rkKeyInfo)
{
    KeyInfo* pkInfo;
    int iKeys = riNumKeys;
    riNumKeys = 0;
// Process Tension/Continuity/Bias controller
    if ( rkClassID == Class_ID(TCBINTERP_SCALE_CLASS_ID,0) )
    {
        ITCBScaleKey kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);
// Don't process the key if occurs before the animation actually starts...
            if ( kKey.time < rkSTiming.timeStart )
                continue;
// ... or after the animation has ended
            else if ( kKey.time > rkSTiming.timeEnd ) 
                break;
                
            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = SCALEKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }
    }
// Process Bezier controller
    else if ( rkClassID == Class_ID(HYBRIDINTERP_SCALE_CLASS_ID, 0) )
    {
        IBezScaleKey kKey;
        for (int i = 0; i < iKeys; i++)
        {
            pkKeyCon->GetKey(i,&kKey);          
            if ( kKey.time < rkSTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkSTiming.timeEnd ) 
                break;

            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = SCALEKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }
    }
// Process Linear controller
    else if ( rkClassID == Class_ID(LININTERP_SCALE_CLASS_ID,0) )
    {
        ILinScaleKey kKey;
        for (int i = 0; i < iKeys; i++) 
        {
            pkKeyCon->GetKey(i,&kKey);          
            if ( kKey.time < rkSTiming.timeStart ) 
                continue;
            else if ( kKey.time > rkSTiming.timeEnd ) 
                break;
            pkInfo = new KeyInfo;
            pkInfo->iTime = kKey.time;
            pkInfo->eType = SCALEKEY;
            rkKeyInfo.push_back(pkInfo);
            riNumKeys++;
        }   
    }
}
