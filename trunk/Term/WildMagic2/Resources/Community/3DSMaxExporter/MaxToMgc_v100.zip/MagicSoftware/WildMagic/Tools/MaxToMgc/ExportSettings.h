// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef EXPORTSETTINGS_H
#define EXPORTSETTINGS_H

#include <wtypes.h>
///////////////////////////////////////////////////////////
// Class ExportSettings
///////////////////////////////////////////////////////////

// Class ExportSettings encapsulates the exporter options as specified by the user
// from the exporter dialog's user interface. The options specified in the
// constructor represent defaults, which will be overridden if a valid exporter
// configuration file exists.

class ExportSettings
{
public:
    ExportSettings ();

    void operator= (const ExportSettings& rkSettings);

public:
// Object settings
    BOOL bIncludeObjects;
    BOOL bIncludeCameras;
    BOOL bIncludeLights;
    BOOL bIncludeMeshes;
// Mesh settings
    BOOL bIncludeMaterials;
    BOOL bIncludeNormals;
    BOOL bIncludeTexCoords;
    BOOL bIncludeVertexColors;
    BOOL bGenerateMaps;
// Modifier settings
    BOOL bIncludeModifiers;
    BOOL bIncludeSkins;
// Animation settings
    BOOL bIncludeCurrentFrame;
    BOOL bIncludeKeyFrames;
    BOOL bIncludeAllFrames;
    BOOL bUseLocalTime;
    int iStartFrame;
    int iEndFrame;
};

#endif // #define EXPORTSETTINGS_H
