// Magic Software, Inc.
// http://www.magic-software.com
//
// PURPOSE:  Required file to allow the Wild Magic exporter plugin project
// in MagicSoftware\WildMagic\Tools\MaxToMgc to compile using Microsoft
// Visual C++ 7.0.
// 
// This file existed in Visual C++ 6.0, but does not in Visual C++ 7.0.
// The 3D Studio Max header file max.h tries to include ctl3d.h.  Rather
// than modify max.h, we have added this dummy include file that should
// be copied to the Max SDK include directory.  If you installed Max
// using the defaults, that path is c:\3dsmax4\maxsdk\Include.  Because
// max.h has #include <ctl3d.h>, the VC6 compiler will find the correct
// header.  The VC7 compiler will not find the system header and will
// therefore use this local one.  The file ctl3d.h has only #define's and
// function prototypes, so there should be no side effects caused by the
// absence of the (old) ctl3d.h.
