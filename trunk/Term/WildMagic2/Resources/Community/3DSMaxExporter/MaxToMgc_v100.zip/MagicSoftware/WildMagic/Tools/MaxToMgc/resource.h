//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MaxToMgc.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDS_INTERNALNAME                6
#define IDS_SHORTDESCRIPTION            7
#define IDS_AUTHORNAME                  8
#define IDS_LONGDESCRIPTION             9
#define IDS_EXTENSION                   10
#define IDS_ERR_NODESELECT              11
#define IDS_ERR_IMAGEDIMS               12
#define IDS_ERR_NONUNIFORMSCALE         13
#define IDS_WARN_NONUNIFORMSCALE        13
#define IDS_WARN_CORRUPTCONFIGFILE      14
#define IDS_WARN_BADVERSION             15
#define IDS_WARN_CREATECONFIGFILE       16
#define IDS_WARN_WRITECONFIG            17
#define IDS_ERR_UNSUPPORTEDNODETYPE     18
#define IDS_WARN_UNSUPPORTEDNODETYPE    18
#define IDS_WARN_MAPNOTFOUND            19
#define IDS_EXNAME_MAXTOMGC             20
#define IDS_WARN_UNSUPPORTEDLIGHT       21
#define IDD_PANEL                       101
#define IDB_WILDMAGIC                   106
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_CHECK_MESHES                1002
#define IDC_CHECK_LIGHTS                1003
#define IDC_CHECK_CAMERAS               1004
#define IDC_CHECK_NORMALS               1005
#define IDC_CHECK_VERTEXCOLS            1006
#define IDC_CHECK_TEXCOORDS             1007
#define IDC_CHECK_MATERIALS             1008
#define IDC_SPINNER_STARTFRAME          1009
#define IDC_EDIT_STARTFRAME             1010
#define IDC_EDIT_ENDFRAME               1011
#define IDC_SPINNER_ENDFRAME            1012
#define IDC_RADIO_CURRENTFRAME          1017
#define IDC_RADIO_KEYFRAMES             1018
#define IDC_RADIO_ALLFRAMES             1019
#define IDC_CHECK_USELOCALTIME          1020
#define IDC_CHECK_OBJECTS               1021
#define IDC_CHECK_GENERATEMAPS          1022
#define IDC_CHECK_MODIFIERS             1023
#define IDC_CHECK_SKINS                 1024
#define IDC_CHECK1                      1029
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
