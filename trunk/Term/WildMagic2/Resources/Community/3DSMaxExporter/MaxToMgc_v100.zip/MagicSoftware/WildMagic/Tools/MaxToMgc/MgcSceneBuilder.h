// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MGCSCENEBUILDER_H
#define MGCSCENEBUILDER_H

#include "MgcEngine.pkg"
#include "MgcAnimation.pkg"

#include "Max.h"
#include "decomp.h"
#include "shaders.h"
#include "bmmlib.h"
#include "MaterialManager.h"
#include "modstack.h"
#include "iskin.h"
#include "ExportSettings.h"
#include <string>
#include <set>
using namespace std;

#define MAX_ATTEN 1E-3f
#define MIN_DIFFERENCE 1E-3
#define APPROX_EQ(a, b) ((a) - (b) < MIN_DIFFERENCE)

///////////////////////////////////////////////////////////
// Class AnimationTiming
///////////////////////////////////////////////////////////

// Class AnimationTiming is a simple class which determines whether or not a given
// quantity is animated and, if so, the start and end times of the animation
 
class AnimationTiming
{
public:
    AnimationTiming() : bActive(FALSE), timeStart(0), timeEnd(0){}
public:
    BOOL bActive;
    TimeValue timeStart;
    TimeValue timeEnd;
};

//////////////////////////////////////////////////////////////
// Class ModifierInfo
//////////////////////////////////////////////////////////////

// Store modifier information for each node, as the scene is traversed

class ModifierInfo
{
public:
    INode* pkNode;
    vector<Modifier*> kModifiers;
};

//////////////////////////////////////////////////////////////
// Class KeyInfo
//////////////////////////////////////////////////////////////

// Store animation key information

typedef enum
{
    TRANSKEY = 0,
    ROTKEY,
    SCALEKEY
} KEYTYPE;

class KeyInfo
{
public:
    TimeValue iTime;
    KEYTYPE eType; 
};

///////////////////////////////////////////////////////////
// Class MgcSceneBuilder
///////////////////////////////////////////////////////////

// Class MgcSceneBuilder implements the core functionality of the exporter, 
// providing methods necessary to build the Wild Magic scene corresponding to a
// MAX scene, and save the scene to disk.

class WildExportUtils;
class ISkin;
class ISkinContextData;
class UnimaterialMesh;

class MgcSceneBuilder
{
public:
    MgcSceneBuilder();
    ~MgcSceneBuilder();

    void Initialize (const TCHAR* acFilename, BOOL bExportSelected, 
        ExportSettings* pkSettings, ExpInterface* pkExport, 
        Interface* pkMax, INode* pkRootNode);   
    void Build();
    void Save();
    
private:
// Scene traversal
    bool Traverse (INode* pkMaxNode, Mgc::Node* pkMgcNode);

// Node construction
    Mgc::Node* BuildMesh (INode* pkMaxNode, Mgc::Node* pkMgcNode);
    Mgc::Node* BuildSpatial (INode* pkMaxNode, Mgc::Node* pkMgcNode);

// Node transforms  
    void GetLocalTransform (INode* pkNode, Mgc::Vector3* pkTrn, Mgc::Matrix3 *pkRot, 
        Mgc::Vector3 *pkScale, Mgc::Matrix3 *pkOrient, TimeValue timeNow = 0);
    
    bool HasReflection (Matrix3& rkMatrix);
        
// Mesh related
    Mgc::Node* BuildGeometry (INode* pkMaxNode, Mgc::Node* pkMgcNode);
    TriObject* GetTriObject (INode* pkNode, bool* bNeedDel);
    Mgc::Vector3 GetVertexNormal(Mesh *pkMaxMesh, int iFace, int iVertex);  
    void PackColors (UnimaterialMesh *pkMesh, Mesh* pkMaxMesh, vector<int>& rkPartition);
    void PackTextures (UnimaterialMesh* pkUniMesh, Mesh* pkMaxMesh, vector<int>& rkPartition);
    void PackVertices (UnimaterialMesh* pkUniMesh, Mesh* pkMaxMesh, vector<int>& rkPartition, 
        Mgc::Vector3* akNormal);
    void ProcessMeshTransform (INode* pkNode, Mgc::TriMesh* pkMgcMesh); 
    void SplitGeometry (Mesh* pkTriMesh, int iMtlID, vector<UnimaterialMesh*>& rkUMeshes,
        bool bHasReflection);

// Material processing
    void ConvertMaterials (INode* pkTopNode);
    void CollectMaterials (INode* pkNode);
    void ConvertMaterial (Mtl& rkMtl, int iMtlID, int iSubNo, MaterialTree& rkTree);
    void ConvertTexture (Texmap& rkTex, Class_ID kClassID, int iSubNo, TextureTree& rkTree);

// Modifiers
    void ApplyModifiers ();
    void FindModifiers (INode* pkNode, vector<Modifier*>& rkModifiers);
    void ProcessSkin (INode* pkNode, Modifier* pkSkinMod);

// Animation
    void BuildKeyFrameController (INode* pkMaxNode, Mgc::Node* pkMgcNode);
    void BuildFrameController (INode* pkMaxNode, Mgc::Node* pkMgcNode);
    bool GetAnimationTiming (INode* pkNode, AnimationTiming& rkTTiming, 
        AnimationTiming& rkRTiming, AnimationTiming& rkSTiming);
    void GetTransKeyInfo (int &riNumKeys, Class_ID& rkClassID, IKeyControl* pkKeyCon, 
        AnimationTiming& rkTTiming, vector<KeyInfo*>& rkKeyInfo);
    void GetRotKeyInfo (int &riNumKeys, Class_ID& rkClassID, IKeyControl* pkKeyCon, 
        AnimationTiming& rkRTiming, vector<KeyInfo*>& rkKeyInfo);
    void GetScaleKeyInfo (int &riNumKeys, Class_ID& rkClassID, IKeyControl* pkKeyCon, 
        AnimationTiming& rkSTiming, vector<KeyInfo*>& rkKeyInfo);

// Lights
    void BuildAmbientLight (void);
    void BuildLight (INode* pkMaxNode, Mgc::Node* pkMgcNode);
    Mgc::Light* BuildPointLight (INode* pkNode);
    Mgc::Light* BuildSpotLight (INode* pkNode, struct LightState& rkLightState);
    Mgc::Light* BuildDirectionalLight (INode* pkNode);

// Utility
    bool IsUniformScale (Mgc::Vector3& rkScale);
    bool IsUniformScale (Point3& rkScale);
    bool Point3ProximityTest (Point3& rkPoint1, Point3& rkPoint2);

private:
    TCHAR* m_acFilename;
    ExpInterface* m_pkExport;
    Interface* m_pkMax;
    INode* m_pkRootNode;
    TimeValue m_timeStart;
    TimeValue m_timeEnd;
    TimeValue m_timeOffset;
    int m_iTicksPerFrame;
    Mgc::NodePtr m_spkScene;
    BOOL m_bExportSelected;
    ExportSettings* m_pkSettings;
    MaterialKeeper m_kMtlList;
    std::vector<MaterialTree> m_kMtlTree;
    std::vector<ModifierInfo*> m_kModList;
    static TCHAR* ms_aacMapName[NTEXMAPS];
    static TCHAR ms_acMapEnvironment[];
    static TCHAR ms_acMapGeneric[];
    static const char* ms_acEnvName[5];
};

#endif // #define MGCSCENEBUILDER_H