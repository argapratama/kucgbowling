// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MaxToMgcUtils.h"

// Plug-in's global(ugh!) module handle. At least limit its scope to this file
// so that only the following two functions can modify it

static HINSTANCE g_shInstance = NULL;

// SetHINSTANCE() - Store the plug-in's module HINSTANCE, as supplied by MAX    
// [in] hInstance - the plugin's module handle

void SetPluginHINSTANCE (HINSTANCE hInstance)
{
    g_shInstance = hInstance;
}

// GetHINSTANCE() - Retrieve the plug-in's module HINSTANCE
// [returns] HINSTANCE of the plug-in's module

HINSTANCE GetPluginHINSTANCE ()
{
    return g_shInstance;
}

// GetResString() - Load a string from the plug-in's resources
// [in] iResId - integer resource identifier of the string to load
// [returns]  - character string loaded from resource file, if successful,
// NULL otherwise

TCHAR* GetResString (int iResId)
{
// NOTE: maximum resource string length is 512 characters!
    static TCHAR acBuff[512];
    assert(g_shInstance != NULL);
    return LoadString(GetPluginHINSTANCE(),iResId,acBuff,sizeof(acBuff)) ? acBuff : NULL;
}
