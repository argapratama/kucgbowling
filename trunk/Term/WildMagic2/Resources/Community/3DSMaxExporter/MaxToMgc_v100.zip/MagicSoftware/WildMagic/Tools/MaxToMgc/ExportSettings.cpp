// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "ExportSettings.h"

ExportSettings::ExportSettings ()
{
    // Object settings
    bIncludeObjects = TRUE;
    bIncludeCameras = FALSE;
    bIncludeLights = TRUE;
    bIncludeMeshes = TRUE;
    // Mesh settings
    bIncludeMaterials = TRUE;
    bIncludeTexCoords = TRUE;
    bIncludeNormals = TRUE;
    bIncludeVertexColors = FALSE;
    bGenerateMaps = TRUE;
    // Modifier settings    
    bIncludeModifiers = TRUE;
    bIncludeSkins = TRUE;
    // Animation settings
    bIncludeCurrentFrame = TRUE;
    bIncludeKeyFrames = FALSE;
    bIncludeAllFrames = FALSE;
    bUseLocalTime = TRUE;
    iStartFrame = iEndFrame = 0;
}

void ExportSettings::operator= (const ExportSettings& rkSettings)
{
    // Object settings
    bIncludeObjects = rkSettings.bIncludeObjects;
    bIncludeCameras = rkSettings.bIncludeCameras;
    bIncludeLights = rkSettings.bIncludeLights;
    bIncludeMeshes = rkSettings.bIncludeMeshes;
    // Mesh settings
    bIncludeNormals = rkSettings.bIncludeNormals;
    bIncludeTexCoords = rkSettings.bIncludeTexCoords;
    bIncludeVertexColors = rkSettings.bIncludeVertexColors;
    bIncludeMaterials = rkSettings.bIncludeMaterials;
    bGenerateMaps = rkSettings.bGenerateMaps;
    // Modifier settings    
    bIncludeModifiers = rkSettings.bIncludeModifiers;
    bIncludeSkins = rkSettings.bIncludeSkins;
    // Animation settings
    bIncludeCurrentFrame = rkSettings.bIncludeCurrentFrame;
    bIncludeKeyFrames = rkSettings.bIncludeKeyFrames;
    bIncludeAllFrames = rkSettings.bIncludeAllFrames;
    bUseLocalTime = rkSettings.bUseLocalTime;
    iStartFrame = rkSettings.iStartFrame;
    iEndFrame = rkSettings.iEndFrame;
}

