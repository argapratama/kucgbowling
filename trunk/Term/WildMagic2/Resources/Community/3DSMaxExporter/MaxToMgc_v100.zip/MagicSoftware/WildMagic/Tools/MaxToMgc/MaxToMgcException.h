// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MAXTOMGCEXCEPTION_H
#define MAXTOMGCEXCEPTION_H

#include "MgcException.h"
#include "MaxToMgcUtils.h"
#include "resource.h"

#ifdef _DEBUG

#define EXPORT_ERR(description)\
    throw new MaxToMgcException(__FILE__,__LINE__,(description),Mgc::Exception::SEV_FATAL)

#define EXPORT_WARN(description)\
    throw new MaxToMgcException(__FILE__,__LINE__,(description),Mgc::Exception::SEV_WARN)

#else // #ifdef _DEBUG

#define EXPORT_ERR(description)\
    throw new MaxToMgcException(NULL,0,(description),Mgc::Exception::SEV_FATAL)

#define EXPORT_WARN(description)\
    throw new MaxToMgcException(NULL,0,(description),Mgc::Exception::SEV_WARN)

#endif // #ifdef _DEBUG

class MaxToMgcException : public Mgc::Exception
{
public:
    MaxToMgcException (char* acContext, int iCode, int iResId, int iSeverity); 
    MaxToMgcException (char* acContext, int iCode, char* acDescription, int iSeverity);
    
    void Show (void);
    static void SetHWND (HWND hWnd);

private:
    static HWND m_shWnd;
};

#include "MaxToMgcException.inl"

#endif // #define MAXTOMGCEXCEPTION_H
