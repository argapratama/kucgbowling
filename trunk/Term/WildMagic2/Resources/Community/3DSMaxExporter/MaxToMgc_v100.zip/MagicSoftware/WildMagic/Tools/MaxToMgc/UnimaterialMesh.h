// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef UNIMATERIALMESH_H
#define UNIMATERIALMESH_H

#include "MgcVector3.h"
#include "MgcVector2.h"
#include "MgcColorRGB.h"
#include "MgcMaterialState.h"
#include "MgcTextureState.h"
#include "MgcTriMesh.h"

class UnimaterialMesh
{
public:
    UnimaterialMesh ();
    int& VQuantity ();
    Mgc::Vector3*& Vertex ();
    Mgc::Vector3*& Normal ();
    int& CQuantity ();
    Mgc::ColorRGB*& Color ();
    int& TQuantity ();
    Mgc::Vector2*& Texture ();
    int& FQuantity ();
    int*& Face ();
    int*& CFace ();
    int*& TFace ();
    Mgc::MaterialStatePtr& MState();
    Mgc::TextureStatePtr& TState();
// A Max Vertex can have multiple UVW-coordinates.  Wild Magic supports
// only one UV-coordinate (W is ignored), so any Max Vertex with N
// UVW-coordinates must be duplicated into N Wild Magic vertices, each
// having a single UV-coordinate.
    void DuplicateGeometry ();
    Mgc::TriMesh* ToTriMesh ();
    bool& HasReflection();

    class VertexAttr
    {
    public:
        VertexAttr ();
        bool operator== (const VertexAttr& rkAttr) const;
        bool operator< (const VertexAttr& rkAttr) const;
        int m_iV, m_iC, m_iT;
    };

private:
    int m_iVQuantity;
    Mgc::Vector3* m_akVertex;
    Mgc::Vector3* m_akNormal;

    int m_iCQuantity;
    Mgc::ColorRGB* m_akColor;

    int m_iTQuantity;
    Mgc::Vector2* m_akTexture;

    int m_iFQuantity;
    int* m_aiFace;
    int* m_aiCFace;
    int* m_aiTFace;

    Mgc::MaterialStatePtr m_spkMState;
    Mgc::TextureStatePtr m_spkTState;

    bool m_bHasReflection;
};

#include "UnimaterialMesh.inl"

#endif // #define UNIMATERIALMESH_H
