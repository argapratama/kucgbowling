// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

// BuildAmbientLight() - Get MAX's global ambient light settings, and build the 
// corresponding Magic light

void MgcSceneBuilder::BuildAmbientLight (void)
{
    Color kAmbientColor = m_pkMax->GetAmbient(0,FOREVER);
    Mgc::AmbientLight *pkAmbientLight = new Mgc::AmbientLight;
    pkAmbientLight->Ambient().r = kAmbientColor.r;
    pkAmbientLight->Ambient().g = kAmbientColor.g;
    pkAmbientLight->Ambient().b = kAmbientColor.b;
    Mgc::LightState *pkLightState = new Mgc::LightState;
    pkLightState->Attach(pkAmbientLight);
    m_spkScene->SetRenderState(pkLightState);
}

// BuildLight() - Build a Magic light corresponding to a light in the MAX hierarchy.
// MAX's omnidirectional, directional and free spot lights are supported. Note that MAX 
// assigns a node in the scene graph to each light, whereas as Magic represents a light 
// as a render state applied to a node. The approach used here is to apply the Magic light 
// state to the node in the Magic scene graph which corresponds to the parent of the light 
// node in the MAX scene graph.
// [in] pkMaxNode - the MAX node representing the light.
// [in] pkMgcNode - the Magic node to which the corresponding light state will be applied.
// [throws] MaxToMgcException

void MgcSceneBuilder::BuildLight (INode* pkMaxNode, Mgc::Node* pkMgcNode)
{
// Get the light's parameters from MAX
    ObjectState kObjectState = pkMaxNode->EvalWorldState(m_timeStart);  
    GenLight* pkGenLight = (GenLight*)kObjectState.obj;
    struct LightState kMaxLightState;   
    Interval kValid = FOREVER;
    pkGenLight->EvalLightState(m_timeStart,kValid,&kMaxLightState);

    Mgc::Light* pkMgcLight = NULL;

    switch( pkGenLight->Type() ) 
    {
    case OMNI_LIGHT: // Magic Point Light
        pkMgcLight = BuildPointLight(pkMaxNode);
        break;
    case TSPOT_LIGHT:
    case FSPOT_LIGHT: // Magic Spot Light
        pkMgcLight = BuildSpotLight(pkMaxNode,kMaxLightState);
        break;
    case TDIR_LIGHT:
    case DIR_LIGHT: // MagicDirectional Light
        pkMgcLight = BuildDirectionalLight(pkMaxNode);
        break;
    default: // Light not supported
        EXPORT_WARN(IDS_WARN_UNSUPPORTEDLIGHT);
        break;
    }
    
    pkMgcLight->On() = (kMaxLightState.on != 0);
    pkMgcLight->Intensity() = kMaxLightState.intens;
    
// MAX lights seem to specify only one color. Use this color for
// Magic light's specular and diffuse colours
    if ( kMaxLightState.affectDiffuse )
    {
        pkMgcLight->Diffuse().r = kMaxLightState.color.r;
        pkMgcLight->Diffuse().g = kMaxLightState.color.g;
        pkMgcLight->Diffuse().b = kMaxLightState.color.b;
    }

    if ( kMaxLightState.affectSpecular )
    {
        pkMgcLight->Specular().r = kMaxLightState.color.r;
        pkMgcLight->Specular().g = kMaxLightState.color.g;
        pkMgcLight->Specular().b = kMaxLightState.color.b;
    }
    
// Set the attenuation parameters. MAX's decay model is simpler than Magic's,
// in that the decay can be either constant, linear or quadratic, but not a
// combination of all three
    if( pkGenLight->GetDecayType() != 0 )
    {
        pkMgcLight->Attenuate() = true;
        Interval kValid;
        float fDecayRadius = pkGenLight->GetDecayRadius(m_timeStart,kValid);
        
        switch( pkGenLight->GetDecayType() )
        {
        case 0:
            pkMgcLight->Constant() = 1.0f / MAX_ATTEN;
            pkMgcLight->Linear() = 0.0f;
            pkMgcLight->Quadratic() = 0;
            break;
        case 1:
            pkMgcLight->Constant() = 0.0f;
            pkMgcLight->Linear() = 1.0f / (fDecayRadius * MAX_ATTEN);
            pkMgcLight->Quadratic() = 0;
            break;
        case 2:
            pkMgcLight->Constant() = 0.0f;
            pkMgcLight->Linear() = 0.0f;
            pkMgcLight->Quadratic() = 1.0f / (fDecayRadius * fDecayRadius * MAX_ATTEN);
            break;
        } 
    }
    else if ( pkGenLight->GetUseAtten() )
    {
        float fFarAtten = kMaxLightState.attenEnd;
        pkMgcLight->Attenuate() = true;             
        pkMgcLight->Constant() = 0.0f;
        pkMgcLight->Linear() = 1.0f / (fFarAtten * MAX_ATTEN);
        pkMgcLight->Quadratic() = 0.0f;
    }
// Get the lighting render state for this node      
    Mgc::LightState* pkMgcLightState =
        MgcSmartPointerCast(Mgc::LightState,
        pkMgcNode->GetRenderState(Mgc::RenderState::RS_LIGHT));
    if( pkMgcLightState == NULL )
// If the node doesn't already have a lighting render state, then create a new one
        pkMgcLightState = new Mgc::LightState;
// Attach the light to the render state
    pkMgcLightState->Attach(pkMgcLight);
// Set the render state
    pkMgcNode->SetRenderState(pkMgcLightState);
}

// BuildSpotLight() - Construct a new spotlight object.
// [in] pkNode - light node in MAX hierarchy
// [in] rkLightState - the MAX light state of this light 
// [out] Mgc::Light pointer corresponding to the newly created Magic spotlight

Mgc::Light* MgcSceneBuilder::BuildSpotLight (INode* pkNode, struct LightState& rkLightState)
{
    Mgc::SpotLight* pkSpotLight = new Mgc::SpotLight;
    Mgc::Matrix3 kRotate;
// Get the spotlight's location from the MAX node's local translation
    GetLocalTransform(pkNode,&(pkSpotLight->Location()),&kRotate,NULL,NULL,m_timeStart);    
// MAX creates directional lights whose direction vector is along the negative
// z-axis. Get the direction vector for the Magic light by transforming a negative
// unit z-vector with the node's local rotation.
    pkSpotLight->Direction() = kRotate * -Mgc::Vector3::UNIT_Z;
// Set the spotlight angle 
    pkSpotLight->SetAngle(HALFPI * rkLightState.fallsize / 180);
// Set the spotlight exponent - this equation seems to give reasonable correspondance
// between MAX and Magic
    pkSpotLight->Exponent() = 128 * ((rkLightState.fallsize - rkLightState.hotsize) / 
        rkLightState.fallsize);
    
    return pkSpotLight;
}

// BuildPointLight() - Construct a new point light object
// [in] pkNode - light node in MAX hierarchy
// [out] Mgc::Light pointer corresponding to the newly created Magic point light

Mgc::Light* MgcSceneBuilder::BuildPointLight (INode* pkNode)
{
    Mgc::PointLight* pkPointLight = new Mgc::PointLight;
// Set the point light's location
    GetLocalTransform(pkNode,&(pkPointLight->Location()),NULL,NULL,NULL,m_timeStart);
    
    return pkPointLight;
}

// BuildDirectionalLight() - Construct a new directional light object.
// [in] pkNode - light node in MAX hierarchy
// [out] Mgc::Light pointer corresponding to the newly created Magic directional light

Mgc::Light* MgcSceneBuilder::BuildDirectionalLight (INode* pkNode)
{
    Mgc::DirectionalLight* pkDirLight = new Mgc::DirectionalLight;
    Mgc::Matrix3 kRotate;
// MAX creates directional lights whose direction vector is along the negative
// z-axis. Get the direction vector for the Magic light by transforming a negative
// unit z-vector with the node's local rotation.
    GetLocalTransform(pkNode,NULL,&kRotate,NULL,NULL,m_timeStart);  
    pkDirLight->Direction() = kRotate * -Mgc::Vector3::UNIT_Z;
    return pkDirLight;
}
