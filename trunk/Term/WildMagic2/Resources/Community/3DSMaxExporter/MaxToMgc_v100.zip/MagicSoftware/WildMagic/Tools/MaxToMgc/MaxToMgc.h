// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MAXTOMGC_H
#define MAXTOMGC_H

#include <crtdbg.h>
#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"

#include "MaxToMgcUtils.h"
#include "MaxToMgcException.h"
#include "ExportSettings.h"

#define MAXTOMGC_CLASS_ID   Class_ID(0x554dbc9c, 0x8f27519)
#define MAXTOMGC_VERSION 100
#define CONFIG_FILENAME "MaxToMgc.cfg"

///////////////////////////////////////////////////////////
// Class MaxToMgc
///////////////////////////////////////////////////////////

// Class MaxToMgc encapsulates functionality handle exporter configuration, and
// the user's interaction with the user interface. It also provides implementations
// of standard methods required of MAX exporter plug-ins.

class MgcSceneBuilder;

class MaxToMgc : public SceneExport 
{
public:
//Constructor/Destructor
    MaxToMgc ();
    ~MaxToMgc ();       

// Standard DLL exports
    int ExtCount ();                    
    const TCHAR* Ext (int iExt);    
    const TCHAR* LongDesc ();           
    const TCHAR* ShortDesc ();          
    const TCHAR* AuthorName ();         
    const TCHAR* CopyrightMessage ();   
    const TCHAR* OtherMessage1 ();      
    const TCHAR* OtherMessage2 ();      
    unsigned int Version ();                
    void ShowAbout (HWND hWnd);         
    BOOL SupportsOptions (int iExt, DWORD dwOptions);
    int DoExport (const TCHAR* acFilename, ExpInterface* pkExport, Interface* pkMax, 
        BOOL bSuppressPrompts = FALSE, DWORD dwOptions = 0);

// User interface dialog's window procedure
    static BOOL CALLBACK MaxToMgcOptionsDlgProc( HWND hWnd, UINT uMsg, WPARAM wParam, 
        LPARAM lParam);

// User interface dialog message handlers   
    BOOL OnEnableFrameSpinners (HWND hWnd, BOOL bEnabled);
    BOOL OnEndFrameSpinnerChanged (HWND hWnd);
    BOOL OnInitDialog (HWND hWnd);
    BOOL OnMeshChecked (HWND hWnd, BOOL bEnabled);
    BOOL OnModifiersChecked (HWND hWnd, BOOL bEnabled);
    BOOL OnObjectsChecked (HWND hWnd, BOOL bEnabled);
    void OnOK (HWND hWnd);
    BOOL OnStartFrameSpinnerChanged (HWND hWnd);

private:
// Exporter configuration file methods
    void ReadConfig();
    void WriteConfig();
    
private:
    MgcSceneBuilder* m_pkSceneBuilder;
    Interface* m_pkMax;
    ExportSettings m_kUISettings;
    ExportSettings m_kEffectiveSettings;
    TSTR m_strConfigFile;
};

#endif // #define MAXTOMGC_H
