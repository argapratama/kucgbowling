// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

//////////////////////////////////////////////////////////////
// Class MgcSceneBuilder - Node transform methods
//////////////////////////////////////////////////////////////

// GetLocalTransform() - Evaluate a node's local transform. MAX's node transform
// access methods all supply the node's world space transform, so we have to
// perform some manipulation to get the node's local transform. Also, MAX can
// supply the node's pivot transform (via GetNodeTM), or object transform,
// (via GetObjectTM() ,GetObjTMBeforeWSM() and GetObjTMAfterWSM()). The "object offset"
// refers to the transformation of the object associated with the node, relative to
// the node's pivot, so the node's pivot transform is not in itself sufficient to
// locate the object in local coordinates. Note that the object transform access 
// methods return the aggregate of the node's pivot and object offset transformations.

// [in] pkNode - A node in the MAX hierarchy
// [out] pkTrn - pointer to Mgc::Vector3 which will receive the translation component
// [out] pkRot - pointer to Mgc::Matrix3 which will receive the rotation component
// [out] pkScale - pointer to Mgc::Vector3 which will receive the scale component
// [out] pkScaleOrient - pointer to Mgc::Matrix3 which will receive the scale 
//       orientation component
// [in] timeNow - time at which the node's transform is to be evaluated

void MgcSceneBuilder::GetLocalTransform (INode* pkNode, Mgc::Vector3* pkTrn, 
    Mgc::Matrix3* pkRot, Mgc::Vector3* pkScale, Mgc::Matrix3* pkOrient,
    TimeValue timeNow)
{
// Evaluate the node's object transform, in local coordinates 
    INode* pkParent = pkNode->GetParentNode();
    Matrix3 kLocalTM = pkNode->GetObjTMAfterWSM(timeNow) * 
        Inverse(pkParent->GetObjTMAfterWSM(timeNow));   
// Decompose the transform into its affine parts
    AffineParts kAffParts;
    decomp_affine(kLocalTM,&kAffParts);
// Extract the translation component, if required
    if ( pkTrn != NULL )
    {
        pkTrn->x = kAffParts.t.x;
        pkTrn->y = kAffParts.t.y;
        pkTrn->z = kAffParts.t.z;
    }
// Extract the "essential rotation", if required
    if ( pkRot != NULL )
    {
        Mgc::Quaternion(kAffParts.q.w,kAffParts.q.x,kAffParts.q.y,kAffParts.q.z).
            ToRotationMatrix(*pkRot);
        *pkRot = *pkRot * kAffParts.f * Mgc::Matrix3::IDENTITY;
        *pkRot = pkRot->Transpose();
    }
// Get the scale component if required  
    if ( pkScale != NULL )
    {
        pkScale->x = kAffParts.k.x;
        pkScale->y = kAffParts.k.y;
        pkScale->z = kAffParts.k.z;
    }
// The scale orientation matrix is a rotation into the coordinate system where the 
// scaling is done
    if ( pkOrient != NULL )
    {
        Mgc::Quaternion(kAffParts.u.w, kAffParts.u.x, kAffParts.u.y, kAffParts.u.z).
            ToRotationMatrix(*pkOrient);    
        *pkOrient = pkOrient->Transpose();
    }
}

// HasReflection() - Determines whether a transformation matrix contains a reflection
// [in] rkMatrix - the matrix to test
// [returns] bool - true if a reflection is present, false otherwise

bool MgcSceneBuilder::HasReflection (Matrix3& rkMatrix)
{
// Negative scaling is allowed in MAX to support reflection.  Determine
// if a reflection is present by computing the determinant of the
// matrix and testing if it is negative.
    Point3 kCross = CrossProd(rkMatrix.GetRow(0),rkMatrix.GetRow(1));
    float fDot = DotProd(kCross,rkMatrix.GetRow(2));
    return fDot < 0.0f;
}