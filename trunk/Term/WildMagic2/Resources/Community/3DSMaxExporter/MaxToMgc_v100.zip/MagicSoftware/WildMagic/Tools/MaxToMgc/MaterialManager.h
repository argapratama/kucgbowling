// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MATERIALMANAGER_H
#define MATERIALMANAGER_H

#include "MgcMaterialState.h"
#include "MgcTextureState.h"
#include "Max.h"
#include <vector>

class TextureTree
{
public:
    TextureTree (Mgc::TextureState* pkTState = NULL);
    Mgc::TextureStatePtr& TState ();
    void SetNumSubtextures (int iTextures);
    TextureTree& GetSubtextureTree (int iSubtexture);

private:
    Mgc::TextureStatePtr m_spkTState;
    std::vector<TextureTree> m_kSubtexture;
};

//----------------------------------------------------------------------------

class MaterialTree
{
public:
    MaterialTree (Mgc::MaterialState* pkMState = NULL);
    int NumSubmaterialTrees ();
    MaterialTree& GetSubmaterialTree (int iSubtree);
    TextureTree& GetSubtextureTree (int iSubtree);
    Mgc::MaterialStatePtr& MState ();
    int NumSubtextureTrees ();
    void SetNumSubtextures (int iNumTextures);
    void SetNumSubmaterials (int iNumMaterials);
    Mgc::TextureStatePtr& TState (int iSubtexture);

private:
    Mgc::MaterialStatePtr m_spkMState;
    std::vector<MaterialTree> m_kSubmaterial;
    std::vector<TextureTree> m_kSubtexture;
};

//----------------------------------------------------------------------------

class MaterialKeeper
{
public:
    bool Add (Mtl* pkMtl);
    int GetID (Mtl* pkMtl);
    int Count();
    Mtl* Get(int iMtlID);

private:
    std::vector<Mtl*> m_kMtlList;   
};

//----------------------------------------------------------------------------

#include "MaterialManager.inl"

#endif // #define MATERIALMANAGER_H
