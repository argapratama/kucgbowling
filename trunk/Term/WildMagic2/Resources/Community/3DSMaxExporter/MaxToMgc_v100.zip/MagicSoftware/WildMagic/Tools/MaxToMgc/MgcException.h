// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#ifndef MGCEXCEPTION_H
#define MGCEXCEPTION_H

#include <stdio.h>
#include <string.h>

#define THROW_ERR(szContext, iCode, szDescription)\
    throw new Exception(szContext, iCode, szDescription, Mgc::Exception::SEV_FATAL);

#define THROW_WARN(szContext, iCode, szDescription)\
    throw new Exception(szContext, iCode, szDescription, Mgc::Exception::SEV_WARN);

#define IS_FATAL_EX(pkException)\
    (pkException->GetSeverity() == Mgc::Exception::SEV_FATAL)

namespace Mgc
{

//////////////////////////////////////////////////////////////
// Class Exception - base class for all exceptions
//////////////////////////////////////////////////////////////

class Exception
{
public:
    Exception (char* acContext = NULL, int iCode = 0, char* acDescription = NULL,
        int iSeverity = SEV_FATAL);

    virtual ~Exception ();

    virtual void Show (int iWindow);
    virtual const char* GetName ();
    virtual const char* GetContext ();
    virtual const char* GetDescription ();
    virtual const int GetCode ();
    virtual const int GetSeverity ();
    virtual void SetName (char* acName);
    virtual void SetContext (char* acContext);
    virtual void SetDescription (char* acDescription);
    virtual void SetCode (int iCode);
    virtual void SetSeverity (int iSeverity);

    const enum
    {
        SEV_WARN = 0,
        SEV_FATAL
    };

protected:
    int m_iCode;
    int m_iSeverity;
    char* m_acName;
    char* m_acContext;
    char* m_acDescription;
};

} // namespace Mgc

#endif // #define MGCEXCEPTION_H