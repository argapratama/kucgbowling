// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

// ApplyModifiers() - Apply the modifier info that was collected during node traversal.
// The only modifier currently supported is skin.

void MgcSceneBuilder::ApplyModifiers ()
{
    std::vector<ModifierInfo*>::iterator i;
    std::vector<Modifier*>::iterator j;

    for ( i = m_kModList.begin(); i  < m_kModList.end(); i++ )
    {
        for ( j = (*i)->kModifiers.begin(); j < (*i)->kModifiers.end(); j++ )
        {
            if ( (*j)->ClassID() == SKIN_CLASSID )
                ProcessSkin((*i)->pkNode, *j);
        }       
    }
}

// FindModifiers() - Determine whether a node has any modifiers, if so, store them for later use
// [in] pkNode - Pointer to a MAX node
// [out] rkModifiers - vector in which to store modifier pointers

void MgcSceneBuilder::FindModifiers (INode* pkMaxNode,vector<Modifier*>& rkModifiers)
{
// Get object from node. Abort if no object.
    Object* pkObj = pkMaxNode->GetObjectRef();
    if ( !pkObj ) 
        return;

// Is derived object ?
    while ( pkObj->SuperClassID() == GEN_DERIVOB_CLASS_ID )
    {
        // Yes -> Cast.
        IDerivedObject* pkDerObj = static_cast<IDerivedObject*>(pkObj);
// Iterate over all entries of the modifier stack.
        int iModStackIndex = 0;
        while ( iModStackIndex < pkDerObj->NumModifiers() )
        {
// Get current modifier.
            Modifier* pkMod = pkDerObj->GetModifier(iModStackIndex);
            if( pkMod ) 
                rkModifiers.push_back(pkMod);
            iModStackIndex++;
        }
        pkObj = pkDerObj->GetObjRef();
    }
}

// ProcessSkin() - Construct skin controller. If the MAX mesh required splitting during the export,
// each Magic mesh created during the split will need its own skin controller. The skin vertex
// offsets are calculated using the world transformed mesh vertices at the animation's starting time,
// and the bones' world transforms. 
// [in] pkMaxNode - Pointer to MAX node to which skin modifier is applied
// [in] pkSkinMod - pointer to the skin modifier object

void MgcSceneBuilder::ProcessSkin (INode* pkMaxNode,Modifier* pkSkinMod)
{
    int i,j,k,l;

    bool bNeedDel;
    TriObject* pkTriObj = GetTriObject(pkMaxNode,&bNeedDel);
    Mesh* pkMesh = &pkTriObj->GetMesh();
// Get interface to MAX's skin controller classes
    ISkin* pkSkin = (ISkin*)pkSkinMod->GetInterface(I_SKIN);
    ISkinContextData* pkSkinData = pkSkin->GetContextInterface(pkMaxNode);

    int iBoneQuantity = pkSkin->GetNumBones();
    Mgc::Node** apkMgcBones = new Mgc::Node*[iBoneQuantity]; 
    Mgc::Matrix3* akBoneWorldRot = new Mgc::Matrix3[iBoneQuantity];
    Mgc::Vector3* akBoneWorldTrans = new Mgc::Vector3[iBoneQuantity];

// Loop through bones, storing the initial bone rotations and translations, and retrieving the 
// corresponding Magic nodes from the scene
    INode* pkBoneNode;
    for (i = 0; i < iBoneQuantity; i++)
    {
        pkBoneNode = pkSkin->GetBone(i);
        apkMgcBones[i] = MgcStaticCast(Mgc::Node,
            m_spkScene->GetObjectByName(pkBoneNode->GetName()));
        akBoneWorldRot[i] = apkMgcBones[i]->WorldRotate();
        akBoneWorldTrans[i] = apkMgcBones[i]->WorldTranslate();
    }

    vector<Mgc::TriMesh*> akMgcMeshes;
// Check whether the Magic node corresponding to the MAX skin mesh is itself a 
// mesh node (in which case, the MAX mesh didn't require splitting earlier in the export) or
// whether the node is a "link" node (i.e. the parent node of a number of split meshes)
    Mgc::Node* pkLinkNode = MgcStaticCast(Mgc::Node,
        m_spkScene->GetObjectByName(pkMaxNode->GetName())); 

    if( pkLinkNode->GetQuantity() == 0 )
    {
        akMgcMeshes.push_back(MgcStaticCast(Mgc::TriMesh,pkLinkNode));
    }
    else
    {
        for (i = 0; i < pkLinkNode->GetQuantity(); i++)
        {
            Mgc::Spatial* pkChild = pkLinkNode->GetChild(i);
            if ( strncmp(pkChild->GetName(),pkLinkNode->GetName(),
                strlen(pkLinkNode->GetName())) == 0 )
            {
                akMgcMeshes.push_back(MgcStaticCast(Mgc::TriMesh,pkChild));
            }
        }
    }

    int* aiVertsPerBone = new int[iBoneQuantity];
    Mgc::SkinController::SkinVertex** apkSkinVertBuff = 
        new Mgc::SkinController::SkinVertex*[iBoneQuantity];
    Mgc::SkinController::SkinVertex** ppkSkinVertBuff = 
        new Mgc::SkinController::SkinVertex*[iBoneQuantity];    
// Build a skin controller for each of the Magic meshes corresponding to the MAX mesh
    for( i = 0; i < (int)akMgcMeshes.size(); i++ )
    {
        memset(aiVertsPerBone,0,sizeof(int) * iBoneQuantity);
        vector<int> kVertList;
// Determine which vertices from the MAX mesh are contained in this Magic mesh, and store the MAX
// vertex indices.
        Mgc::Vector3* pkV = akMgcMeshes[i]->Vertices();
        for (j = 0; j < akMgcMeshes[i]->GetVertexQuantity(); j++, pkV++)
        {
            for( k = 0; k < pkMesh->getNumVerts(); k++ )
            {
                Mgc::Vector3 kVert(pkMesh->verts[k].x,pkMesh->verts[k].y,
                    pkMesh->verts[k].z);

                if( *pkV == kVert ){
                    kVertList.push_back(k);
                    break;
                }
            }
        }
// Figure out how many vertices are influenced by each bone             
        vector<int>::iterator it;
        for (it = kVertList.begin(); it < kVertList.end(); it++)
        {
            k = *it;
            for (j = 0; j < pkSkinData->GetNumAssignedBones(k); j++)
                aiVertsPerBone[pkSkinData->GetAssignedBone(k,j)]++;
        }
// If the MAX mesh has been split, then it is possible that some bones will have no influence on 
// the current Magic mesh, hence we need to determine the number of "active" bones for this mesh
        int iActiveBoneQuantity = 0;
        for (j = 0; j < iBoneQuantity; j++)
        {
            if ( aiVertsPerBone[j] > 0 )
                iActiveBoneQuantity++;
        }

        Mgc::SkinController* pkMgcSkin = new Mgc::SkinController;
        pkMgcSkin->BoneQuantity() = iActiveBoneQuantity;
        Mgc::Node** apkActiveBones = new Mgc::Node* [iActiveBoneQuantity];
        int* aiVertsPerActiveBone = new int[iActiveBoneQuantity];   
// Store the Magic node pointers corresponding to the active bones for this Magic mesh
        for (j = 0, k = 0; j < iBoneQuantity; j++)
        {
            if ( aiVertsPerBone[j] > 0 )
            {
                apkActiveBones[k] = apkMgcBones[j];
                aiVertsPerActiveBone[k++] = aiVertsPerBone[j];
                apkSkinVertBuff[j] = new Mgc::SkinController::SkinVertex[aiVertsPerBone[j]];
            }
        }

        pkMgcSkin->Bones() = apkActiveBones;
        pkMgcSkin->SkinVertexQuantities() = aiVertsPerActiveBone;
        
        memcpy(ppkSkinVertBuff,apkSkinVertBuff,sizeof(Mgc::SkinController::SkinVertex*) * 
            iBoneQuantity);
// Get the Mgc mesh's world transform
        Mgc::Matrix3 kMeshWorldRot = akMgcMeshes[i]->WorldRotate();
        Mgc::Vector3 kMeshWorldTrans = akMgcMeshes[i]->WorldTranslate();
// Loop through the list of MAX vertices for this Magic mesh, obtaining the vertex weights,
// and calculating the vertex offsets
        for (it = kVertList.begin(), j = 0; it < kVertList.end(); it++, j++ )
        {
            k = *it;
            for (l = 0; l < pkSkinData->GetNumAssignedBones(k); l++)
            {
                int iBoneIndex = pkSkinData->GetAssignedBone(k,l);
                ppkSkinVertBuff[iBoneIndex]->m_iIndex = j;
                ppkSkinVertBuff[iBoneIndex]->m_fWeight = pkSkinData->GetBoneWeight(k,l);                
                Mgc::Vector3 kOffset = kMeshWorldRot * 
                    akMgcMeshes[i]->Vertices()[j] + kMeshWorldTrans;
                kOffset = akBoneWorldRot[iBoneIndex].Transpose() * 
                    (kOffset - akBoneWorldTrans[iBoneIndex]);
                ppkSkinVertBuff[iBoneIndex]->m_kOffset = kOffset;
                ppkSkinVertBuff[iBoneIndex]++;
            }
        }
        
        Mgc::SkinController::SkinVertex** apkSkinVertex = 
            new Mgc::SkinController::SkinVertex* [iActiveBoneQuantity];

        for (j = 0, k = 0; j < iBoneQuantity; j++)
        {
            if ( aiVertsPerBone[j] > 0 )
            {
                apkSkinVertex[k] = new Mgc::SkinController::SkinVertex[aiVertsPerBone[j]];
                memcpy(apkSkinVertex[k++],apkSkinVertBuff[j],aiVertsPerBone[j] * 
                    sizeof(Mgc::SkinController::SkinVertex));
                delete [] apkSkinVertBuff[j];
            }
        }
        
        pkMgcSkin->SkinVertices() = apkSkinVertex;
        pkMgcSkin->MinTime() = 0.0f;
        pkMgcSkin->MaxTime() = TicksToSec(m_timeEnd - m_timeStart);
        akMgcMeshes[i]->AttachControl(pkMgcSkin);
    }
    
    if( bNeedDel ) 
        delete pkTriObj;
    delete [] apkSkinVertBuff;
    delete [] ppkSkinVertBuff;
    delete [] apkMgcBones;
    delete [] aiVertsPerBone;
    delete [] akBoneWorldRot;
    delete [] akBoneWorldTrans;
}