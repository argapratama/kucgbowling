// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "UnimaterialMesh.h"

#include <cassert>
#include <algorithm>
#include <set>
using namespace std;
using namespace Mgc;

//----------------------------------------------------------------------------
UnimaterialMesh::UnimaterialMesh ()
{
    m_iVQuantity = 0;
    m_akVertex = NULL;
    m_akNormal = NULL;
    m_iCQuantity = 0;
    m_akColor = NULL;
    m_iTQuantity = 0;
    m_akTexture = NULL;
    m_iFQuantity = 0;
    m_aiFace = NULL;
    m_aiCFace = NULL;
    m_aiTFace = NULL;
    m_bHasReflection = false;
}
//----------------------------------------------------------------------------
void UnimaterialMesh::DuplicateGeometry ()
{
    // build array of vertex+attribute objects
    vector<VertexAttr>* akVArray = new vector<VertexAttr>[m_iVQuantity];
    int i;
    for (i = 0; i < 3*m_iFQuantity; i++)
    {
        VertexAttr kAttr;

        kAttr.m_iV = m_aiFace[i];

        if ( m_iCQuantity > 0 )
            kAttr.m_iC = m_aiCFace[i];

        if ( m_iTQuantity > 0 )
            kAttr.m_iT = m_aiTFace[i];

        akVArray[m_aiFace[i]].push_back(kAttr);
    }

    // compute total number of vertices needed
    int iNewVQuantity = 0;
    for (i = 0; i < m_iVQuantity; i++)
    {
        // remove duplicate uvw indices
        sort(akVArray[i].begin(),akVArray[i].end());
        vector<VertexAttr>::iterator pkEnd = unique(akVArray[i].begin(),
            akVArray[i].end());
        akVArray[i].erase(pkEnd,akVArray[i].end());
        iNewVQuantity += akVArray[i].size();
    }

    // Wild Magic geometry data
    Vector3* akNewVertex = new Vector3[iNewVQuantity];
    Vector3* akNewNormal = new Vector3[iNewVQuantity];

    Mgc::ColorRGB* akNewColor = NULL;
    if ( m_iCQuantity > 0 )
        akNewColor = new Mgc::ColorRGB[iNewVQuantity];

    Vector2* akNewTexture = NULL;
    if ( m_iTQuantity > 0 )
        akNewTexture = new Vector2[iNewVQuantity];

    int j, k;
    for (i = 0, k = 0; i < m_iVQuantity; i++)
    {
        vector<VertexAttr>& rkVArray = akVArray[i];
        int iSize = rkVArray.size();
        for (j = 0; j < iSize; j++, k++)
        {
            akNewVertex[k] = m_akVertex[i];
            akNewNormal[k] = m_akNormal[i];

            VertexAttr kAttr = rkVArray[j];

            if ( akNewColor )
                akNewColor[k] = m_akColor[kAttr.m_iC];

            if ( akNewTexture )
                akNewTexture[k] = m_akTexture[kAttr.m_iT];

            // save duplicated attributes for later use
            kAttr.m_iV = k;
            rkVArray.push_back(kAttr);
        }
    }

    // modify the connectivity array to reflect the duplication of vertices
    for (i = 0; i < m_iFQuantity; i++)
    {
        int iThreeI = 3*i;
        int* aiVIndex = m_aiFace+iThreeI;
        int* aiCIndex = ( m_iCQuantity > 0 ? m_aiCFace+iThreeI : NULL );
        int* aiTIndex = ( m_iTQuantity > 0 ? m_aiTFace+iThreeI : NULL );
        for (j = 0; j < 3; j++)
        {
            VertexAttr kAttr;
            kAttr.m_iV = aiVIndex[j];

            if ( aiCIndex )
                kAttr.m_iC = aiCIndex[j];

            if ( aiTIndex )
                kAttr.m_iT = aiTIndex[j];

            // VArray has N original vertices and N duplicates
            vector<VertexAttr>& rkVArray = akVArray[aiVIndex[j]];
            int iHalfSize = rkVArray.size()/2;
            for (k = 0; k < iHalfSize; k++)
            {
                if ( rkVArray[k] == kAttr )
                {
                    // found correct (vert,color,uv) pair, update vert index
                    aiVIndex[j] = rkVArray[iHalfSize+k].m_iV;
                    break;
                }
            }
        }
    }

    delete[] m_akVertex;
    delete[] m_akNormal;
    delete[] m_akColor;
    delete[] m_akTexture;
    delete[] m_aiTFace;

    m_iVQuantity = iNewVQuantity;
    m_akVertex = akNewVertex;
    m_akNormal = akNewNormal;
    m_akColor = akNewColor;
    m_akTexture = akNewTexture;

    delete[] akVArray;
}
//----------------------------------------------------------------------------
Mgc::TriMesh* UnimaterialMesh::ToTriMesh()
{
    Mgc::TriMesh *pkTriMesh = new Mgc::TriMesh(m_iVQuantity,m_akVertex,m_akNormal,
        m_akColor,m_akTexture, m_iFQuantity, m_aiFace);
    
    if( m_spkMState )
        pkTriMesh->SetRenderState(m_spkMState);
            
    if( m_spkTState )
        pkTriMesh->SetRenderState(m_spkTState);

    return pkTriMesh;
}
//----------------------------------------------------------------------------
UnimaterialMesh::VertexAttr::VertexAttr ()
{
    m_iV = -1;
    m_iC = -1;
    m_iT = -1;
}
//----------------------------------------------------------------------------
bool UnimaterialMesh::VertexAttr::operator== (const VertexAttr& rkAttr) const
{
    return m_iV == rkAttr.m_iV && m_iC == rkAttr.m_iC && m_iT == rkAttr.m_iT;
}
//----------------------------------------------------------------------------
bool UnimaterialMesh::VertexAttr::operator< (const VertexAttr& rkAttr) const
{
    if ( m_iV < rkAttr.m_iV )
        return true;
    if ( m_iV > rkAttr.m_iV )
        return false;

    if ( m_iC < rkAttr.m_iC )
        return true;
    if ( m_iC > rkAttr.m_iC )
        return false;

    return m_iT < rkAttr.m_iT;
}
