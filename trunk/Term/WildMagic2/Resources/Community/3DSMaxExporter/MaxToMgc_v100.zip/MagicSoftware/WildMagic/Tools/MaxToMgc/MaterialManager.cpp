// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MaterialManager.h"
using namespace std;

int MaterialTree::NumSubmaterialTrees ()
{
    return (int)m_kSubmaterial.size();
}
//----------------------------------------------------------------------------
void MaterialTree::SetNumSubtextures (int iTextures)
{
    m_kSubtexture.resize(iTextures);
}
//----------------------------------------------------------------------------
void MaterialTree::SetNumSubmaterials (int iMaterials)
{
    m_kSubmaterial.resize(iMaterials);
}
//----------------------------------------------------------------------------
MaterialTree& MaterialTree::GetSubmaterialTree (int iSubtree)
{
    return m_kSubmaterial[iSubtree];
}
//----------------------------------------------------------------------------
TextureTree& MaterialTree::GetSubtextureTree (int iSubtree)
{
    return m_kSubtexture[iSubtree];   
}
//----------------------------------------------------------------------------
int MaterialTree::NumSubtextureTrees ()
{
    return (int)m_kSubtexture.size();
}
//----------------------------------------------------------------------------
Mgc::TextureStatePtr& MaterialTree::TState (int iSubtexture)
{
   return m_kSubtexture[iSubtexture].TState();
}
//----------------------------------------------------------------------------
Mgc::TextureStatePtr& TextureTree::TState ()
{
    return m_spkTState;
}
//----------------------------------------------------------------------------
void TextureTree::SetNumSubtextures (int iTextures)
{
    m_kSubtexture.resize(iTextures);
}
//----------------------------------------------------------------------------
TextureTree& TextureTree::GetSubtextureTree (int iSubtexture)
{
    return m_kSubtexture[iSubtexture];
}
//----------------------------------------------------------------------------
bool MaterialKeeper::Add (Mtl* pkMtl)
{
    if ( pkMtl == NULL ) 
        return false;
    
    vector<Mtl*>::iterator i;

    for (i = m_kMtlList.begin(); i < m_kMtlList.end(); i++)
        if ( *i == pkMtl ) 
            return FALSE;
        
    m_kMtlList.push_back(pkMtl);

    return true;
}
//----------------------------------------------------------------------------
Mtl* MaterialKeeper::Get (int iMtlID)
{
    if ( iMtlID > (int)m_kMtlList.size() || iMtlID < 0 ) 
        return NULL;

    return m_kMtlList[iMtlID];
}
//----------------------------------------------------------------------------
int MaterialKeeper::GetID (Mtl* pkMtl)
{
    if( pkMtl == NULL ) 
        return -1;

    for( int i = 0; i < (int)m_kMtlList.size(); i++ )
        if( m_kMtlList[i] == pkMtl ) 
            return i;

    return -1;
}
//----------------------------------------------------------------------------
int MaterialKeeper::Count ()
{
    return m_kMtlList.size();
}


