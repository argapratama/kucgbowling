Notes for the Wild Magic exporter.

1.  If you are using Microsoft Visual C++ 6, the project will compile as is.
    However, if you have Microsoft Visual C++ 7, the file ctl3d.h that existed
    in VC6 no longer exists in VC7.  The Max SDK header max.h attempts to
    include ctl3d.h.  The file appears not to be needed, so you can either
    modify max.h (not recommended) or copy the dummy file (recommended)
      C:\MagicSoftware\WildMagic\ToolsMaxToMgc\CopyFileToMaxSdkInclude\ctl3d.h
    to the Max SDK include directory.  If you used the defaults on
    installation of Max, the directory is
      C:\3dsmax4\maxsdk\Include

2.  You cannot mix library files for VC6 and VC7.  We had built VC6 libraries
    for MagicFM.lib and MagicWM.lib.  The VC7 Release build of MaxToMgc that
    tried to link in these libraries complained about undefined symbols in
    MagicWM.lib related to STL.  For some reason VC7 Debug build compiled and
    linked just fine.

