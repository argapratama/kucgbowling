// Magic Software, Inc.
// http://www.magic-software.com
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Magic Software is supplied under the terms of a license
// agreement and may not be copied or disclosed except in accordance with the
// terms of that agreement.  The various license agreements may be found at
// the Magic Software web site.  This file is subject to the license
//
// 3D GAME ENGINE SOURCE CODE
// http://www.magic-software.com/License/3DGameEngine.pdf

#include "MgcSceneBuilder.h"
#include "MaxToMgc.h"

using namespace std;

TCHAR* MgcSceneBuilder::ms_aacMapName[NTEXMAPS] =
{
    _T("map_ambient"),             // ID_AM
    _T("map_diffuse"),             // ID_DI
    _T("map_specular"),            // ID_SP
    _T("map_shininess"),           // ID_SH
    _T("map_shininess_strength"),  // ID_SS
    _T("map_selfillumination"),    // ID_SI
    _T("map_opacity"),             // ID_OP
    _T("map_filter_color"),        // ID_FI
    _T("map_bump"),                // ID_BU
    _T("map_reflection"),          // ID_RL
    _T("map_refraction"),          // ID_RR
    _T("map_displacment")          // ID_DP
};

const char* MgcSceneBuilder::ms_acEnvName[5] =
{
    "env_explicit",
    "env_sphere",
    "env_cylinder",
    "env_shrink",
    "env_screen"
};

TCHAR MgcSceneBuilder::ms_acMapEnvironment[] = _T("map_environment");
TCHAR MgcSceneBuilder::ms_acMapGeneric[] = _T("map_generic");

//----------------------------------------------------------------------------
void MgcSceneBuilder::CollectMaterials (INode* pkNode)
{
    Mtl* pkMtl = pkNode->GetMtl();
    if ( pkMtl )
        m_kMtlList.Add(pkMtl);
    for (int i = 0; i < pkNode->NumberOfChildren(); i++)
        CollectMaterials(pkNode->GetChildNode(i));
}
//----------------------------------------------------------------------------
void MgcSceneBuilder::ConvertMaterials (INode* pkTopNode)
{
    CollectMaterials(pkTopNode);

    if( !m_pkSettings->bIncludeMaterials ) 
        return;

    int iQuantity = m_kMtlList.Count();
    m_kMtlTree.resize(iQuantity);

    for (int i = 0; i < m_kMtlList.Count(); i++)
    {
        Mtl* pkMtl = m_kMtlList.Get(i);
        if ( pkMtl )
            ConvertMaterial(*pkMtl,i,-1,m_kMtlTree[i]);
    }
}
//----------------------------------------------------------------------------
void MgcSceneBuilder::ConvertMaterial (Mtl& rkMtl, int iMtlID, int iSubNo, MaterialTree& rkTree)
{
    Mgc::MaterialStatePtr spkMState;
    spkMState = new Mgc::MaterialState;
    spkMState->SetName(rkMtl.GetName());
    rkTree.MState() = spkMState;
    Color kColor = rkMtl.GetAmbient();
    spkMState->Ambient().r = kColor.r;
    spkMState->Ambient().g = kColor.g;
    spkMState->Ambient().b = kColor.b;

    kColor = rkMtl.GetDiffuse();
    spkMState->Diffuse().r = kColor.r;
    spkMState->Diffuse().g = kColor.g;
    spkMState->Diffuse().b = kColor.b;

    kColor = rkMtl.GetSpecular();
    spkMState->Specular().r = kColor.r;
    spkMState->Specular().g = kColor.g;
    spkMState->Specular().b = kColor.b;

    spkMState->Shininess() = 128.0f * rkMtl.GetShininess();
    spkMState->Alpha() = 1.0f - rkMtl.GetXParency();

    int iTQuantity = rkMtl.NumSubTexmaps();
    if ( iTQuantity > 0 )
    {
        rkTree.SetNumSubtextures(iTQuantity);
        for (int i = 0; i < iTQuantity; i++)
        {
            Texmap* pkSubTex = rkMtl.GetSubTexmap(i);
            if ( pkSubTex )
            {
                // Check if the material is "standard" and if the subtexture
                // is enabled.  If not enabled, the subtexture is not
                // converted.
                if ( rkMtl.ClassID() == Class_ID(DMTL_CLASS_ID,0)
                &&   !((StdMat&)rkMtl).MapEnabled(i) )
                {
                    continue;
                }

                ConvertTexture(*pkSubTex,rkMtl.ClassID(),i,
                    rkTree.GetSubtextureTree(i));
            }
        }
    }

    int iMQuantity = rkMtl.NumSubMtls();
    if ( iMQuantity > 0 )
    {
        rkTree.SetNumSubmaterials(iMQuantity);
        for (int i = 0; i < iMQuantity; i++)
        {
            Mtl* pkSubMtl = rkMtl.GetSubMtl(i);
            if ( pkSubMtl )
                ConvertMaterial(*pkSubMtl,0,i,rkTree.GetSubmaterialTree(i));
        }
    }
}
//----------------------------------------------------------------------------
void MgcSceneBuilder::ConvertTexture (Texmap& rkTex, Class_ID kClassID, int iSubNo,
    TextureTree& rkTree)
{
   try
   {
       if ( rkTex.ClassID() == Class_ID(BMTEX_CLASS_ID,0) )
       {
           // texture is a bitmapped image
           rkTree.TState() = new Mgc::TextureState;
           const TCHAR* acTexName = rkTex.GetName();
           const TCHAR* acMapName;
           if ( kClassID == Class_ID(0,0) )
               acMapName = ms_acMapEnvironment;
           else if ( kClassID == Class_ID(DMTL_CLASS_ID,0) )
               acMapName = ms_aacMapName[iSubNo];
           else
               acMapName = ms_acMapGeneric;

           int iCombineLength = _tcslen(acTexName)+_tcslen(acMapName)+3;
           TCHAR* acCombineName = new TCHAR[iCombineLength];
           _stprintf(acCombineName,"%s: %s",acTexName,acMapName);
           rkTree.TState()->SetName(acCombineName);

           BitmapTex& rkBmpTex = (BitmapTex&)rkTex;
           Bitmap*pkBmp = rkBmpTex.GetBitmap(m_timeStart);
           if(pkBmp == NULL)
               EXPORT_WARN(IDS_WARN_MAPNOTFOUND);

           int iWidth = pkBmp->Width();
           int iHeight = pkBmp->Height();   
           if ( !((iWidth & -iWidth) == iWidth) || !((iHeight & -iHeight) == iHeight) )
               EXPORT_WARN(IDS_ERR_IMAGEDIMS);

           TSTR kFileName = rkBmpTex.GetMapName();
           char acDrive[_MAX_DRIVE];
           char acDir[_MAX_DIR];
           char acFName[_MAX_FNAME];
           char acExt[_MAX_EXT];
           _splitpath(kFileName.data(),acDrive,acDir,acFName,acExt);
           strcat(acFName, ".mif");
            
           Mgc::Image* pkMgcImage;
           Mgc::Image::Type eType;
           int iBytesPerPixel;
           BOOL bHasAlpha = pkBmp->HasAlpha();
           if ( bHasAlpha )
           {
               eType =  Mgc::Image::IT_RGBA8888;
               iBytesPerPixel = 4;
           }
           else
           {
               eType = Mgc::Image::IT_RGB888;
               iBytesPerPixel = 3;
           }

           WIN32_FIND_DATA kFindData;
           HANDLE hFile = FindFirstFile(acFName,&kFindData);
           FindClose(hFile);

           if ( hFile == INVALID_HANDLE_VALUE
               || m_pkSettings->bGenerateMaps )
           {
                unsigned char* aucDst = 
                    new unsigned char[iWidth * iHeight * iBytesPerPixel];
                unsigned char*pucDst = aucDst;
                BMM_Color_64* pkScanLine = new BMM_Color_64[iWidth];
                BMM_Color_64* pkPixel;
                BMM_Color_32 kScaledColor;

                for (int y = iHeight - 1; y >= 0; y--)
                {
                    pkBmp->GetLinearPixels(0,y,iWidth,pkScanLine);
                    pkPixel = pkScanLine;
                    for ( int x = 0; x < iWidth; x++ )
                    {
                        AColor kColor(*pkPixel);
                        kScaledColor = (BMM_Color_32)kColor;
                        *pucDst++ = (unsigned char)kScaledColor.r;
                        *pucDst++ = (unsigned char)kScaledColor.g;
                        *pucDst++ = (unsigned char)kScaledColor.b;
                        if( bHasAlpha )
                            *pucDst++ = (unsigned char)kScaledColor.a;
                        pkPixel++;
                    }
                }
                delete [] pkScanLine;
                pkMgcImage = new Mgc::Image(eType,iWidth,iHeight,aucDst,acFName);
                pkMgcImage->Save(acFName);
            }
            else
            {
                pkMgcImage = new Mgc::Image(eType,pkBmp->Width(),pkBmp->Height(),
                    NULL,acFName);
            }

            Mgc::Texture* pkTexture = new Mgc::Texture;
            rkTree.TState()->Set(0,pkTexture);  // TO DO.  zero slot for now
            pkTexture->SetImage(pkMgcImage);
            pkTexture->Apply() = Mgc::Texture::AM_MODULATE;
        
            StdUVGen* pkUVGen = rkBmpTex.GetUVGen();
            if ( pkUVGen )
            {
                pkTexture->SetName(ms_acEnvName[pkUVGen->GetCoordMapping(0)]);

                // TO DO.  Need to handle animated texture coordinates.  What to
                // do when the UV parameters are not the standard ones?  The
                // functions below are called through pkUVGen.  The "noise"
                // parameters appear to be for procedural generation of textures.
                //
                // U offset:      GetUOffs(time)
                // V offset:      GetVOffs(time)
                // U tiling:      GetUScl(time)
                // V tiling:      GetVScl(time)
                // angle:         GetAng(time)
                // blur:          GetBlur(time)
                // blur offset:   GetBlurOffs(time)
                // noise amount:  GetNoiseAmt(time)
                // noise size:    GetNoiseSize(time)
                // noise level:   GetNoiseLev(time)
                // noise phase:   GetNoisePhs(time)

                // Apparently Max always uses wrapping?
                pkTexture->Wrap() = Mgc::Texture::WM_WRAP_S_WRAP_T;
            }

            switch ( rkBmpTex.GetFilterType() )
            {
            case FILTER_PYR:
                // bilinear filter, trilinear mipmap
                pkTexture->Filter() = Mgc::Texture::FM_LINEAR;
                pkTexture->Mipmap() = Mgc::Texture::MM_LINEAR_LINEAR;
                break;
            case FILTER_SAT:
                // TO DO. What is it and how to convert?
                pkTexture->Mipmap() = Mgc::Texture::MM_NONE;
                break;
            default:
                pkTexture->Mipmap() = Mgc::Texture::MM_NONE;
                break;
            }
        }
    }
    catch( MaxToMgcException* pkEx)
    {
        pkEx->Show();
        delete pkEx;
        rkTree.TState() = 0;
    }

    int iTQuantity = rkTex.NumSubTexmaps();
    if ( iTQuantity > 0 )
    {
        rkTree.SetNumSubtextures(iTQuantity);
        for (int i = 0; i < iTQuantity; i++)
        {
            Texmap* pkSubTex = rkTex.GetSubTexmap(i);
            if ( pkSubTex )
            {
                ConvertTexture(*pkSubTex,rkTex.ClassID(),i,
                    rkTree.GetSubtextureTree(i));
            }
        }
    }
}
//----------------------------------------------------------------------------
